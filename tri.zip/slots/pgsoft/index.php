<?php
session_start();
$sesi_id = $_SESSION['id'];
if(empty($sesi_id)){
    header('location:../../home');
}else{
    include_once('../functions/koneksi.php');
    $query = mysqli_query($conn, "SELECT * FROM user where id='$sesi_id'");
    $d = mysqli_fetch_assoc($query);
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>TIC88 Situs slot deposit pulsa tri 5000 tanpa potongan</title>

<meta content="TIC88 merupakan situs slot deposit pulsa tri terpercaya tanpa potongan yang memberikan banyak promosi mantap di tahun 2023" name="description" /><meta content="TIC88, Tri 88, slot pulsa tri, slot pulsa, slot online, situs slot, situs slot deposit pulsa, slot deposit tri, situs slot deposit 5000, slot tanpa potongan tri, deposit slot online, depo slot, tri slot." name="keywords" /><meta content="TIC88 Situs slot deposit pulsa tri 5000 tanpa potongan" property="og:title" /><meta content="TIC88 merupakan situs slot deposit pulsa tri terpercaya tanpa potongan yang memberikan banyak promosi mantap di tahun 2023" property="og:description" /><meta content="https://www.androidfanatic.com" property="og:url" /><meta content="TIC88" property="og:site_name" /><meta content="DarkGold" name="theme-color" /><meta content="id-ID" name="language" /><meta content="Indonesia" name="geo.region" /><meta content="Jakarta" name="geo.placename" /><meta content="website" name="categories" /><meta content="lAabQ_jE5qVb4m31PKzUGtDeAeebFGypV4JEw1dywQs" name="google-site-verification" />
    

    <link rel="preload" href="../../fonts/glyphicons-halflings-regular.woff" as="font" type="font/woff" crossorigin>
    <link rel="preload" href="../../fonts/FontsFreeNetAvenirLTStdBook.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="../../fonts/FontsFreeNetAvenirLTStdBlack.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="../../fonts/AvenirLTStdRoman.woff2" as="font" type="font/woff2" crossorigin>


<link href="https://TIC88.net" rel="canonical" /><link href="../../favicon.png" rel="shortcut icon" type="image/x-icon" />
    <link href="../../Content/zoom-beta-css?v=VzHJ-qzdbye7P7NykpUgLrBV7a_6cHgNNOfbEKlM9uc1" rel="stylesheet"/>


    
    <link href="../../Content/Slots/zoom-beta-css?v=Bnt8Egx2sCGuBZZ7YLresCNc63H8A4GrMeuRZe8HLyg1" rel="stylesheet"/>



<link href="../../Content/Theme/zoom-beta-dark-turquoise-css?v=CYcoorWS7zJqM6kKvoS7WpSkFlc3te5aN3DCNawvKDw1" rel="stylesheet"/>


<div style="position: fixed; bottom: 100px; left: 17px; z-index: 10; opacity: 0.98;">
<a href="https://wa.me/6289505661821 " target="_blank" rel="noopener nofollow">
<img src="https://i.ibb.co/2qNy6vN/whatsapp.gif" alt="whatsapp" border="0"  width="50" height="50"></a></div>


 <div align="center1" id="foot_banner2" style="z-index: 9999; width: 100px; margin: 0 auto; overflow:hidden;display:scroll;position:fixed;bottom:200px;left:17px;">
<a id="rtp2" onclick="document.getElementById('foot_banner2').style.display = 'none';" style="cursor:pointer; float:right;">
<button style="z-index: 999920;position: absolute;float: right;top: 0px;right: 0px;width: 20px;cursor: pointer;height: 20px;background-repeat: no-repeat;background-size: cover;background-color: red;" id="rtp2" alt="close" title="Close Ads">X</button></a>
<p>
<a title="RTP SLOT TERBARU" href="../../livertpgacor/" target="_blank"><img src="https://i.ibb.co/LCZStMw/rtp.webp" alt="surga-group" width="50" height="50"></a>
</p>
</div> </head>
<body style="--expand-icon-src: url(//zm-cdn.zoomwl.com/Images/icons/expand.gif?v=20230417-1);
      --collapse-icon-src: url(//zm-cdn.zoomwl.com/Images/icons/collapse.gif?v=20230417-1);
      --play-icon-src: url(//zm-cdn.zoomwl.com/Images/icons/play.png?v=20230417-1);
      --jquery-ui-444444-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_444444_256x240.png?v=20230417-1);
      --jquery-ui-555555-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_555555_256x240.png?v=20230417-1);
      --jquery-ui-ffffff-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_ffffff_256x240.png?v=20230417-1);
      --jquery-ui-777620-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_777620_256x240.png?v=20230417-1);
      --jquery-ui-cc0000-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_cc0000_256x240.png?v=20230417-1);
      --jquery-ui-777777-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_777777_256x240.png?v=20230417-1);">

    <div class="navbar navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="site-topbar">
                            <a href="../../dashboard/" class="logo">
                                <img loading="lazy" src="../../logo.png" />
                            </a>
                        <main>

<div class="user-info">
    <button title="Refresh" class="refresh_balance">
        <i class="glyphicon glyphicon-refresh"></i>
    </button>
    <div class="user-info-item wallet-container" id="wallet_container">
        <?php echo $d['username'] ?>
        <div class="balance">
            <a href="#" data-toggle="dropdown">
                <strong>IDR</strong>
                <span class="total_balance">
                    0.00
                </span>
                <span class="locked-balance locked_balance_container" hidden>
                    <i data-icon="locked-balance" class="glyphicon glyphicon-lock"></i>
                    <span class="total_locked_balance">
                        -1.00
                    </span>
                </span>
            </a>
            <div class="dropdown-menu vendor-balances-container">
    <div class="vendor-balances-header">
        <div>SALDO KREDIT</div>
        <div>0.00</div>
    </div>
    <div class="vendor-balances-content">
            <div>
                <strong>Slots</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>Pragmatic Play</div>
                            <div data-vendor-game-code="7">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>MicroGaming</div>
                            <div data-vendor-game-code="17">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>PG Slots</div>
                            <div data-vendor-game-code="9">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Reel Kingdom by Pragmatic</div>
                            <div data-vendor-game-code="74">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>AdvantPlay</div>
                            <div data-vendor-game-code="54">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Crowd Play</div>
                            <div data-vendor-game-code="73">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>AMB Slot</div>
                            <div data-vendor-game-code="61">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Bigpot</div>
                            <div data-vendor-game-code="75">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>VPower</div>
                            <div data-vendor-game-code="77">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Mario Club</div>
                            <div data-vendor-game-code="80">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Dragoonsoft</div>
                            <div data-vendor-game-code="81">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Slot88</div>
                            <div data-vendor-game-code="40">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>ION Slot</div>
                            <div data-vendor-game-code="50">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Joker</div>
                            <div data-vendor-game-code="6">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Fachai</div>
                            <div data-vendor-game-code="72">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Jili</div>
                            <div data-vendor-game-code="70">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Live22</div>
                            <div data-vendor-game-code="45">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Playstar</div>
                            <div data-vendor-game-code="65">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Spade Gaming</div>
                            <div data-vendor-game-code="29">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Fun Gaming</div>
                            <div data-vendor-game-code="79">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Habanero</div>
                            <div data-vendor-game-code="16">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>JDB</div>
                            <div data-vendor-game-code="51">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>CQ9</div>
                            <div data-vendor-game-code="13">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Top Trend Gaming</div>
                            <div data-vendor-game-code="67">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>BetSoft</div>
                            <div data-vendor-game-code="68">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Playtech</div>
                            <div data-vendor-game-code="2">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Yggdrasil</div>
                            <div data-vendor-game-code="42">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Play&#39;n Go</div>
                            <div data-vendor-game-code="18">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>OneTouch</div>
                            <div data-vendor-game-code="33">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Real Time Gaming</div>
                            <div data-vendor-game-code="28">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Flow Gaming</div>
                            <div data-vendor-game-code="26">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Funky Games</div>
                            <div data-vendor-game-code="35">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>Live Casino</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>ION Casino</div>
                            <div data-vendor-game-code="1">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>PP Casino</div>
                            <div data-vendor-game-code="41">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>MG Live</div>
                            <div data-vendor-game-code="66">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Evo Gaming</div>
                            <div data-vendor-game-code="38">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Sexy Baccarat</div>
                            <div data-vendor-game-code="27">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Pretty Gaming</div>
                            <div data-vendor-game-code="39">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Asia Gaming</div>
                            <div data-vendor-game-code="14">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>AllBet</div>
                            <div data-vendor-game-code="44">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>PGS Live</div>
                            <div data-vendor-game-code="64">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>SA Gaming</div>
                            <div data-vendor-game-code="84">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Ebet</div>
                            <div data-vendor-game-code="85">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Dream Gaming</div>
                            <div data-vendor-game-code="43">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>568Win Casino</div>
                            <div data-vendor-game-code="10">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>SV388</div>
                            <div data-vendor-game-code="57">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>Sports</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>SBO Sportsbook</div>
                            <div data-vendor-game-code="5">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Saba Sportsbook</div>
                            <div data-vendor-game-code="23">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Opus</div>
                            <div data-vendor-game-code="71">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>WBet</div>
                            <div data-vendor-game-code="69">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Pinnacle</div>
                            <div data-vendor-game-code="59">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>CMD</div>
                            <div data-vendor-game-code="83">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>SBO Virtual Sports</div>
                            <div data-vendor-game-code="11">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>PP Virtual Sports</div>
                            <div data-vendor-game-code="55">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>Arcade</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>MicroGaming Fishing</div>
                            <div data-vendor-game-code="17">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Crowd Play Fishing</div>
                            <div data-vendor-game-code="73">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Spribe</div>
                            <div data-vendor-game-code="82">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Joker Fishing</div>
                            <div data-vendor-game-code="6">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Fachai Fishing</div>
                            <div data-vendor-game-code="72">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Jili Fishing</div>
                            <div data-vendor-game-code="70">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Mario Club Fishing</div>
                            <div data-vendor-game-code="80">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Dragoonsoft Fishing</div>
                            <div data-vendor-game-code="81">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>AMB Slot Fishing</div>
                            <div data-vendor-game-code="61">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>VPower Fishing</div>
                            <div data-vendor-game-code="77">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Live22 Fishing</div>
                            <div data-vendor-game-code="45">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>CQ9 Fishing</div>
                            <div data-vendor-game-code="13">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Fun Gaming Fishing</div>
                            <div data-vendor-game-code="79">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Spade Gaming Fishing</div>
                            <div data-vendor-game-code="29">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Arcadia</div>
                            <div data-vendor-game-code="63">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Playstar Fishing</div>
                            <div data-vendor-game-code="65">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>AdvantPlay Mini Game</div>
                            <div data-vendor-game-code="62">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>JDB Fishing</div>
                            <div data-vendor-game-code="51">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Funky Games Fishing</div>
                            <div data-vendor-game-code="35">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>MM Tangkas</div>
                            <div data-vendor-game-code="34">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>Poker</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>Balak Play</div>
                            <div data-vendor-game-code="24">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>9Gaming</div>
                            <div data-vendor-game-code="32">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>E-Sports</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>IM Esports</div>
                            <div data-vendor-game-code="78">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Pinnacle E-Sports</div>
                            <div data-vendor-game-code="60">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>TF Gaming</div>
                            <div data-vendor-game-code="58">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>Togel</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>Nex4D</div>
                            <div data-vendor-game-code="48">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>
        </div>
    </div>
    <div class="unread-announcements-button unread_announcements_button" data-announcement-count="0">
        <a href="#">
            <i class="glyphicon glyphicon-bell"></i>
        </a>
    </div>
    <a href="../../account-summary" data-link="profile">
        <span class="user-info-item">
            <i class="glyphicon glyphicon-user"></i>
            Akun Saya
        </span>
    </a>
    <a href="../../deposit" data-link="deposit">
        <span class="user-info-item">
            <i class="glyphicon glyphicon-credit-card"></i>
            Deposit
        </span>
    </a>
        <a href="../../mobile-app" data-link="download">
            <span class="user-info-item">
                <i class="glyphicon glyphicon-download-alt"></i>
                Download Game APK
            </span>
        </a>
    <a href="#" data-link="inbox">
        <span class="user-info-item">
            <i class="glyphicon glyphicon-envelope"></i>
            Inbox
        </span>
    </a>
    <a href="#" data-link="announcement">
        <span class="user-info-item unread_announcements_button" data-new-announcement="true" data-announcement-count="0">
            <i class="glyphicon glyphicon-bell"></i>
            Pengumuman
        </span>
    </a>
        <a href="javascript:void(window.open(&#39;/streaming/live-tv/Mobile&#39;, &#39;live-tv&#39;))" data-link="live-tv">
            <span class="user-info-item">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/live-tv.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/live-tv.png?v=20230417-1" type="image/png" /><img alt="Live TV" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/live-tv.png?v=20230417-1" /></picture>
                Live Tv
            </span>
        </a>
    <a href="#" data-link="logout" onclick="window.closeWindows(); document.querySelector('#logout-form').submit()">
<form action="../../logout.php" id="logout-form" method="post">            <span class="user-info-item">
                <i class="glyphicon glyphicon-log-out"></i>
                Keluar
            </span>
</form>    </a>
</div>
                            <label class="site-side-menu-trigger" for="site_side_menu_trigger_input">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </label>
                        </main>
                    </div>
                </div>
            </div>
        </div>
        <div class="site-header-navbar">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="site-menu">
                            <li data-active="false">
                                <a href="../../dashboard/">
                                    <i class="glyphicon glyphicon-home"></i>
                                </a>
                            </li>
                            <li data-active="false">
                                <a href="../../slots/">
                                    <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/hot-games.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/hot-games.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/hot-games.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/hot-games-active.png?v=20230417-1);" /></picture>
                                    Hot Games
                                    <i data-icon="dropdown"></i>
                                </a>
                                    <div class="game-list-container">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <ul class="games-container">



<li>
    <a href="/slots/pragmatic">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.png?v=20230417-1" /></picture>
        Pragmatic Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TRG/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.png?v=20230417-1" /></picture>
        ION Casino
    </a>
</li>



<li>
    <a href="/slots/microgaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.png?v=20230417-1" /></picture>
        MicroGaming
    </a>
</li>



<li>
    <a href="/slots/crowd-play">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.png?v=20230417-1" /></picture>
        Crowd Play
    </a>
</li>



<li>
    <a href="/slots/pgsoft">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.png?v=20230417-1" /></picture>
        PG Slots
    </a>
</li>



<li>
    <a href="/arcade/spribe">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.png?v=20230417-1" /></picture>
        Spribe
    </a>
</li>



<li>
    <a href="/slots/reel-kingdom">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.png?v=20230417-1" /></picture>
        Reel Kingdom by Pragmatic
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/G8POKER/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.png?v=20230417-1" /></picture>
        Balak Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/BALAK4D/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.png?v=20230417-1" /></picture>
        Nex4D
    </a>
</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </li>
                                <li data-active="true">
                                    <a href="../../slots/">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/slots.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/slots.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/slots.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/slots-active.png?v=20230417-1);" /></picture>
                                        Slots
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="/slots/pragmatic">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.png?v=20230417-1" /></picture>
        Pragmatic Play
    </a>
</li>



<li>
    <a href="/slots/microgaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.png?v=20230417-1" /></picture>
        MicroGaming
    </a>
</li>



<li>
    <a href="/slots/pgsoft">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.png?v=20230417-1" /></picture>
        PG Slots
    </a>
</li>



<li>
    <a href="/slots/reel-kingdom">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.png?v=20230417-1" /></picture>
        Reel Kingdom by Pragmatic
    </a>
</li>



<li>
    <a href="/slots/advantplay">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplay.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplay.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplay.png?v=20230417-1" /></picture>
        AdvantPlay
    </a>
</li>



<li>
    <a href="/slots/crowd-play">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.png?v=20230417-1" /></picture>
        Crowd Play
    </a>
</li>



<li>
    <a href="/slots/amb-slot">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/amb.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/amb.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/amb.png?v=20230417-1" /></picture>
        AMB Slot
    </a>
</li>



<li>
    <a href="/slots/bigpot">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/bigpot.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/bigpot.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/bigpot.png?v=20230417-1" /></picture>
        Bigpot
    </a>
</li>



<li>
    <a href="/slots/vpower">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpower.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpower.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpower.png?v=20230417-1" /></picture>
        VPower
    </a>
</li>



<li>
    <a href="/slots/mario-club">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclub.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclub.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclub.png?v=20230417-1" /></picture>
        Mario Club
    </a>
</li>



<li>
    <a href="/slots/dragoonsoft">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoft.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoft.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoft.png?v=20230417-1" /></picture>
        Dragoonsoft
    </a>
</li>



<li>
    <a href="/slots/slot88">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/slot88.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/slot88.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/slot88.png?v=20230417-1" /></picture>
        Slot88
    </a>
</li>



<li>
    <a href="/slots/ion-slot">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgs.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgs.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgs.png?v=20230417-1" /></picture>
        ION Slot
    </a>
</li>



<li>
    <a href="/slots/joker">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/joker.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/joker.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/joker.png?v=20230417-1" /></picture>
        Joker
    </a>
</li>



<li>
    <a href="/slots/fachai">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachai.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachai.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachai.png?v=20230417-1" /></picture>
        Fachai
    </a>
</li>



<li>
    <a href="/slots/jili">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jili.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jili.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jili.png?v=20230417-1" /></picture>
        Jili
    </a>
</li>



<li>
    <a href="/slots/live22">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22.png?v=20230417-1" /></picture>
        Live22
    </a>
</li>



<li>
    <a href="/slots/playstar">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstar.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstar.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstar.png?v=20230417-1" /></picture>
        Playstar
    </a>
</li>



<li>
    <a href="/slots/spade-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegaming.png?v=20230417-1" /></picture>
        Spade Gaming
    </a>
</li>



<li>
    <a href="/slots/fun-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungaming.png?v=20230417-1" /></picture>
        Fun Gaming
    </a>
</li>



<li>
    <a href="/slots/habanero">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/habanero.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/habanero.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/habanero.png?v=20230417-1" /></picture>
        Habanero
    </a>
</li>



<li>
    <a href="/slots/jdb">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdb.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdb.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdb.png?v=20230417-1" /></picture>
        JDB
    </a>
</li>



<li>
    <a href="/slots/cq9">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9.png?v=20230417-1" /></picture>
        CQ9
    </a>
</li>



<li>
    <a href="/slots/ttg">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ttg.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ttg.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ttg.png?v=20230417-1" /></picture>
        Top Trend Gaming
    </a>
</li>



<li>
    <a href="/slots/betsoft">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/betsoft.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/betsoft.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/betsoft.png?v=20230417-1" /></picture>
        BetSoft
    </a>
</li>



<li>
    <a href="/slots/playtech">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playtech.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playtech.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playtech.png?v=20230417-1" /></picture>
        Playtech
    </a>
</li>



<li>
    <a href="/slots/yggdrasil">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/yggdrasil.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/yggdrasil.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/yggdrasil.png?v=20230417-1" /></picture>
        Yggdrasil
    </a>
</li>



<li>
    <a href="/slots/playngo">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playngo.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playngo.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playngo.png?v=20230417-1" /></picture>
        Play&#39;n Go
    </a>
</li>



<li>
    <a href="/slots/onetouch">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onetouch.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onetouch.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onetouch.png?v=20230417-1" /></picture>
        OneTouch
    </a>
</li>



<li>
    <a href="/slots/real-time-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sborealtimegaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sborealtimegaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sborealtimegaming.png?v=20230417-1" /></picture>
        Real Time Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOFLOWGAMING/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sboflowgaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sboflowgaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sboflowgaming.png?v=20230417-1" /></picture>
        Flow Gaming
    </a>
</li>



<li>
    <a href="/slots/funky-games">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygame.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygame.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygame.png?v=20230417-1" /></picture>
        Funky Games
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/casino">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/casino.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/casino.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/casino.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/casino-active.png?v=20230417-1);" /></picture>
                                        Live Casino
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TRG/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.png?v=20230417-1" /></picture>
        ION Casino
    </a>
</li>



<li>
    <a href="/casino/pragmatic">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pplivecasino.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pplivecasino.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pplivecasino.png?v=20230417-1" /></picture>
        PP Casino
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/MGLIVECASINO/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/mglivecasino.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/mglivecasino.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/mglivecasino.png?v=20230417-1" /></picture>
        MG Live
    </a>
</li>



<li>
    <a href="/casino/evo-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/evogaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/evogaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/evogaming.png?v=20230417-1" /></picture>
        Evo Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOSEXYBACCARAT/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbosexybaccarat.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbosexybaccarat.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbosexybaccarat.png?v=20230417-1" /></picture>
        Sexy Baccarat
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PRETTYGAMING/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/prettygaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/prettygaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/prettygaming.png?v=20230417-1" /></picture>
        Pretty Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/AG/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ag.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ag.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ag.png?v=20230417-1" /></picture>
        Asia Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/ALLBET/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/allbet.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/allbet.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/allbet.png?v=20230417-1" /></picture>
        AllBet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PGSLIVE/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgslive.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgslive.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgslive.png?v=20230417-1" /></picture>
        PGS Live
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SAGAMING/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sagaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sagaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sagaming.png?v=20230417-1" /></picture>
        SA Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/EBET/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ebet.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ebet.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ebet.png?v=20230417-1" /></picture>
        Ebet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/DREAMGAMING/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dreamgaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dreamgaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dreamgaming.png?v=20230417-1" /></picture>
        Dream Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOCASINO/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocasino.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocasino.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocasino.png?v=20230417-1" /></picture>
        568Win Casino
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SV388/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sv388.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sv388.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sv388.png?v=20230417-1" /></picture>
        SV388
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/sport">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/sport.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/sport.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/sport.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/sport-active.png?v=20230417-1);" /></picture>
                                        Sports
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBO/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbo.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbo.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbo.png?v=20230417-1" /></picture>
        SBO Sportsbook
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IBCSPORTS/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ibcsports.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ibcsports.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ibcsports.png?v=20230417-1" /></picture>
        Saba Sportsbook
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/OPUS/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/opus.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/opus.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/opus.png?v=20230417-1" /></picture>
        Opus
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/WBET/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/wbet.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/wbet.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/wbet.png?v=20230417-1" /></picture>
        WBet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PINNACLE/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacle.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacle.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacle.png?v=20230417-1" /></picture>
        Pinnacle
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/CMD/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/cmd.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/cmd.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/cmd.png?v=20230417-1" /></picture>
        CMD
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOVIRTUALGAMES/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbovirtualgames.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbovirtualgames.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbovirtualgames.png?v=20230417-1" /></picture>
        SBO Virtual Sports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PPVIRTUALGAMES/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ppvirtualgames.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ppvirtualgames.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ppvirtualgames.png?v=20230417-1" /></picture>
        PP Virtual Sports
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/arcade">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/arcade.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/arcade.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/arcade.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/arcade-active.png?v=20230417-1);" /></picture>
                                        Arcade
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="/arcade/microgaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgamingfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgamingfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgamingfishing.png?v=20230417-1" /></picture>
        MicroGaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/crowd-play">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplayfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplayfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplayfishing.png?v=20230417-1" /></picture>
        Crowd Play Fishing
    </a>
</li>



<li>
    <a href="/arcade/spribe">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.png?v=20230417-1" /></picture>
        Spribe
    </a>
</li>



<li>
    <a href="/arcade/joker">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jokerfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jokerfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jokerfishing.png?v=20230417-1" /></picture>
        Joker Fishing
    </a>
</li>



<li>
    <a href="/arcade/fachai">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachaifishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachaifishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachaifishing.png?v=20230417-1" /></picture>
        Fachai Fishing
    </a>
</li>



<li>
    <a href="/arcade/jili">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jilifishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jilifishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jilifishing.png?v=20230417-1" /></picture>
        Jili Fishing
    </a>
</li>



<li>
    <a href="/arcade/mario-club">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclubfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclubfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclubfishing.png?v=20230417-1" /></picture>
        Mario Club Fishing
    </a>
</li>



<li>
    <a href="/arcade/dragoonsoft">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoftfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoftfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoftfishing.png?v=20230417-1" /></picture>
        Dragoonsoft Fishing
    </a>
</li>



<li>
    <a href="/arcade/amb-slot">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ambfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ambfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ambfishing.png?v=20230417-1" /></picture>
        AMB Slot Fishing
    </a>
</li>



<li>
    <a href="/arcade/vpower">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpowerfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpowerfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpowerfishing.png?v=20230417-1" /></picture>
        VPower Fishing
    </a>
</li>



<li>
    <a href="/arcade/live22">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22fishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22fishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22fishing.png?v=20230417-1" /></picture>
        Live22 Fishing
    </a>
</li>



<li>
    <a href="/arcade/cq9">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9fishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9fishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9fishing.png?v=20230417-1" /></picture>
        CQ9 Fishing
    </a>
</li>



<li>
    <a href="/arcade/fun-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungamingfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungamingfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungamingfishing.png?v=20230417-1" /></picture>
        Fun Gaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/spade-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegamingfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegamingfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegamingfishing.png?v=20230417-1" /></picture>
        Spade Gaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/arcadia">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/arcadia.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/arcadia.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/arcadia.png?v=20230417-1" /></picture>
        Arcadia
    </a>
</li>



<li>
    <a href="/arcade/playstar">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstarfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstarfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstarfishing.png?v=20230417-1" /></picture>
        Playstar Fishing
    </a>
</li>



<li>
    <a href="/arcade/advantplay-mini-game">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplayminigame.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplayminigame.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplayminigame.png?v=20230417-1" /></picture>
        AdvantPlay Mini Game
    </a>
</li>



<li>
    <a href="/arcade/jdb">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdbfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdbfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdbfishing.png?v=20230417-1" /></picture>
        JDB Fishing
    </a>
</li>



<li>
    <a href="/arcade/funky-games">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygamefishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygamefishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygamefishing.png?v=20230417-1" /></picture>
        Funky Games Fishing
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IXTTANGKAS/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ixttangkas.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ixttangkas.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ixttangkas.png?v=20230417-1" /></picture>
        MM Tangkas
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/poker">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/poker.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/poker.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/poker.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/poker-active.png?v=20230417-1);" /></picture>
                                        Poker
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/G8POKER/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.png?v=20230417-1" /></picture>
        Balak Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/ONEPOKER/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onepoker.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onepoker.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onepoker.png?v=20230417-1" /></picture>
        9Gaming
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/e-sports">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/e-sports.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/e-sports.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/e-sports.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/e-sports-active.png?v=20230417-1);" /></picture>
                                        E-Sports
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IMONE/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/imone.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/imone.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/imone.png?v=20230417-1" /></picture>
        IM Esports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PINNACLEESPORTS/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacleesports.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacleesports.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacleesports.png?v=20230417-1" /></picture>
        Pinnacle E-Sports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TFGAMING/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/tfgaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/tfgaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/tfgaming.png?v=20230417-1" /></picture>
        TF Gaming
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/others">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/others.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/others.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/others.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/others-active.png?v=20230417-1);" /></picture>
                                        Togel
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/BALAK4D/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.png?v=20230417-1" /></picture>
        Nex4D
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                            <li data-active="false">
                                <a href="/promotion">
                                    <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/promotion.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/promotion.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/promotion.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/promotion-active.png?v=20230417-1);" /></picture>
                                    Promosi
                                </a>
                            </li>
                            <li>
                                <div class="language-selector-container" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/flags.png?v=20230417-1);">
                                    <div id="language_selector_trigger" data-toggle="dropdown" class="language-selector-trigger" data-language="id">
                                        <i data-language="id"></i>
                                        ID
                                        <i data-icon="dropdown"></i>
                                    </div>
                                    <ul class="dropdown-menu language-selector">
                                            <li class="language_selector" data-language="en">
                                                <i data-language="en"></i>
                                                EN
                                            </li>
                                            <li class="language_selector" data-language="id">
                                                <i data-language="id"></i>
                                                ID
                                            </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    




<picture><source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/banners/slots/banner-480w.webp?v=20230417-1" type="image/webp" /><source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/banners/slots/banner-480w.png?v=20230417-1" type="image/png" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/banners/slots/banner.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/banners/slots/banner.png?v=20230417-1" type="image/png" /><img class="img-responsive" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/banners/slots/banner.png?v=20230417-1" /></picture>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="slots-jackpot-outer-container">
                <div class="slots-jackpot-inner-container">
                    <div class="slot-jackpot-container">
    <div class="progressive-jackpot">
        <span id="progressive_jackpot"></span>
        <div class="jackpot-container">
            <span class="counter-container" id="progressive_jackpot_counter">
                <span data-digit="-"></span>
                <span data-digit="-"></span>
                <span>,</span>
                <span data-digit="-"></span>
                <span data-digit="-"></span>
                <span data-digit="-"></span>
                <span>,</span>
                <span data-digit="-"></span>
                <span data-digit="-"></span>
                <span data-digit="-"></span>
            </span>
        </div>
    </div>
</div>

                </div>
            </div>
            <div class="game-provider-slider">
    <button tpye="button" id="previous_game_provider">
        <span class="glyphicon glyphicon-chevron-left"></span>
    </button>
    <div class="game-providers" id="slots_providers">
            <a href="../../slots/pragmatic/">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PP.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PP.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PP.png?v=20230417-1" /></picture>
                <h5>Pragmatic Play</h5>
            </a>
            <a href="#">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/MICROGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/MICROGAMING.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/MICROGAMING.png?v=20230417-1" /></picture>
                <h5>MicroGaming</h5>
            </a>
            <a href="../../slots/pgsoft/">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PGSOFT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PGSOFT.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PGSOFT.png?v=20230417-1" /></picture>
                <h5>PG Slots</h5>
            </a>
            <a href="#">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/REELKINGDOM.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/REELKINGDOM.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/REELKINGDOM.png?v=20230417-1" /></picture>
                <h5>Reel Kingdom by Pragmatic</h5>
            </a>
            <a href="#">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/ADVANTPLAY.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/ADVANTPLAY.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/ADVANTPLAY.png?v=20230417-1" /></picture>
                <h5>AdvantPlay</h5>
            </a>
            <a href="#">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/CROWDPLAY.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/CROWDPLAY.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/CROWDPLAY.png?v=20230417-1" /></picture>
                <h5>Crowd Play</h5>
            </a>
            <a href="/slots/amb-slot">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/AMB.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/AMB.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/AMB.png?v=20230417-1" /></picture>
                <h5>AMB Slot</h5>
            </a>
            <a href="/slots/bigpot">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/BIGPOT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/BIGPOT.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/BIGPOT.png?v=20230417-1" /></picture>
                <h5>Bigpot</h5>
            </a>
            <a href="/slots/vpower">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/VPOWER.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/VPOWER.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/VPOWER.png?v=20230417-1" /></picture>
                <h5>VPower</h5>
            </a>
            <a href="/slots/mario-club">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/MARIOCLUB.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/MARIOCLUB.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/MARIOCLUB.png?v=20230417-1" /></picture>
                <h5>Mario Club</h5>
            </a>
            <a href="/slots/dragoonsoft">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/DRAGOONSOFT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/DRAGOONSOFT.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/DRAGOONSOFT.png?v=20230417-1" /></picture>
                <h5>Dragoonsoft</h5>
            </a>
            <a href="/slots/slot88">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SLOT88.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SLOT88.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SLOT88.png?v=20230417-1" /></picture>
                <h5>Slot88</h5>
            </a>
            <a href="/slots/ion-slot">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PGS.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PGS.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PGS.png?v=20230417-1" /></picture>
                <h5>ION Slot</h5>
            </a>
            <a href="/slots/joker">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/JOKER.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/JOKER.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/JOKER.png?v=20230417-1" /></picture>
                <h5>Joker</h5>
            </a>
            <a href="/slots/fachai">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/FACHAI.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/FACHAI.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/FACHAI.png?v=20230417-1" /></picture>
                <h5>Fachai</h5>
            </a>
            <a href="/slots/jili">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/JILI.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/JILI.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/JILI.png?v=20230417-1" /></picture>
                <h5>Jili</h5>
            </a>
            <a href="/slots/live22">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/LIVE22.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/LIVE22.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/LIVE22.png?v=20230417-1" /></picture>
                <h5>Live22</h5>
            </a>
            <a href="/slots/playstar">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PLAYSTAR.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PLAYSTAR.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PLAYSTAR.png?v=20230417-1" /></picture>
                <h5>Playstar</h5>
            </a>
            <a href="/slots/spade-gaming">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SPADEGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SPADEGAMING.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SPADEGAMING.png?v=20230417-1" /></picture>
                <h5>Spade Gaming</h5>
            </a>
            <a href="/slots/fun-gaming">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/FUNGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/FUNGAMING.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/FUNGAMING.png?v=20230417-1" /></picture>
                <h5>Fun Gaming</h5>
            </a>
            <a href="/slots/habanero">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/HABANERO.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/HABANERO.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/HABANERO.png?v=20230417-1" /></picture>
                <h5>Habanero</h5>
            </a>
            <a href="/slots/jdb">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/JDB.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/JDB.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/JDB.png?v=20230417-1" /></picture>
                <h5>JDB</h5>
            </a>
            <a href="/slots/cq9">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOCQ9.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOCQ9.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOCQ9.png?v=20230417-1" /></picture>
                <h5>CQ9</h5>
            </a>
            <a href="/slots/ttg">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/TTG.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/TTG.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/TTG.png?v=20230417-1" /></picture>
                <h5>Top Trend Gaming</h5>
            </a>
            <a href="/slots/betsoft">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/BETSOFT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/BETSOFT.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/BETSOFT.png?v=20230417-1" /></picture>
                <h5>BetSoft</h5>
            </a>
            <a href="/slots/playtech">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PLAYTECH.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PLAYTECH.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PLAYTECH.png?v=20230417-1" /></picture>
                <h5>Playtech</h5>
            </a>
            <a href="/slots/yggdrasil">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/YGGDRASIL.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/YGGDRASIL.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/YGGDRASIL.png?v=20230417-1" /></picture>
                <h5>Yggdrasil</h5>
            </a>
            <a href="/slots/playngo">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PLAYNGO.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PLAYNGO.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/PLAYNGO.png?v=20230417-1" /></picture>
                <h5>Play&#39;n Go</h5>
            </a>
            <a href="/slots/onetouch">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/ONETOUCH.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/ONETOUCH.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/ONETOUCH.png?v=20230417-1" /></picture>
                <h5>OneTouch</h5>
            </a>
            <a href="/slots/real-time-gaming">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOREALTIMEGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOREALTIMEGAMING.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOREALTIMEGAMING.png?v=20230417-1" /></picture>
                <h5>Real Time Gaming</h5>
            </a>
            <a href="/slots/flow-gaming">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOFLOWGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOFLOWGAMING.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOFLOWGAMING.png?v=20230417-1" /></picture>
                <h5>Flow Gaming</h5>
            </a>
            <a href="/slots/funky-games">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOFUNKYGAME.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOFUNKYGAME.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/tabs/slots/SBOFUNKYGAME.png?v=20230417-1" /></picture>
                <h5>Funky Games</h5>
            </a>
    </div>
    <button type="button" id="next_game_provider">
        <span class="glyphicon glyphicon-chevron-right"></span>
    </button>
</div>

            <div class="game-list-container">
                <div class="filter-section">
                    <div class="category-filter" id="filter_categories">
                        <div class="category-filter-link active" data-category="">
                            Semua permainan
                        </div>
                    </div>
                    <input type="text" id="filter_input" placeholder="Cari Permainan">
                    <select id="filter_categories_select">
                        <option value="">Semua permainan</option>
                    </select>
                </div>
                <div class="game-list-title">PG Slots</div>
                <div class="game-list" id="game_list" style="--star-on-icon: url(\/\/zm-cdn\.zoomwl\.com\/Images\/icons\/star-on\.svg\?v\=20230417-1); --star-off-icon: url(\/\/zm-cdn\.zoomwl\.com\/Images\/icons\/star-off\.svg\?v\=20230417-1);"><div class="game-item" data-game="Songkran Splash" data-match="true" style="order: 19;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1448762" id="PGSOFT_1448762" class="favourite-game-btn"><label for="PGSOFT_1448762"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_1448762.jpg?v=20230417-1" alt="Songkran Splash"><div class="link-container"><a class="play-now" data-game="Songkran Splash" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1448762', 'Slots')">MAIN</a></div></div><div class="game-name">Songkran Splash</div></div><div class="game-item" data-game="Bakery Bonanza" data-match="true" style="order: 46;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1418544" id="PGSOFT_1418544" class="favourite-game-btn"><label for="PGSOFT_1418544"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_1418544.jpg?v=20230417-1" alt="Bakery Bonanza"><div class="link-container"><a class="play-now" data-game="Bakery Bonanza" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1418544', 'Slots')">MAIN</a></div></div><div class="game-name">Bakery Bonanza</div></div><div class="game-item" data-game="Hawaiian Tiki" data-match="true" style="order: 49;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1381200" id="PGSOFT_1381200" class="favourite-game-btn"><label for="PGSOFT_1381200"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_1381200.jpg?v=20230417-1" alt="Hawaiian Tiki"><div class="link-container"><a class="play-now" data-game="Hawaiian Tiki" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1381200', 'Slots')">MAIN</a></div></div><div class="game-name">Hawaiian Tiki</div></div><div class="game-item" data-game="Rave Party Fever" data-match="true" style="order: 59;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1420892" id="PGSOFT_1420892" class="favourite-game-btn"><label for="PGSOFT_1420892"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_1420892.jpg?v=20230417-1" alt="Rave Party Fever"><div class="link-container"><a class="play-now" data-game="Rave Party Fever" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1420892', 'Slots')">MAIN</a></div></div><div class="game-name">Rave Party Fever</div></div><div class="game-item" data-game="Fortune Rabbit" data-match="true" style="order: 42;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1543462" id="PGSOFT_1543462" class="favourite-game-btn"><label for="PGSOFT_1543462"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_1543462.jpg?v=20230417-1" alt="Fortune Rabbit"><div class="link-container"><a class="play-now" data-game="Fortune Rabbit" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1543462', 'Slots')">MAIN</a></div></div><div class="game-name">Fortune Rabbit</div></div><div class="game-item" data-game="Midas Fortune" data-match="true" style="order: 26;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1402846" id="PGSOFT_1402846" class="favourite-game-btn"><label for="PGSOFT_1402846"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_1402846.jpg?v=20230417-1" alt="Midas Fortune"><div class="link-container"><a class="play-now" data-game="Midas Fortune" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1402846', 'Slots')">MAIN</a></div></div><div class="game-name">Midas Fortune</div></div><div class="game-item" data-game="Asgardian Rising" data-match="true" style="order: 10;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1340277" id="PGSOFT_1340277" class="favourite-game-btn"><label for="PGSOFT_1340277"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_1340277.jpg?v=20230417-1" alt="Asgardian Rising"><div class="link-container"><a class="play-now" data-game="Asgardian Rising" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1340277', 'Slots')">MAIN</a></div></div><div class="game-name">Asgardian Rising</div></div><div class="game-item" data-game="Diner Delights" data-match="true" style="order: 31;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1372643" id="PGSOFT_1372643" class="favourite-game-btn"><label for="PGSOFT_1372643"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_1372643.jpg?v=20230417-1" alt="Diner Delights"><div class="link-container"><a class="play-now" data-game="Diner Delights" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1372643', 'Slots')">MAIN</a></div></div><div class="game-name">Diner Delights</div></div><div class="game-item" data-game="Alchemy Gold" data-match="true" style="order: 45;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1368367" id="PGSOFT_1368367" class="favourite-game-btn"><label for="PGSOFT_1368367"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_1368367.jpg?v=20230417-1" alt="Alchemy Gold"><div class="link-container"><a class="play-now" data-game="Alchemy Gold" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1368367', 'Slots')">MAIN</a></div></div><div class="game-name">Alchemy Gold</div></div><div class="game-item" data-game="Totem Wonders" data-match="true" style="order: 62;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1338274" id="PGSOFT_1338274" class="favourite-game-btn"><label for="PGSOFT_1338274"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_1338274.jpg?v=20230417-1" alt="Totem Wonders"><div class="link-container"><a class="play-now" data-game="Totem Wonders" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1338274', 'Slots')">MAIN</a></div></div><div class="game-name">Totem Wonders</div></div><div class="game-item" data-game="Prosperity Fortune Tree" data-match="true" style="order: 67;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1312883" id="PGSOFT_1312883" class="favourite-game-btn"><label for="PGSOFT_1312883"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_1312883.jpg?v=20230417-1" alt="Prosperity Fortune Tree"><div class="link-container"><a class="play-now" data-game="Prosperity Fortune Tree" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1312883', 'Slots')">MAIN</a></div></div><div class="game-name">Prosperity Fortune Tree</div></div><div class="game-item" data-game="Wild Bounty Showdown" data-match="true" style="order: 5;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_135" id="PGSOFT_135" class="favourite-game-btn"><label for="PGSOFT_135"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_135.jpg?v=20230417-1" alt="Wild Bounty Showdown"><div class="link-container"><a class="play-now" data-game="Wild Bounty Showdown" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_135', 'Slots')">MAIN</a></div></div><div class="game-name">Wild Bounty Showdown</div></div><div class="game-item" data-game="Wild Coaster" data-match="true" style="order: 72;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_132" id="PGSOFT_132" class="favourite-game-btn"><label for="PGSOFT_132"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_132.jpg?v=20230417-1" alt="Wild Coaster"><div class="link-container"><a class="play-now" data-game="Wild Coaster" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_132', 'Slots')">MAIN</a></div></div><div class="game-name">Wild Coaster</div></div><div class="game-item" data-game="Legend of Perseus" data-match="true" style="order: 21;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_128" id="PGSOFT_128" class="favourite-game-btn"><label for="PGSOFT_128"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_128.jpg?v=20230417-1" alt="Legend of Perseus"><div class="link-container"><a class="play-now" data-game="Legend of Perseus" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_128', 'Slots')">MAIN</a></div></div><div class="game-name">Legend of Perseus</div></div><div class="game-item" data-game="Speed Winner" data-match="true" style="order: 14;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_127" id="PGSOFT_127" class="favourite-game-btn"><label for="PGSOFT_127"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_127.jpg?v=20230417-1" alt="Speed Winner"><div class="link-container"><a class="play-now" data-game="Speed Winner" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_127', 'Slots')">MAIN</a></div></div><div class="game-name">Speed Winner</div></div><div class="game-item" data-game="Lucky Piggy" data-match="true" style="order: 24;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_130" id="PGSOFT_130" class="favourite-game-btn"><label for="PGSOFT_130"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_130.jpg?v=20230417-1" alt="Lucky Piggy"><div class="link-container"><a class="play-now" data-game="Lucky Piggy" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_130', 'Slots')">MAIN</a></div></div><div class="game-name">Lucky Piggy</div></div><div class="game-item" data-game="Battleground Royale" data-match="true" style="order: 34;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_124" id="PGSOFT_124" class="favourite-game-btn"><label for="PGSOFT_124"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_124.jpg?v=20230417-1" alt="Battleground Royale"><div class="link-container"><a class="play-now" data-game="Battleground Royale" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_124', 'Slots')">MAIN</a></div></div><div class="game-name">Battleground Royale</div></div><div class="game-item" data-game="Win Win Fish Prawn Crab" data-match="true" style="order: 57;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_129" id="PGSOFT_129" class="favourite-game-btn"><label for="PGSOFT_129"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_129.jpg?v=20230417-1" alt="Win Win Fish Prawn Crab"><div class="link-container"><a class="play-now" data-game="Win Win Fish Prawn Crab" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_129', 'Slots')">MAIN</a></div></div><div class="game-name">Win Win Fish Prawn Crab</div></div><div class="game-item" data-game="The Queen's Banquet" data-match="true" style="order: 37;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_120" id="PGSOFT_120" class="favourite-game-btn"><label for="PGSOFT_120"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_120.jpg?v=20230417-1" alt="The Queen's Banquet"><div class="link-container"><a class="play-now" data-game="The Queen's Banquet" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_120', 'Slots')">MAIN</a></div></div><div class="game-name">The Queen's Banquet</div></div><div class="game-item" data-game="Rooster Rumble" data-match="true" style="order: 29;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_123" id="PGSOFT_123" class="favourite-game-btn"><label for="PGSOFT_123"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_123.jpg?v=20230417-1" alt="Rooster Rumble"><div class="link-container"><a class="play-now" data-game="Rooster Rumble" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_123', 'Slots')">MAIN</a></div></div><div class="game-name">Rooster Rumble</div></div><div class="game-item" data-game="Butterfly Blossom" data-match="true" style="order: 74;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_125" id="PGSOFT_125" class="favourite-game-btn"><label for="PGSOFT_125"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_125.jpg?v=20230417-1" alt="Butterfly Blossom"><div class="link-container"><a class="play-now" data-game="Butterfly Blossom" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_125', 'Slots')">MAIN</a></div></div><div class="game-name">Butterfly Blossom</div></div><div class="game-item" data-game="Destiny of Sun and Moon" data-match="true" style="order: 52;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_121" id="PGSOFT_121" class="favourite-game-btn"><label for="PGSOFT_121"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/PGSOFT_121.jpg?v=20230417-1" alt="Destiny of Sun and Moon"><div class="link-container"><a class="play-now" data-game="Destiny of Sun and Moon" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_121', 'Slots')">MAIN</a></div></div><div class="game-name">Destiny of Sun and Moon</div></div><div class="game-item" data-game="Garuda Gems" data-match="true" style="order: 38;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_122" id="PGSOFT_122" class="favourite-game-btn"><label for="PGSOFT_122"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/garuda-gems.jpg?v=20230417-1" alt="Garuda Gems"><div class="link-container"><a class="play-now" data-game="Garuda Gems" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_122', 'Slots')">MAIN</a></div></div><div class="game-name">Garuda Gems</div></div><div class="game-item" data-game="Fortune Tiger" data-match="true" style="order: 51;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_126" id="PGSOFT_126" class="favourite-game-btn"><label for="PGSOFT_126"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/fortune-tiger.jpg?v=20230417-1" alt="Fortune Tiger"><div class="link-container"><a class="play-now" data-game="Fortune Tiger" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_126', 'Slots')">MAIN</a></div></div><div class="game-name">Fortune Tiger</div></div><div class="game-item" data-game="Oriental Prosperity " data-match="true" style="order: 25;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_112" id="PGSOFT_112" class="favourite-game-btn"><label for="PGSOFT_112"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/oriental-pros.jpg?v=20230417-1" alt="Oriental Prosperity "><div class="link-container"><a class="play-now" data-game="Oriental Prosperity " href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_112', 'Slots')">MAIN</a></div></div><div class="game-name">Oriental Prosperity </div></div><div class="game-item" data-game="Mask Carnival" data-match="true" style="order: 73;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_118" id="PGSOFT_118" class="favourite-game-btn"><label for="PGSOFT_118"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/mask-carnival.jpg?v=20230417-1" alt="Mask Carnival"><div class="link-container"><a class="play-now" data-game="Mask Carnival" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_118', 'Slots')">MAIN</a></div></div><div class="game-name">Mask Carnival</div></div><div class="game-item" data-game="Cocktail Nights" data-match="true" style="order: 8;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_117" id="PGSOFT_117" class="favourite-game-btn"><label for="PGSOFT_117"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/cocktail-nite.jpg?v=20230417-1" alt="Cocktail Nights"><div class="link-container"><a class="play-now" data-game="Cocktail Nights" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_117', 'Slots')">MAIN</a></div></div><div class="game-name">Cocktail Nights</div></div><div class="game-item" data-game="Emoji Riches" data-match="true" style="order: 81;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_114" id="PGSOFT_114" class="favourite-game-btn"><label for="PGSOFT_114"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/emoji-riches.jpg?v=20230417-1" alt="Emoji Riches"><div class="link-container"><a class="play-now" data-game="Emoji Riches" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_114', 'Slots')">MAIN</a></div></div><div class="game-name">Emoji Riches</div></div><div class="game-item" data-game="Spirited Wonders" data-match="true" style="order: 39;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_119" id="PGSOFT_119" class="favourite-game-btn"><label for="PGSOFT_119"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/spirit-wonder.jpg?v=20230417-1" alt="Spirited Wonders"><div class="link-container"><a class="play-now" data-game="Spirited Wonders" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_119', 'Slots')">MAIN</a></div></div><div class="game-name">Spirited Wonders</div></div><div class="game-item" data-game="Legendary Monkey King" data-match="true" style="order: 64;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_107" id="PGSOFT_107" class="favourite-game-btn"><label for="PGSOFT_107"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/lgd-monkey-kg.jpg?v=20230417-1" alt="Legendary Monkey King"><div class="link-container"><a class="play-now" data-game="Legendary Monkey King" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_107', 'Slots')">MAIN</a></div></div><div class="game-name">Legendary Monkey King</div></div><div class="game-item" data-game="Buffalo Win" data-match="true" style="order: 40;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_108" id="PGSOFT_108" class="favourite-game-btn"><label for="PGSOFT_108"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/buffalo-win.jpg?v=20230417-1" alt="Buffalo Win"><div class="link-container"><a class="play-now" data-game="Buffalo Win" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_108', 'Slots')">MAIN</a></div></div><div class="game-name">Buffalo Win</div></div><div class="game-item" data-game="Supermarket Spree" data-match="true" style="order: 20;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_115" id="PGSOFT_115" class="favourite-game-btn"><label for="PGSOFT_115"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/sprmkt-spree.jpg?v=20230417-1" alt="Supermarket Spree"><div class="link-container"><a class="play-now" data-game="Supermarket Spree" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_115', 'Slots')">MAIN</a></div></div><div class="game-name">Supermarket Spree</div></div><div class="game-item" data-game="Raider Jane's Crypt of Fortune" data-match="true" style="order: 55;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_113" id="PGSOFT_113" class="favourite-game-btn"><label for="PGSOFT_113"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/crypt-fortune.jpg?v=20230417-1" alt="Raider Jane's Crypt of Fortune"><div class="link-container"><a class="play-now" data-game="Raider Jane's Crypt of Fortune" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_113', 'Slots')">MAIN</a></div></div><div class="game-name">Raider Jane's Crypt of Fortune</div></div><div class="game-item" data-game="Mermaid Riches" data-match="true" style="order: 61;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_102" id="PGSOFT_102" class="favourite-game-btn"><label for="PGSOFT_102"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/mermaid-riches.jpg?v=20230417-1" alt="Mermaid Riches"><div class="link-container"><a class="play-now" data-game="Mermaid Riches" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_102', 'Slots')">MAIN</a></div></div><div class="game-name">Mermaid Riches</div></div><div class="game-item" data-game="Jurassic Kingdom" data-match="true" style="order: 11;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_110" id="PGSOFT_110" class="favourite-game-btn"><label for="PGSOFT_110"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/jurassic-kdm.jpg?v=20230417-1" alt="Jurassic Kingdom"><div class="link-container"><a class="play-now" data-game="Jurassic Kingdom" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_110', 'Slots')">MAIN</a></div></div><div class="game-name">Jurassic Kingdom</div></div><div class="game-item" data-game="Rise of Apollo" data-match="true" style="order: 28;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_101" id="PGSOFT_101" class="favourite-game-btn"><label for="PGSOFT_101"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/rise-of-apollo.jpg?v=20230417-1" alt="Rise of Apollo"><div class="link-container"><a class="play-now" data-game="Rise of Apollo" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_101', 'Slots')">MAIN</a></div></div><div class="game-name">Rise of Apollo</div></div><div class="game-item" data-game="Heist Stakes" data-match="true" style="order: 54;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_105" id="PGSOFT_105" class="favourite-game-btn"><label for="PGSOFT_105"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/heist-stakes.jpg?v=20230417-1" alt="Heist Stakes"><div class="link-container"><a class="play-now" data-game="Heist Stakes" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_105', 'Slots')">MAIN</a></div></div><div class="game-name">Heist Stakes</div></div><div class="game-item" data-game="Ways of the Qilin" data-match="true" style="order: 7;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_106" id="PGSOFT_106" class="favourite-game-btn"><label for="PGSOFT_106"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/ways-of-qilin.jpg?v=20230417-1" alt="Ways of the Qilin"><div class="link-container"><a class="play-now" data-game="Ways of the Qilin" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_106', 'Slots')">MAIN</a></div></div><div class="game-name">Ways of the Qilin</div></div><div class="game-item" data-game="Wild Bandito" data-match="true" style="order: 3;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_104" id="PGSOFT_104" class="favourite-game-btn"><label for="PGSOFT_104"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/wild-bandito.jpg?v=20230417-1" alt="Wild Bandito"><div class="link-container"><a class="play-now" data-game="Wild Bandito" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_104', 'Slots')">MAIN</a></div></div><div class="game-name">Wild Bandito</div></div><div class="game-item" data-game="Candy Bonanza" data-match="true" style="order: 15;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_100" id="PGSOFT_100" class="favourite-game-btn"><label for="PGSOFT_100"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/candy-bonanza.jpg?v=20230417-1" alt="Candy Bonanza"><div class="link-container"><a class="play-now" data-game="Candy Bonanza" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_100', 'Slots')">MAIN</a></div></div><div class="game-name">Candy Bonanza</div></div><div class="game-item" data-game="Majestic Treasures" data-match="true" style="order: 16;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_95" id="PGSOFT_95" class="favourite-game-btn"><label for="PGSOFT_95"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/majestic-ts.jpg?v=20230417-1" alt="Majestic Treasures"><div class="link-container"><a class="play-now" data-game="Majestic Treasures" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_95', 'Slots')">MAIN</a></div></div><div class="game-name">Majestic Treasures</div></div><div class="game-item" data-game="Crypto Gold" data-match="true" style="order: 27;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_103" id="PGSOFT_103" class="favourite-game-btn"><label for="PGSOFT_103"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/crypto-gold.jpg?v=20230417-1" alt="Crypto Gold"><div class="link-container"><a class="play-now" data-game="Crypto Gold" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_103', 'Slots')">MAIN</a></div></div><div class="game-name">Crypto Gold</div></div><div class="game-item" data-game="Bali Vacation" data-match="true" style="order: 103;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_94" id="PGSOFT_94" class="favourite-game-btn"><label for="PGSOFT_94"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/bali-vacation.jpg?v=20230417-1" alt="Bali Vacation"><div class="link-container"><a class="play-now" data-game="Bali Vacation" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_94', 'Slots')">MAIN</a></div></div><div class="game-name">Bali Vacation</div></div><div class="game-item" data-game="Fortune Ox" data-match="true" style="order: 50;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_98" id="PGSOFT_98" class="favourite-game-btn"><label for="PGSOFT_98"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/fortune-ox.jpg?v=20230417-1" alt="Fortune Ox"><div class="link-container"><a class="play-now" data-game="Fortune Ox" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_98', 'Slots')">MAIN</a></div></div><div class="game-name">Fortune Ox</div></div><div class="game-item" data-game="Opera Dynasty" data-match="true" style="order: 75;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_93" id="PGSOFT_93" class="favourite-game-btn"><label for="PGSOFT_93"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/opera-dynasty.jpg?v=20230417-1" alt="Opera Dynasty"><div class="link-container"><a class="play-now" data-game="Opera Dynasty" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_93', 'Slots')">MAIN</a></div></div><div class="game-name">Opera Dynasty</div></div><div class="game-item" data-game="Guardians of Ice and Fire" data-match="true" style="order: 102;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_91" id="PGSOFT_91" class="favourite-game-btn"><label for="PGSOFT_91"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/gdn-ice-fire.jpg?v=20230417-1" alt="Guardians of Ice and Fire"><div class="link-container"><a class="play-now" data-game="Guardians of Ice and Fire" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_91', 'Slots')">MAIN</a></div></div><div class="game-name">Guardians of Ice and Fire</div></div><div class="game-item" data-game="Galactic Gems" data-match="true" style="order: 43;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_86" id="PGSOFT_86" class="favourite-game-btn"><label for="PGSOFT_86"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/galactic-gems.jpg?v=20230417-1" alt="Galactic Gems"><div class="link-container"><a class="play-now" data-game="Galactic Gems" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_86', 'Slots')">MAIN</a></div></div><div class="game-name">Galactic Gems</div></div><div class="game-item" data-game="Jack Frost's Winter" data-match="true" style="order: 60;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_97" id="PGSOFT_97" class="favourite-game-btn"><label for="PGSOFT_97"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/jack-frosts.jpg?v=20230417-1" alt="Jack Frost's Winter"><div class="link-container"><a class="play-now" data-game="Jack Frost's Winter" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_97', 'Slots')">MAIN</a></div></div><div class="game-name">Jack Frost's Winter</div></div><div class="game-item" data-game="Lucky Neko" data-match="true" style="order: 4;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_89" id="PGSOFT_89" class="favourite-game-btn"><label for="PGSOFT_89"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/lucky-neko.jpg?v=20230417-1" alt="Lucky Neko"><div class="link-container"><a class="play-now" data-game="Lucky Neko" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_89', 'Slots')">MAIN</a></div></div><div class="game-name">Lucky Neko</div></div><div class="game-item" data-game="Jewels of Prosperity" data-match="true" style="order: 69;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_88" id="PGSOFT_88" class="favourite-game-btn"><label for="PGSOFT_88"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/jewels-prosper.jpg?v=20230417-1" alt="Jewels of Prosperity"><div class="link-container"><a class="play-now" data-game="Jewels of Prosperity" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_88', 'Slots')">MAIN</a></div></div><div class="game-name">Jewels of Prosperity</div></div><div class="game-item" data-game="Queen of Bounty" data-match="true" style="order: 33;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_84" id="PGSOFT_84" class="favourite-game-btn"><label for="PGSOFT_84"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/queen-bounty.jpg?v=20230417-1" alt="Queen of Bounty"><div class="link-container"><a class="play-now" data-game="Queen of Bounty" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_84', 'Slots')">MAIN</a></div></div><div class="game-name">Queen of Bounty</div></div><div class="game-item" data-game="Vampire's Charm" data-match="true" style="order: 88;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_58" id="PGSOFT_58" class="favourite-game-btn"><label for="PGSOFT_58"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/vampires-charm.jpg?v=20230417-1" alt="Vampire's Charm"><div class="link-container"><a class="play-now" data-game="Vampire's Charm" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_58', 'Slots')">MAIN</a></div></div><div class="game-name">Vampire's Charm</div></div><div class="game-item" data-game="Secret of Cleopatra" data-match="true" style="order: 101;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_90" id="PGSOFT_90" class="favourite-game-btn"><label for="PGSOFT_90"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/sct-cleopatra.jpg?v=20230417-1" alt="Secret of Cleopatra"><div class="link-container"><a class="play-now" data-game="Secret of Cleopatra" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_90', 'Slots')">MAIN</a></div></div><div class="game-name">Secret of Cleopatra</div></div><div class="game-item" data-game="Fortune Gods" data-match="true" style="order: 94;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_3" id="PGSOFT_3" class="favourite-game-btn"><label for="PGSOFT_3"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/fortune-gods.jpg?v=20230417-1" alt="Fortune Gods"><div class="link-container"><a class="play-now" data-game="Fortune Gods" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_3', 'Slots')">MAIN</a></div></div><div class="game-name">Fortune Gods</div></div><div class="game-item" data-game="Hotpot" data-match="true" style="order: 93;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_28" id="PGSOFT_28" class="favourite-game-btn"><label for="PGSOFT_28"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/hotpot.jpg?v=20230417-1" alt="Hotpot"><div class="link-container"><a class="play-now" data-game="Hotpot" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_28', 'Slots')">MAIN</a></div></div><div class="game-name">Hotpot</div></div><div class="game-item" data-game="Dragon Legend" data-match="true" style="order: 77;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_29" id="PGSOFT_29" class="favourite-game-btn"><label for="PGSOFT_29"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/dragon-legend.jpg?v=20230417-1" alt="Dragon Legend"><div class="link-container"><a class="play-now" data-game="Dragon Legend" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_29', 'Slots')">MAIN</a></div></div><div class="game-name">Dragon Legend</div></div><div class="game-item" data-game="Tree of Fortune" data-match="true" style="order: 65;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_26" id="PGSOFT_26" class="favourite-game-btn"><label for="PGSOFT_26"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/fortune-tree.jpg?v=20230417-1" alt="Tree of Fortune"><div class="link-container"><a class="play-now" data-game="Tree of Fortune" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_26', 'Slots')">MAIN</a></div></div><div class="game-name">Tree of Fortune</div></div><div class="game-item" data-game="Piggy Gold" data-match="true" style="order: 22;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_39" id="PGSOFT_39" class="favourite-game-btn"><label for="PGSOFT_39"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/piggy-gold.jpg?v=20230417-1" alt="Piggy Gold"><div class="link-container"><a class="play-now" data-game="Piggy Gold" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_39', 'Slots')">MAIN</a></div></div><div class="game-name">Piggy Gold</div></div><div class="game-item" data-game="Legend of Hou Yi" data-match="true" style="order: 95;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_34" id="PGSOFT_34" class="favourite-game-btn"><label for="PGSOFT_34"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/legend-of-hou-yi.jpg?v=20230417-1" alt="Legend of Hou Yi"><div class="link-container"><a class="play-now" data-game="Legend of Hou Yi" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_34', 'Slots')">MAIN</a></div></div><div class="game-name">Legend of Hou Yi</div></div><div class="game-item" data-game="Honey Trap of Diao Chan" data-match="true" style="order: 85;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_1" id="PGSOFT_1" class="favourite-game-btn"><label for="PGSOFT_1"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/diaochan.jpg?v=20230417-1" alt="Honey Trap of Diao Chan"><div class="link-container"><a class="play-now" data-game="Honey Trap of Diao Chan" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_1', 'Slots')">MAIN</a></div></div><div class="game-name">Honey Trap of Diao Chan</div></div><div class="game-item" data-game="Prosperity Lion" data-match="true" style="order: 96;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_36" id="PGSOFT_36" class="favourite-game-btn"><label for="PGSOFT_36"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/prosperity-lion.jpg?v=20230417-1" alt="Prosperity Lion"><div class="link-container"><a class="play-now" data-game="Prosperity Lion" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_36', 'Slots')">MAIN</a></div></div><div class="game-name">Prosperity Lion</div></div><div class="game-item" data-game="Gem Saviour Sword" data-match="true" style="order: 84;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_38" id="PGSOFT_38" class="favourite-game-btn"><label for="PGSOFT_38"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/gem-saviour-sword.jpg?v=20230417-1" alt="Gem Saviour Sword"><div class="link-container"><a class="play-now" data-game="Gem Saviour Sword" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_38', 'Slots')">MAIN</a></div></div><div class="game-name">Gem Saviour Sword</div></div><div class="game-item" data-game="Santa's Gift Rush" data-match="true" style="order: 97;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_37" id="PGSOFT_37" class="favourite-game-btn"><label for="PGSOFT_37"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/santas-gift-rush.jpg?v=20230417-1" alt="Santa's Gift Rush"><div class="link-container"><a class="play-now" data-game="Santa's Gift Rush" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_37', 'Slots')">MAIN</a></div></div><div class="game-name">Santa's Gift Rush</div></div><div class="game-item" data-game="Hip Hop Panda" data-match="true" style="order: 91;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_33" id="PGSOFT_33" class="favourite-game-btn"><label for="PGSOFT_33"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/hip-hop-panda.jpg?v=20230417-1" alt="Hip Hop Panda"><div class="link-container"><a class="play-now" data-game="Hip Hop Panda" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_33', 'Slots')">MAIN</a></div></div><div class="game-name">Hip Hop Panda</div></div><div class="game-item" data-game="Plushie Frenzy" data-match="true" style="order: 68;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_25" id="PGSOFT_25" class="favourite-game-btn"><label for="PGSOFT_25"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/plushie-frenzy.jpg?v=20230417-1" alt="Plushie Frenzy"><div class="link-container"><a class="play-now" data-game="Plushie Frenzy" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_25', 'Slots')">MAIN</a></div></div><div class="game-name">Plushie Frenzy</div></div><div class="game-item" data-game="Medusa 2" data-match="true" style="order: 82;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_6" id="PGSOFT_6" class="favourite-game-btn"><label for="PGSOFT_6"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/medusa2.jpg?v=20230417-1" alt="Medusa 2"><div class="link-container"><a class="play-now" data-game="Medusa 2" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_6', 'Slots')">MAIN</a></div></div><div class="game-name">Medusa 2</div></div><div class="game-item" data-game="Medusa" data-match="true" style="order: 87;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_7" id="PGSOFT_7" class="favourite-game-btn"><label for="PGSOFT_7"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/medusa.jpg?v=20230417-1" alt="Medusa"><div class="link-container"><a class="play-now" data-game="Medusa" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_7', 'Slots')">MAIN</a></div></div><div class="game-name">Medusa</div></div><div class="game-item" data-game="Caishen Wins" data-match="true" style="order: 30;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_71" id="PGSOFT_71" class="favourite-game-btn"><label for="PGSOFT_71"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/cai-shen-wins.jpg?v=20230417-1" alt="Caishen Wins"><div class="link-container"><a class="play-now" data-game="Caishen Wins" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_71', 'Slots')">MAIN</a></div></div><div class="game-name">Caishen Wins</div></div><div class="game-item" data-game="Gem Saviour" data-match="true" style="order: 80;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_2" id="PGSOFT_2" class="favourite-game-btn"><label for="PGSOFT_2"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/gem-saviour.jpg?v=20230417-1" alt="Gem Saviour"><div class="link-container"><a class="play-now" data-game="Gem Saviour" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_2', 'Slots')">MAIN</a></div></div><div class="game-name">Gem Saviour</div></div><div class="game-item" data-game="Hood vs Wolf" data-match="true" style="order: 92;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_18" id="PGSOFT_18" class="favourite-game-btn"><label for="PGSOFT_18"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/hood-wolf.jpg?v=20230417-1" alt="Hood vs Wolf"><div class="link-container"><a class="play-now" data-game="Hood vs Wolf" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_18', 'Slots')">MAIN</a></div></div><div class="game-name">Hood vs Wolf</div></div><div class="game-item" data-game="Thai River Wonders" data-match="true" style="order: 53;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_92" id="PGSOFT_92" class="favourite-game-btn"><label for="PGSOFT_92"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/thai-river.jpg?v=20230417-1" alt="Thai River Wonders"><div class="link-container"><a class="play-now" data-game="Thai River Wonders" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_92', 'Slots')">MAIN</a></div></div><div class="game-name">Thai River Wonders</div></div><div class="game-item" data-game="Circus Delight" data-match="true" style="order: 100;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_80" id="PGSOFT_80" class="favourite-game-btn"><label for="PGSOFT_80"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/circus-delight.jpg?v=20230417-1" alt="Circus Delight"><div class="link-container"><a class="play-now" data-game="Circus Delight" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_80', 'Slots')">MAIN</a></div></div><div class="game-name">Circus Delight</div></div><div class="game-item" data-game="Treasures of Aztec" data-match="true" style="order: 6;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_87" id="PGSOFT_87" class="favourite-game-btn"><label for="PGSOFT_87"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/treasures-aztec.jpg?v=20230417-1" alt="Treasures of Aztec"><div class="link-container"><a class="play-now" data-game="Treasures of Aztec" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_87', 'Slots')">MAIN</a></div></div><div class="game-name">Treasures of Aztec</div></div><div class="game-item" data-game="Genie's 3 Wishes" data-match="true" style="order: 66;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_85" id="PGSOFT_85" class="favourite-game-btn"><label for="PGSOFT_85"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/genies-wishes.jpg?v=20230417-1" alt="Genie's 3 Wishes"><div class="link-container"><a class="play-now" data-game="Genie's 3 Wishes" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_85', 'Slots')">MAIN</a></div></div><div class="game-name">Genie's 3 Wishes</div></div><div class="game-item" data-game="Wild Fireworks" data-match="true" style="order: 48;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_83" id="PGSOFT_83" class="favourite-game-btn"><label for="PGSOFT_83"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/wild-fireworks.jpg?v=20230417-1" alt="Wild Fireworks"><div class="link-container"><a class="play-now" data-game="Wild Fireworks" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_83', 'Slots')">MAIN</a></div></div><div class="game-name">Wild Fireworks</div></div><div class="game-item" data-game="Dreams of Macau" data-match="true" style="order: 12;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_79" id="PGSOFT_79" class="favourite-game-btn"><label for="PGSOFT_79"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/dreams-of-macau.jpg?v=20230417-1" alt="Dreams of Macau"><div class="link-container"><a class="play-now" data-game="Dreams of Macau" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_79', 'Slots')">MAIN</a></div></div><div class="game-name">Dreams of Macau</div></div><div class="game-item" data-game="Phoenix Rises" data-match="true" style="order: 23;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_82" id="PGSOFT_82" class="favourite-game-btn"><label for="PGSOFT_82"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/phoenix-rises.jpg?v=20230417-1" alt="Phoenix Rises"><div class="link-container"><a class="play-now" data-game="Phoenix Rises" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_82', 'Slots')">MAIN</a></div></div><div class="game-name">Phoenix Rises</div></div><div class="game-item" data-game="Captain's Bounty" data-match="true" style="order: 35;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_54" id="PGSOFT_54" class="favourite-game-btn"><label for="PGSOFT_54"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/captains-bounty.jpg?v=20230417-1" alt="Captain's Bounty"><div class="link-container"><a class="play-now" data-game="Captain's Bounty" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_54', 'Slots')">MAIN</a></div></div><div class="game-name">Captain's Bounty</div></div><div class="game-item" data-game="Mahjong Ways 2" data-match="true" style="order: 1;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_74" id="PGSOFT_74" class="favourite-game-btn"><label for="PGSOFT_74"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/mahjong-ways2.jpg?v=20230417-1" alt="Mahjong Ways 2"><div class="link-container"><a class="play-now" data-game="Mahjong Ways 2" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_74', 'Slots')">MAIN</a></div></div><div class="game-name">Mahjong Ways 2</div></div><div class="game-item" data-game="Ganesha Fortune" data-match="true" style="order: 9;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_75" id="PGSOFT_75" class="favourite-game-btn"><label for="PGSOFT_75"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/ganesha-fortune.jpg?v=20230417-1" alt="Ganesha Fortune"><div class="link-container"><a class="play-now" data-game="Ganesha Fortune" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_75', 'Slots')">MAIN</a></div></div><div class="game-name">Ganesha Fortune</div></div><div class="game-item" data-game="Egypt's Book of Mystery" data-match="true" style="order: 47;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_73" id="PGSOFT_73" class="favourite-game-btn"><label for="PGSOFT_73"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/egypts-book-mystery.jpg?v=20230417-1" alt="Egypt's Book of Mystery"><div class="link-container"><a class="play-now" data-game="Egypt's Book of Mystery" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_73', 'Slots')">MAIN</a></div></div><div class="game-name">Egypt's Book of Mystery</div></div><div class="game-item" data-game="Bikini Paradise" data-match="true" style="order: 13;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_69" id="PGSOFT_69" class="favourite-game-btn"><label for="PGSOFT_69"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/bikini-paradise.jpg?v=20230417-1" alt="Bikini Paradise"><div class="link-container"><a class="play-now" data-game="Bikini Paradise" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_69', 'Slots')">MAIN</a></div></div><div class="game-name">Bikini Paradise</div></div><div class="game-item" data-game="Candy Burst" data-match="true" style="order: 36;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_70" id="PGSOFT_70" class="favourite-game-btn"><label for="PGSOFT_70"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/candy-burst.jpg?v=20230417-1" alt="Candy Burst"><div class="link-container"><a class="play-now" data-game="Candy Burst" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_70', 'Slots')">MAIN</a></div></div><div class="game-name">Candy Burst</div></div><div class="game-item" data-game="Shaolin Soccer" data-match="true" style="order: 99;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_67" id="PGSOFT_67" class="favourite-game-btn"><label for="PGSOFT_67"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/shaolin-soccer.jpg?v=20230417-1" alt="Shaolin Soccer"><div class="link-container"><a class="play-now" data-game="Shaolin Soccer" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_67', 'Slots')">MAIN</a></div></div><div class="game-name">Shaolin Soccer</div></div><div class="game-item" data-game="Gem Saviour Conquest" data-match="true" style="order: 32;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_62" id="PGSOFT_62" class="favourite-game-btn"><label for="PGSOFT_62"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/gem-saviour-conquest.jpg?v=20230417-1" alt="Gem Saviour Conquest"><div class="link-container"><a class="play-now" data-game="Gem Saviour Conquest" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_62', 'Slots')">MAIN</a></div></div><div class="game-name">Gem Saviour Conquest</div></div><div class="game-item" data-game="Reel Love" data-match="true" style="order: 78;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_20" id="PGSOFT_20" class="favourite-game-btn"><label for="PGSOFT_20"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/reel-love.jpg?v=20230417-1" alt="Reel Love"><div class="link-container"><a class="play-now" data-game="Reel Love" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_20', 'Slots')">MAIN</a></div></div><div class="game-name">Reel Love</div></div><div class="game-item" data-game="Fortune Mouse" data-match="true" style="order: 89;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_68" id="PGSOFT_68" class="favourite-game-btn"><label for="PGSOFT_68"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/fortune-mouse.jpg?v=20230417-1" alt="Fortune Mouse"><div class="link-container"><a class="play-now" data-game="Fortune Mouse" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_68', 'Slots')">MAIN</a></div></div><div class="game-name">Fortune Mouse</div></div><div class="game-item" data-game="Dragon Hatch" data-match="true" style="order: 18;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_57" id="PGSOFT_57" class="favourite-game-btn"><label for="PGSOFT_57"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/dragon-hatch.jpg?v=20230417-1" alt="Dragon Hatch"><div class="link-container"><a class="play-now" data-game="Dragon Hatch" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_57', 'Slots')">MAIN</a></div></div><div class="game-name">Dragon Hatch</div></div><div class="game-item" data-game="Mahjong Ways" data-match="true" style="order: 2;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_65" id="PGSOFT_65" class="favourite-game-btn"><label for="PGSOFT_65"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/mahjong-ways.jpg?v=20230417-1" alt="Mahjong Ways"><div class="link-container"><a class="play-now" data-game="Mahjong Ways" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_65', 'Slots')">MAIN</a></div></div><div class="game-name">Mahjong Ways</div></div><div class="game-item" data-game="Dragon Tiger Luck" data-match="true" style="order: 70;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_63" id="PGSOFT_63" class="favourite-game-btn"><label for="PGSOFT_63"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/dragon-tiger-luck.jpg?v=20230417-1" alt="Dragon Tiger Luck"><div class="link-container"><a class="play-now" data-game="Dragon Tiger Luck" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_63', 'Slots')">MAIN</a></div></div><div class="game-name">Dragon Tiger Luck</div></div><div class="game-item" data-game="Leprechaun Riches" data-match="true" style="order: 41;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_60" id="PGSOFT_60" class="favourite-game-btn"><label for="PGSOFT_60"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/leprechaun-riches.jpg?v=20230417-1" alt="Leprechaun Riches"><div class="link-container"><a class="play-now" data-game="Leprechaun Riches" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_60', 'Slots')">MAIN</a></div></div><div class="game-name">Leprechaun Riches</div></div><div class="game-item" data-game="Double Fortune" data-match="true" style="order: 71;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_48" id="PGSOFT_48" class="favourite-game-btn"><label for="PGSOFT_48"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/double-fortune.jpg?v=20230417-1" alt="Double Fortune"><div class="link-container"><a class="play-now" data-game="Double Fortune" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_48', 'Slots')">MAIN</a></div></div><div class="game-name">Double Fortune</div></div><div class="game-item" data-game="The Great Icescape" data-match="true" style="order: 17;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_53" id="PGSOFT_53" class="favourite-game-btn"><label for="PGSOFT_53"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/the-great-icescape.jpg?v=20230417-1" alt="The Great Icescape"><div class="link-container"><a class="play-now" data-game="The Great Icescape" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_53', 'Slots')">MAIN</a></div></div><div class="game-name">The Great Icescape</div></div><div class="game-item" data-game="Ganesha Gold" data-match="true" style="order: 44;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_42" id="PGSOFT_42" class="favourite-game-btn"><label for="PGSOFT_42"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/ganesha-gold.jpg?v=20230417-1" alt="Ganesha Gold"><div class="link-container"><a class="play-now" data-game="Ganesha Gold" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_42', 'Slots')">MAIN</a></div></div><div class="game-name">Ganesha Gold</div></div><div class="game-item" data-game="Jungle Delight" data-match="true" style="order: 76;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_40" id="PGSOFT_40" class="favourite-game-btn"><label for="PGSOFT_40"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/jungle-delight.jpg?v=20230417-1" alt="Jungle Delight"><div class="link-container"><a class="play-now" data-game="Jungle Delight" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_40', 'Slots')">MAIN</a></div></div><div class="game-name">Jungle Delight</div></div><div class="game-item" data-game="Flirting Scholar" data-match="true" style="order: 98;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_61" id="PGSOFT_61" class="favourite-game-btn"><label for="PGSOFT_61"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/flirting-scholar.jpg?v=20230417-1" alt="Flirting Scholar"><div class="link-container"><a class="play-now" data-game="Flirting Scholar" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_61', 'Slots')">MAIN</a></div></div><div class="game-name">Flirting Scholar</div></div><div class="game-item" data-game="Muay Thai Champion" data-match="true" style="order: 63;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_64" id="PGSOFT_64" class="favourite-game-btn"><label for="PGSOFT_64"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/muay-thai-champion.jpg?v=20230417-1" alt="Muay Thai Champion"><div class="link-container"><a class="play-now" data-game="Muay Thai Champion" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_64', 'Slots')">MAIN</a></div></div><div class="game-name">Muay Thai Champion</div></div><div class="game-item" data-game="Journey to the Wealth" data-match="true" style="order: 86;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_50" id="PGSOFT_50" class="favourite-game-btn"><label for="PGSOFT_50"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/journey-to-the-wealth.jpg?v=20230417-1" alt="Journey to the Wealth"><div class="link-container"><a class="play-now" data-game="Journey to the Wealth" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_50', 'Slots')">MAIN</a></div></div><div class="game-name">Journey to the Wealth</div></div><div class="game-item" data-game="Ninja vs Samurai" data-match="true" style="order: 56;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_59" id="PGSOFT_59" class="favourite-game-btn"><label for="PGSOFT_59"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/ninja-vs-samurai.jpg?v=20230417-1" alt="Ninja vs Samurai"><div class="link-container"><a class="play-now" data-game="Ninja vs Samurai" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_59', 'Slots')">MAIN</a></div></div><div class="game-name">Ninja vs Samurai</div></div><div class="game-item" data-game="Emperors Favour" data-match="true" style="order: 58;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_44" id="PGSOFT_44" class="favourite-game-btn"><label for="PGSOFT_44"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/emperor_favour.jpg?v=20230417-1" alt="Emperors Favour"><div class="link-container"><a class="play-now" data-game="Emperors Favour" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_44', 'Slots')">MAIN</a></div></div><div class="game-name">Emperors Favour</div></div><div class="game-item" data-game="Symbols of Egypt" data-match="true" style="order: 90;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_41" id="PGSOFT_41" class="favourite-game-btn"><label for="PGSOFT_41"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/symbols-of-egypt.jpg?v=20230417-1" alt="Symbols of Egypt"><div class="link-container"><a class="play-now" data-game="Symbols of Egypt" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_41', 'Slots')">MAIN</a></div></div><div class="game-name">Symbols of Egypt</div></div><div class="game-item" data-game="Mr. Hallow-Win" data-match="true" style="order: 79;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_35" id="PGSOFT_35" class="favourite-game-btn"><label for="PGSOFT_35"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/mr-hallow-win.jpg?v=20230417-1" alt="Mr. Hallow-Win"><div class="link-container"><a class="play-now" data-game="Mr. Hallow-Win" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_35', 'Slots')">MAIN</a></div></div><div class="game-name">Mr. Hallow-Win</div></div><div class="game-item" data-game="Win Win Won" data-match="true" style="order: 83;"><input type="checkbox" data-provider="PGSOFT" value="PGSOFT_24" id="PGSOFT_24" class="favourite-game-btn"><label for="PGSOFT_24"></label><div class="wrapper-container"><img src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/win-win-won2.jpg?v=20230417-1" alt="Win Win Won"><div class="link-container"><a class="play-now" data-game="Win Win Won" href="javascript:openNewTab('/dispatch/game/PGSOFT/Desktop/PGSOFT_24', 'Slots')">MAIN</a></div></div><div class="game-name">Win Win Won</div></div></div>




    <div class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="site-footer-info">
                        <ul class="footer-links">
                                <li data-active="false">
                                    <a href="/info//">
                                        Daftar Situs Slot Pulsa Terbaik Agen TIC88 Jackpot
                                    </a>
                                </li>
                        </ul>
                        </div>
                    <hr />
                    <div class="site-footer-info">
                        <div>
                            <h4>Metode Pembayaran</h4>
                            <ul class="footer-bank-list">
                                        <li><img src="https://api2-t8r.tr8zgames.com/images/BNI_3d30334c-d871-46fb-80b3-0fcb12f99b87_1677349763390.png" /></li>
                                        <li><img src="https://api2-t8r.tr8zgames.com/images/BRI_a458ab91-91a3-49ac-98b3-1bfc5d1966bd_1677505864343.png" /></li>
                                        <li><img src="https://api2-t8r.tr8zgames.com/images/GOPAY_6fbfbc88-bd3a-42ab-b4e8-d35645f9cccd_1679683577987.png" /></li>
                                        <li><img src="https://api2-t8r.tr8zgames.com/images/MANDIRI_ec4427ff-2e6e-4657-a2fe-b3702bc15e7c_1682012334040.png" /></li>
                                        <li><img src="https://api2-t8r.tr8zgames.com/images/PERMATA_4d05ecbe-98e5-47db-a562-21bcf4c24565_1669271085050.png" /></li>
                            </ul>
                        </div>
                        <div>
                            <h4>Hubungi Kami</h4>
                            <ul class="social-media-list">
                                    <li>
                                        <a href="https://t.me/TIC88official" target="_blank" rel="nofollow">
                                            <img src="https://api2-t8r.tr8zgames.com/images/Telegram_fd6804d7-e59d-4012-ac10-07b36c2164e2_1677516566663.png" />
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://api.whatsapp.com/send?phone=6289505661821" target="_blank" rel="nofollow">
                                            <img src="https://api2-t8r.tr8zgames.com/images/Whatsapp_e5de0900-0421-4617-8765-3298a843f85b_1669447888240.png" />
                                        </a>
                                    </li>
                            </ul>
                        </div>
                    </div>
                    <hr />
                </div>
            </div>

                <div class="row">
                    <div class="col-lg-12">
                        <ul class="contact-list">
                                <li>
                                    <a href="https://api.whatsapp.com/send?phone=6289505661821" target="_blank" rel="noopener nofollow">
                                        <i>
                                            <img alt="Contact" loading="lazy" src="//zm-cdn.zoomwl.com/Images/communications/whatsapp.svg?v=20230417-1" />
                                        </i>
                                        6289505661821
                                    </a>
                                </li>
                        </ul>
                    </div>
                </div>

            <div class="row">
                <div class="col-lg-12 site-description">
                    <h1>SITUS SLOT DEPOSIT 5000 PULSA TRI TANPA POTONGAN GACOR | TIC88</h1>
<p><a href="https://www.androidfanatic.com">TIC88</a> yaitu web judi slot pulsa tanpa potongan juga tempat bermain slot yang kini menjadi salah satu kegiatan yang banyak dilakukan oleh masyarakat di Indonesia. Para permainan tersebut masing-masing pemain dapat bermain dengan ratusan game. Saat ini para pemain tidak perlu bingung mencari tempat untuk bermain judi slot deposit 5000. Berbagai situs di Internet sudah menyediakan permainan tersebut. Itulah mengapa masyarakat di Indonesia sangat mudah untuk mengakses permainan judi slot. Namun dengan berbagai pilihan situs yang ada di internet membuat para pemain harus bisa memilih dengan teliti. Apabila nantinya kalian salah pilih maka hasil yang diperoleh saat bermain menjadi kurang menguntungkan. Setiap pemain pastinya sudah tahu bahwa permainan tersebut mampu memberikan keuntungan sampai ratusan juta rupiah. Oleh sebab itu, pilihlah situs slot deposit pulsa tri 5000 resmi TIC88.</p>
<p>Ada hal menarik yang perlu kalian ketahui mengenai situs TIC88 resmi. Di dalamnya para pemain dapat menikmati game-game dengan visual yang menarik. Bahkan, ratusan game tersebut juga tersedia oleh berbagai provider. Hal tersebut pastinya akan membuat para pemain merasa nyaman. Selain menyajikan visual terbaik melalui tema dan simbol di dalamnya, masing-masing pemain juga mampu merasakan keseruan dengan fitur-fitur yang tersedia. Oleh karena itu, tidak heran apabila situs TIC88 resmi sampai saat ini menjadi andalan untuk bertaruh judi slot. Itulah mengapa kini para pemula sebaiknya daftar secara tepat situs TIC88 resmi.</p>
<p>Join Member Situs Slot Deposit Pulsa 5000 Agen TIC88 Resmi</p>
<p>Gabung menjadi member agen judi slot deposit 5000 terbaik merupakan pilihan tepat untuk setiap pemain. Kalian pastinya ingin bermain dengan agen yang memberikan untung besar. Tentu saja agen TIC88 resmi dapat mewujudkan hal tersebut. Di dalamnya pemain mampu menangkan taruhan dengan jackpot jutaan rupiah. Bahkan, total keuntungan yang diperoleh mencapai ratusan juta rupiah. Hal tersebut pastinya menarik perhatian bagi masyarakat di Indonesia. Bertaruh di dalamnya juga tidak memerlukan modal besar. Setelah daftar member nantinya kalian bisa deposit dengan nominal yang terjangkau bagi siapa saja. Agen TIC88 resmi dan terpercaya tidak hanya berikan kalian kemenangan dengan jackpot jutaan rupiah saja. Tetapi, sampai sekarang para pemain juga bisa raih bonus-bonus menarik. Tidak heran bila kini para pemain di Indonesia berlomba-lomba untuk dapatkan keuntungan maksimal bersama agen judi slot deposit pulsa 5000 terpercaya.</p>
<p>Apabila kalian ingin bermain bersama agen <a href="https://www.androidfanatic.com">slot deposit pulsa tri 5000</a> resmi, maka pastikan untuk daftar member. Siapapun tidak perlu khawatir bagaimana cara untuk bisa bergabung dan bermain di dalamnya. Proses yang begitu mudah tentu dapat dilakukan oleh siapa saja. Daftar member pada agen judi TIC88 sangat fleksibel. Pemain dapat mendaftar kapan saja dan dari mana saja. Kalian hanya perlu siapkan smartphone yang terkoneksi dengan internet. Agen slot deposit 5000 resmi memproses pendaftaran setiap member dengan cepat karena online 24 jam nonstop. Oleh karena itu, kalian bisa juga daftar sekarang untuk bermain dengan setiap game di dalamnya. Jika belum tahu mengenai cara daftar tersebut, maka simak caranya berikut ini dengan baik.</p>
<p>- Cara pertama tentunya pemain harus memilih agen dengan tepat karena banyakan pilihan saat ini. Hal ini masih jadi perhatian penting bagi siapa saja. Apabila nantinya kalian asal pilih maka belum tentu agen yang dipilih memberikan hasil maksimal. Hanya agen slot deposit 5000 resmi TIC88 yang berikan keuntungan hingga ratusan juta rupiah. Oleh sebab itu, berhati-hati dalam menentukan pilihan nantinya.</p>
<p>- Cara kedua para pemain dapat memilih menu daftar pada agen TIC88 resmi. Dari menu tersebut masing-masing pastinya wajib mengisi data dengan valid. Data-data yang kalian isi tentu tidak banyak. Namun, pastikan mengisi secara lengkap. Jangan sampai kalian salah dalam mengisi data-data di dalamnya. Pastikan juga bahwa data yang digunakan masih aktif sampai saat ini.</p>
<p>- Cara ketiga adalah klik kolom "Daftar" pada bagian paling bawah. Setelah melakukan hal tersebut maka kalian tentu sudah berhasil mendaftar sebagai member di dalamnya. Dengan ID yang diperoleh kalian dapat bertaruh pada tiap-tiap game di dalamnya.</p>
<p>- Cara keempat yaitu pastikan untuk login terlebih dahulu setelah menyelesaikan pendaftaran akun. Hal ini dilakukan untuk memastikan jika akun tersebut sudah bisa digunakan. Tentunya kalian terdaftar sebagai member resmi agen slot deposit 5000 terpercaya TIC88.</p>
<h2>Kumpulan Provider Terlaris Situs Slot Deposit Pulsa Tri 5000 Resmi</h2>
<p>Di dalam <a href="https://www.androidfanatic.com">situs slot</a> deposit tri tanpa potongan 5000 resmi tentu saja kalian bisa nikmati bermacam-macam game dari berbagai provider terbaik. Dari masing-masing provider yang tersedia pada situs TIC88 resmi kalian bisa bawa pulang untung jutaan rupiah. Sebagian pemain tentu memilih untuk bertaruh dengan provider terpopuler. Sebab, peluang untuk menang bahkan mendapatkan jackpot sudah pasti tinggi. Jika kalian ingin tahu berbagai pilihan terbaik provider tersebut, maka akan kami berikan daftarnya. Berikut merupakan provider-provider terlaris pada situs judi slot pulsa. Simak baik-baik untuk mengetahui secara lengkap informasi mengenai provider tersebut.</p>
<p>1. TIC88 Habanero</p>
<p>Habanero merupakan penyedia game judi slot yang kini ramai dinikmati oleh para pemain di situs TIC88 terpercaya. Tentu saja habanero memiliki berbagai keunggulan di dalamnya. Hal itu menjadikan setiap pemain tidak akan mudah merasa bosan. Perlu kalian ketahui bahwa habanero dapat dinikmati dengan berbagai pilihan bahasa. Oleh karena itu, masyarakat di Indonesia dapat dengan mudah untuk memahami berbagai kata di dalamnya. Selain itu, provider slot satu ini juga memiliki grafis yang tidak perlu diragukan lagi. Tiap-tiap pemain bahkan bisa nikmati berbagai game degan tema yang sangat menarik. Tidak hanya itu saja, namun simbol-simbol yang tersedia pada setiap game juga menambah keseruan saat bertaruh. Itulah mengapa habanero begitu banyak dinikmati para pemain hingga saat ini. Tetapi, habanero banyak dilirik oleh para member situs TIC88 bukan hanya karena itu saja. Melainkan di dalamnya kalian juga bisa menangkan jackpot besar. Salah satu yang menarik adalah jackpot progresif. Jadi, tidak perlu khawatir bertaruh dengan game-game dari habanero melalui situs slot deposit pulsa 5000 resmi.</p>
<p>2. TIC88 Pragmatic Play</p>
<p>Pragmatic play pastinya sudah tidak asing bagi banyak pemain di Indonesia. Situs judi TIC88 tentu menjadi salah satu terbaik untuk meraih untung besar bermain bersama pragmatic play. Ada beberapa hal yang perlu kalian ketahui mengenai provider tersebut. Pragmatic play sendiri memiliki deretan game dengan jumlah lebih dari ratusan judul. Hal tersebut memberikan kesempatan bagi tiap-tiap member untuk menikmati berbagai keseruan setiap harinya. Game-game yang dimiliki oleh pragmatic play bahkan mempunyai visual berkualitas tinggi. Oleh karena itu, kalian tidak akan jenuh apabila nantinya habiskan waktu bermain bersama pragmatic play hingga berjam-jam. Selain itu, pragmatic play juga menawarkan demo pada beberapa game di dalamnya. Setiap member TIC88 resmi tentu saja dapat mencoba permainan tersebut secara gratis. Tentunya hal tersebut membuat nyaman para pemain. Bagi para pemula kalian bisa berlatih untuk menangkan taruhan dengan mudah. Namun, seperti yang disampaikan sebelumnya bahwa tiap-tiap pemain dapat raih untung besar. Di sini kalian mampu menangkan berbagai jackpot. Dalam beberapa pilihan game terbaik kalian bahkan bisa dapatkan jackpot dengan berbagai macam. Oleh karena itu, tidak diragukan lagi bila setiap member mampu raih keuntungan hingga ratusan juta rupiah.</p>
<p>3. TIC88 PG Soft</p>
<p>Situs judi slot deposit pulsa 5000 tentu memiliki berbagai pilihan provider terlaris lainnya. Salah satu diantaranya yaitu PG soft. Provider tersebut memberikan pemain keseruan dalam menikmati setiap game. Kalian bisa temukan berbagai tema menarik pada tiap-tiap game dari PG soft. Perlu kalian pahami jika provider tersebut memberikan grafis yang begitu memukau. Tentu saja siapapun akan merasa nyaman ketika melihat tampilan game saat bermain. Tidak heran apabila kini PG soft juga banyak dipilih oleh sebagian besar member situs TIC88 resmi dan terpercaya. Selain itu, berbagai game dari PG soft juga memiliki tema Asia yang begitu khas. Maka dari itu, jangan lewatkan berbagai keseruan dari game-game yang dimiliki oleh PG soft.</p>
<p>4. TIC88 Microgaming</p>
<p>Saat ini provider microgaming juga bisa jadi pilihan tepat kalian saat bermain bersama situs TIC88 resmi. Mengapa microgaming begitu populer hingga saat ini? Meskipun tersedia banyak pilihan provider pada situs TIC88 tentunya microgaming juga memiliki keunggulan tersendiri. Hal ini yang menjadikan setiap pemain bisa bermain dengan merasakan berbagai keseruan. Microgaming tentu saja memiliki bermacam-macam game dengan RTP tinggi. Peluang untuk menang dari tiap-tiap game tersebut pastinya tinggi. Bahkan, bayaran yang diberikan untuk kalian juga tidak kecil. Itulah mengapa kalian bisa raih untung besar di dalamnya. Selain itu, jackpot yang tersedia juga memberikan untung besar. Pastikan tidak melewatkan berbagai game terbaik dari microgaming saat bertaruh bersama situs TIC88 terpercaya.</p>
<h3>Tips Bertaruh Judi Slot Deposit Pulsa 5000 Terpercaya Menang Jackpot</h3>
<p>Ada beberapa hal yang pastinya perlu diperhatikan saat bermain <a href="https://www.androidfanatic.com">judi slot</a> pulsa. Pemain sebaiknya tidak hanya asal bermain saja meskipun sudah daftar member agen TIC88 terpercaya. Untuk mendapatkan kemenangan dengan untung besar maka kalian perlu bermain menggunakan strategi yang tepat. Jika nantinya hanya bertaruh secara asal, maka hasil menang taruhan tersebut tidak akan memberikan untung maksimal. Itulah sebabnya kami akan berikan beberapa tips untuk bermain bersama agen TIC88 terpercaya. Perhatikan dan pahami berbagai tips tersebut untuk menangkan taruhan dengan mudah serta mendapatkan jackpot.</p>
<p>1. Tips pertama adalah pemain harus tahu berbagai hal mengenai permainan judi slot. Tentu saja permainan ini bukan hanya sekedar pasang taruhan dan memutar gulungan secara berulang-ulang. Tetapi, ada berbagai hal lainnya yang perlu dipahami untuk bisa menangkan taruhan dengan mudah. Pastinya kalian juga bisa mendapatkan jackpot terbesar. Beberapa hal tersebut seperti simbol, paylines, RTP, fitur, dan lain-lain. Setiap game tentunya memiliki ciri khas tersendiri. Oleh karena itu, jangan hanya memilih secara asal tanpa memperhatikan hal-hal tersebut.</p>
<p>2. Tips kedua adalah memilih game slot dengan win rate tinggi. Agen TIC88 tentu memiliki ratusan game dengan win rate yang beragam. Jika kalian memilih game-game dengan win rate tinggi tentunya peluang untuk menang semakin besar. Hal itu pastinya juga mempengaruhi hasil yang diperoleh saat bertaruh bersama agen TIC88. Mendapatkan jackpot bahkan wax win tentu menjadi semakin mudah.</p>
<p>3. Tips ketiga ialah bermain dengan game slot yang sudah dikuasai. Dari sekian banyak pilihan game agen TIC88 pastinya beberapa diantaranya bisa menjadi andalan tepat. Jangan hanya sembarangan memilih game untuk bertaruh. Jika nantinya kalian bermain dengan game-game yang belum dikuasai tentunya kesempatan menang justru semakin kecil.</p>
<p>4. Tips keempat ialah bertaruh menggunakan pola slot jitu. Sebagian besar member agen TIC88 tentu tidak hanya mengandalkan keberuntungan saja. Namun, bermain menggunakan pola jitu juga bisa menjadi cara tepat untuk menang dengan mudah. Hasil dari tiap-tiap taruhan pada agen TIC88 pastinya memberikan untung maksimal. Hanya saja untuk bermain dengan pola jitu para pemain juga harus mencari sumber terpercaya. Bila nantinya kalian asal-asalan dalam memilih sumber pola slot maka kemenangan tidak akan diperoleh secara mudah. Bahkan, jackpot pada agen TIC88 akan terlewatkan. Itulah mengapa tiap-tiap member agen judi TIC88 harus pintar dalam memilih sumber pola slot tersebut.</p>
<h4>Game Terbaik dan Menguntungkan Situs Judi Tri 88 Resmi No 1 di Indonesia</h4>
<p>Kesempatan untuk menangkan uang hingga ratusan juta rupiah tentu juga diperoleh dengan memilih game terbaik. Pada situs judi <a href="https://www.androidfanatic.com">slot deposit pulsa</a> 5000 kalian dapat temukan berbagai pilihan game paling menguntungkan. Tentunya kalian tidak boleh lewatkan kesempatan untuk bermain di dalamnya. Lantas, game-game apa saja yang menjadi pilihan terbaik pada situs TIC88 terpercaya? Di bawah ini adalah berbagai daftar mengenai game-game tersebut. Oleh karena itu, simak baik-baik.</p>
<ul>
    <li>Koi Gate</li>
</ul>
<p>Koi gate merupakan game RTP tinggi yang dimiliki oleh provider slot pulsa habanero. Game tersebut pastinya begitu populer pada situs TIC88 resmi. Di dalamnya kalian dapat menikmati berbagai simbol menarik serta visual terbaik. Hal tersebut tentu saja memberikan pengalaman bermain terbaik bagi setiap pemain. Bahkan, di dalam situs judi TIC88 kalian bisa raih untung besar saat bermain bersama koi gate. Dengan jackpot progresif yang tersedia di dalamnya maka kalian bisa raih untung lebih dari jutaan rupiah. Tidak mengherankan apabila kini koi gate selalu menjadi andalan bagi sebagian besar member situs TIC88 resmi.</p>
<ul>
    <li>Gates of Olympus</li>
</ul>
<p>Gates of olympus tentunya bisa jadi andalan untuk dapatkan uang jutaan rupiah dengan mudah. Game satu ini bukan hanya memberikan jackpot besar bagi setiap member situs TIC88 resmi. Namun, di dalam game tersebut pemain juga bisa nikmati fitur free spin setiap hari. Fitur tersebut memberikan kesempatan bagi siapa saja untuk bermain secara gratis tanpa saldo sedikitpun. Tidak heran bila member situs slot deposit 5000 Resmi begitu tertarik untuk bermain bersama gates of olympus.</p>
<ul>
    <li>Thunderstruck II</li>
</ul>
<p>Game terbaik lainnya dari situs alot deposit 5000 terpercaya yaitu thunderstruck II. Game tersebut kini juga banyak dicari dan dimainkan oleh sebagian besar member situs slot deposit 5000 terpercaya. Masing-masing pemain pastinya bukan hanya mendapatkan bayaran tinggi. Namun, jackpot dari game tersebut juga tinggi. Hal itu memberikan kesempatan bagi siapa saja untuk bawa pulang untung hingga ratusan juta rupiah. Jadi, tidak perlu ragu apabila nantinya kalian juga tertarik untuk bermain thunderstruck II pada situs judi slot deposit 5000 terpercaya.</p>
<p>Itulah bermacam-macam game terbaik situs slot <a href="https://www.androidfanatic.com">deposit 5000</a> yang bisa jadi pilihan telat saat bertaruh. Pilih salah satu diantaranya dan memenangkan taruhan dengan mendapatkan uang lebih dari jutaan rupiah setiap harinya. Oleh sebab itu, jangan salah daftar member situs judi slot pulsa. Daftar segera bersama situs TIC88 dan raih hasil maksimal di dalamnya.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="site-copyright-container">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="site-footer-info">
                        <div class="copyright">
                            ©2023 TIC88. All rights reserved | 18+
                        </div>
                        <div class="license-list">
                            <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/licenses/gambling-commission.svg?v=20230417-1" />
                            <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/licenses/18-plus.svg?v=20230417-1" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="site-footer-navbar navbar-fixed-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul>
                        <li data-active="false">
                            <a href="../../dashboard/">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/home.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/home.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/home.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/home-active.png?v=20230417-1);" /></picture>
                                Beranda
                            </a>
                        </li>
                        <li data-active="false">
                            <a href="/mobile-app">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/mobile-app.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/mobile-app.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/mobile-app.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/mobile-app-active.png?v=20230417-1);" /></picture>
                                Unduh
                            </a>
                        </li>
                        <li data-active="false">
                            <a href="/deposit">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/deposit.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/deposit.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/deposit.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/deposit-active.png?v=20230417-1);" /></picture>
                                Deposit
                            </a>
                        </li>
                        <li data-active="false">
                            <a href="/promotion">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/promotion.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/promotion.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/promotion.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/promotion-active.png?v=20230417-1);" /></picture>
                                Promosi
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)" class="js_live_chat_link" data-url="https://direct.lc.chat/15353634/">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat-active.png?v=20230417-1);" /></picture>
                                Live Chat
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <input type="checkbox" id="site_side_menu_trigger_input" class="site-side-menu-trigger-input" />

    <div class="site-side-menu">
        <label for="site_side_menu_trigger_input"></label>
        <ul>
                            <li>
                    <div class="side-menu-user-info">
    <div class="avatar">
        <i class="glyphicon glyphicon-user"></i>
    </div>
    <div>
        <div class="username"><?php echo $d['username'] ?></div>
        <div class="balance-field">
            <div class="balance">
                <strong>IDR</strong>
                <span class="total_balance">0.00</span>
            </div>
            <div class="locked-balance locked_balance_container" hidden>
                <i class="glyphicon glyphicon-lock"></i>
                <span class="total_locked_balance">
                    -1.00
                </span>
            </div>
        </div>
    </div>
    <div class="buttons-container">
        <a href="#" class="logout-button" onclick="window.closeWindows(); document.querySelector('#side_menu_logout_form').submit();">
<form action="../../logout.php" id="side_menu_logout_form" method="post">Keluar</form>        </a>
    </div>
</div>

                </li>
            <li>
                <a href="../../dashboard/" data-active="false">
                    <i data-icon="home">
                        <img alt="Home" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/home.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/home-active.svg?v=20230417-1);" />
                    </i>
                    Beranda
                </a>
            </li>
            <li>
                <details>
                    <summary>
                        <section>
                            <span>
                                <i data-icon="games">
                                    <img alt="Games" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/games.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/games-active.svg?v=20230417-1);" />
                                </i>
                                Games
                            </span>
                            <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                        </section>
                    </summary>
                    <article>
                        <ul>
                            <li>
                                <details>
                                    <summary>
                                        <section>
                                            Hot Games
                                            <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                        </section>
                                    </summary>
                                    <article>
                                        <ul>



<li>
    <a href="/slots/pragmatic">
        Pragmatic Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TRG/Mobile&#39;, &#39;Main&#39;)">
        ION Casino
    </a>
</li>



<li>
    <a href="/slots/microgaming">
        MicroGaming
    </a>
</li>



<li>
    <a href="/slots/crowd-play">
        Crowd Play
    </a>
</li>



<li>
    <a href="/slots/pgsoft">
        PG Slots
    </a>
</li>



<li>
    <a href="/arcade/spribe">
        Spribe
    </a>
</li>



<li>
    <a href="/slots/reel-kingdom">
        Reel Kingdom by Pragmatic
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/G8POKER/Mobile&#39;, &#39;Main&#39;)">
        Balak Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/BALAK4D/Mobile&#39;, &#39;Main&#39;)">
        Nex4D
    </a>
</li>
                                        </ul>
                                    </article>
                                </details>
                            </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Slots
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="/slots/pragmatic">
        Pragmatic Play
    </a>
</li>



<li>
    <a href="/slots/microgaming">
        MicroGaming
    </a>
</li>



<li>
    <a href="/slots/pgsoft">
        PG Slots
    </a>
</li>



<li>
    <a href="/slots/reel-kingdom">
        Reel Kingdom by Pragmatic
    </a>
</li>



<li>
    <a href="/slots/advantplay">
        AdvantPlay
    </a>
</li>



<li>
    <a href="/slots/crowd-play">
        Crowd Play
    </a>
</li>



<li>
    <a href="/slots/amb-slot">
        AMB Slot
    </a>
</li>



<li>
    <a href="/slots/bigpot">
        Bigpot
    </a>
</li>



<li>
    <a href="/slots/vpower">
        VPower
    </a>
</li>



<li>
    <a href="/slots/mario-club">
        Mario Club
    </a>
</li>



<li>
    <a href="/slots/dragoonsoft">
        Dragoonsoft
    </a>
</li>



<li>
    <a href="/slots/slot88">
        Slot88
    </a>
</li>



<li>
    <a href="/slots/ion-slot">
        ION Slot
    </a>
</li>



<li>
    <a href="/slots/joker">
        Joker
    </a>
</li>



<li>
    <a href="/slots/fachai">
        Fachai
    </a>
</li>



<li>
    <a href="/slots/jili">
        Jili
    </a>
</li>



<li>
    <a href="/slots/live22">
        Live22
    </a>
</li>



<li>
    <a href="/slots/playstar">
        Playstar
    </a>
</li>



<li>
    <a href="/slots/spade-gaming">
        Spade Gaming
    </a>
</li>



<li>
    <a href="/slots/fun-gaming">
        Fun Gaming
    </a>
</li>



<li>
    <a href="/slots/habanero">
        Habanero
    </a>
</li>



<li>
    <a href="/slots/jdb">
        JDB
    </a>
</li>



<li>
    <a href="/slots/cq9">
        CQ9
    </a>
</li>



<li>
    <a href="/slots/ttg">
        Top Trend Gaming
    </a>
</li>



<li>
    <a href="/slots/betsoft">
        BetSoft
    </a>
</li>



<li>
    <a href="/slots/playtech">
        Playtech
    </a>
</li>



<li>
    <a href="/slots/yggdrasil">
        Yggdrasil
    </a>
</li>



<li>
    <a href="/slots/playngo">
        Play&#39;n Go
    </a>
</li>



<li>
    <a href="/slots/onetouch">
        OneTouch
    </a>
</li>



<li>
    <a href="/slots/real-time-gaming">
        Real Time Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOFLOWGAMING/Mobile&#39;, &#39;Main&#39;)">
        Flow Gaming
    </a>
</li>



<li>
    <a href="/slots/funky-games">
        Funky Games
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Live Casino
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TRG/Mobile&#39;, &#39;Main&#39;)">
        ION Casino
    </a>
</li>



<li>
    <a href="/casino/pragmatic">
        PP Casino
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/MGLIVECASINO/Mobile&#39;, &#39;Main&#39;)">
        MG Live
    </a>
</li>



<li>
    <a href="/casino/evo-gaming">
        Evo Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOSEXYBACCARAT/Mobile&#39;, &#39;Main&#39;)">
        Sexy Baccarat
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PRETTYGAMING/Mobile&#39;, &#39;Main&#39;)">
        Pretty Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/AG/Mobile&#39;, &#39;Main&#39;)">
        Asia Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/ALLBET/Mobile&#39;, &#39;Main&#39;)">
        AllBet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PGSLIVE/Mobile&#39;, &#39;Main&#39;)">
        PGS Live
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SAGAMING/Mobile&#39;, &#39;Main&#39;)">
        SA Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/EBET/Mobile&#39;, &#39;Main&#39;)">
        Ebet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/DREAMGAMING/Mobile&#39;, &#39;Main&#39;)">
        Dream Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOCASINO/Mobile&#39;, &#39;Main&#39;)">
        568Win Casino
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SV388/Mobile&#39;, &#39;Main&#39;)">
        SV388
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Sports
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBO/Mobile&#39;, &#39;Main&#39;)">
        SBO Sportsbook
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IBCSPORTS/Mobile&#39;, &#39;Main&#39;)">
        Saba Sportsbook
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/OPUS/Mobile&#39;, &#39;Main&#39;)">
        Opus
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/WBET/Mobile&#39;, &#39;Main&#39;)">
        WBet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PINNACLE/Mobile&#39;, &#39;Main&#39;)">
        Pinnacle
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/CMD/Mobile&#39;, &#39;Main&#39;)">
        CMD
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOVIRTUALGAMES/Mobile&#39;, &#39;Main&#39;)">
        SBO Virtual Sports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PPVIRTUALGAMES/Mobile&#39;, &#39;Main&#39;)">
        PP Virtual Sports
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Arcade
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="/arcade/microgaming">
        MicroGaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/crowd-play">
        Crowd Play Fishing
    </a>
</li>



<li>
    <a href="/arcade/spribe">
        Spribe
    </a>
</li>



<li>
    <a href="/arcade/joker">
        Joker Fishing
    </a>
</li>



<li>
    <a href="/arcade/fachai">
        Fachai Fishing
    </a>
</li>



<li>
    <a href="/arcade/jili">
        Jili Fishing
    </a>
</li>



<li>
    <a href="/arcade/mario-club">
        Mario Club Fishing
    </a>
</li>



<li>
    <a href="/arcade/dragoonsoft">
        Dragoonsoft Fishing
    </a>
</li>



<li>
    <a href="/arcade/amb-slot">
        AMB Slot Fishing
    </a>
</li>



<li>
    <a href="/arcade/vpower">
        VPower Fishing
    </a>
</li>



<li>
    <a href="/arcade/live22">
        Live22 Fishing
    </a>
</li>



<li>
    <a href="/arcade/cq9">
        CQ9 Fishing
    </a>
</li>



<li>
    <a href="/arcade/fun-gaming">
        Fun Gaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/spade-gaming">
        Spade Gaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/arcadia">
        Arcadia
    </a>
</li>



<li>
    <a href="/arcade/playstar">
        Playstar Fishing
    </a>
</li>



<li>
    <a href="/arcade/advantplay-mini-game">
        AdvantPlay Mini Game
    </a>
</li>



<li>
    <a href="/arcade/jdb">
        JDB Fishing
    </a>
</li>



<li>
    <a href="/arcade/funky-games">
        Funky Games Fishing
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IXTTANGKAS/Mobile&#39;, &#39;Main&#39;)">
        MM Tangkas
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Poker
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/G8POKER/Mobile&#39;, &#39;Main&#39;)">
        Balak Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/ONEPOKER/Mobile&#39;, &#39;Main&#39;)">
        9Gaming
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                E-Sports
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IMONE/Mobile&#39;, &#39;Main&#39;)">
        IM Esports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PINNACLEESPORTS/Mobile&#39;, &#39;Main&#39;)">
        Pinnacle E-Sports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TFGAMING/Mobile&#39;, &#39;Main&#39;)">
        TF Gaming
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Togel
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/BALAK4D/Mobile&#39;, &#39;Main&#39;)">
        Nex4D
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                        </ul>
                    </article>
                </details>
            </li>
                <li>
                    <details>
                        <summary>
                            <section>
                                <span>
                                    <i data-icon="wallet">
                                        <img alt="Wallet" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/wallet.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/wallet-active.svg?v=20230417-1);" />
                                    </i>
                                    KASIR
                                </span>
                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                            </section>
                        </summary>
                        <article>
                            <ul>
                                <li>
                                    <a href="/deposit">
                                        Deposit
                                    </a>
                                </li>
                                <li>
                                    <a href="/withdrawal">
                                        Tarik
                                    </a>
                                </li>
                                                                    <li>
                                        <a href="/bonus">
                                            Bonus
                                        </a>
                                    </li>
                                                                    <li>
                                        <a href="/commission">
                                            Komisi
                                        </a>
                                    </li>
                                                                    <li>
                                        <a href="/cashback">
                                            Cashback
                                        </a>
                                    </li>
                                                                    <li>
                                        <a href="/combine-promo">
                                            Promo Gabungan
                                        </a>
                                    </li>
                            </ul>
                        </article>
                    </details>
                </li>
                <li>
                    <details>
                        <summary>
                            <section>
                                <span>
                                    <i data-icon="message">
                                        <img alt="Message" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/message.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/message-active.svg?v=20230417-1);" />
                                    </i>
                                    Pesan
                                </span>
                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                            </section>
                        </summary>
                        <article>
                            <ul>
                                <li>
                                    <a href="#">
                                        Inbox
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        Pengumuman
                                    </a>
                                </li>
                                <li>
                                    <a href="/new-message">
                                        Tiket Bantuan
                                    </a>
                                </li>
                            </ul>
                        </article>
                    </details>
                </li>
                <li>
                    <details>
                        <summary>
                            <section>
                                <span>
                                    <i data-icon="profile">
                                        <img alt="Profile" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/profile.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/profile-active.svg?v=20230417-1);" />
                                    </i>
                                    Profil Saya
                                </span>
                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                            </section>
                        </summary>
                        <article>
                            <ul>
                                <li>
                                    <a href="../../account-summary">
                                        Akun Saya
                                    </a>
                                </li>
                                <li>
                                    <a href="../../password">
                                        Ubah Kata Sandi
                                    </a>
                                </li>
                                <li>
                                    <a href="../../bank-account">
                                        Banking
                                    </a>
                                </li>
                                    <li>
                                        <a href="../../mobile-app">
                                            MOBILE APP
                                        </a>
                                    </li>
                            </ul>
                        </article>
                    </details>
                </li>
                    <li>
                        <details>
                            <summary>
                                <section>
                                    <span>
                                        <i data-icon="referral">
                                            <img alt="Referral" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/referral.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/referral-active.svg?v=20230417-1);" />
                                        </i>
                                        Referensi
                                    </span>
                                    <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                </section>
                            </summary>
                            <article>
                                <ul>
                                    <li>
                                        <a href="/referral">
                                            Referensi
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/referral/signups-summary">
                                            Ringkasan Pendaftaran
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/referral/claimed-history">
                                            Riwayat Klaim
                                        </a>
                                    </li>
                                </ul>
                            </article>
                        </details>
                    </li>
                <li>
                    <details>
                        <summary>
                            <section>
                                <span>
                                    <i data-icon="reporting">
                                        <img alt="Reporting" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/reporting.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/reporting-active.svg?v=20230417-1);" />
                                    </i>
                                    Laporan
                                </span>
                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                            </section>
                        </summary>
                        <article>
                            <ul>
                                <li>
                                    <a href="/statement/consolidate">
                                        KONSOLIDASI

                                    </a>
                                </li>
                                <li>
                                    <a href="/history/deposit">
                                        Riwayat
                                    </a>
                                </li>
                            </ul>
                        </article>
                    </details>
                </li>
                        <li>
                <details>
                    <summary>
                        <section>
                            <span>
                                <i data-icon="language">
                                    <img alt="Language" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/language.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/language-active.svg?v=20230417-1);" />
                                </i>
                                BHS INDONESIAN
                            </span>
                            <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                        </section>
                    </summary>
                    <article>
                        <ul>
                                <li>
                                    <a href="javascript:changeLanguage('en')">
                                        ENGLISH
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:changeLanguage('id')">
                                        BHS INDONESIAN
                                    </a>
                                </li>
                        </ul>
                    </article>
                </details>
            </li>
                <li>
                    <a href="/mobile-app" data-active="false">
                        <i data-icon="download">
                            <img alt="Download" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/download.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/download-active.svg?v=20230417-1);" />
                        </i>
                        Download Game APK
                    </a>
                </li>
                            <li>
                    <a href="javascript:void(window.open(&#39;/streaming/live-tv/Mobile&#39;, &#39;live-tv&#39;))" rel="nofollow">
                        <i data-icon="live-tv">
                            <img alt="Live TV" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/live-tv.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/live-tv-active.svg?v=20230417-1);" />
                        </i>
                        Live Tv
                    </a>
                </li>
        </ul>
    </div>

    <a href="#" class="back-to-top" id="back_to_top" hidden>
        <i class="glyphicon glyphicon-arrow-up" aria-hidden="true"></i>
    </a>

    <a href="javascript:void(0)" class="live-chat-link js_live_chat_link" data-url="https://direct.lc.chat/15353634/">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat-active.png?v=20230417-1);" /></picture>
    </a>


    


<div id="popup_modal" class="modal popup-modal" role="dialog" data-title="">
    <div class="modal-dialog">
        <div class="modal-content" style="--popup-alert-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/popup/alert.png?v=20230417-1);;--popup-notification-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/popup/notification.png?v=20230417-1);;--event-giveaway-popper-src: url(//zm-cdn.zoomwl.com/Images/giveaway/popper.png?v=20230417-1);">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="popup_modal_title">
                    
                </h4>
            </div>
            <div class="modal-body" id="popup_modal_body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="popup_modal_dismiss_button">
                    OK
                </button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal" id="popup_modal_cancel_button" style="display: none">
                    Batal
                </button>
                <button type="button" class="btn btn-primary" id="popup_modal_confirm_button" style="display: none">
                    OK
                </button>
            </div>
        </div>
    </div>
</div>


    <script src='../../bundles/zoom-beta-js?v=OwfKtUYGKaoa3WKTGf3rhl9iu3JUsKwvzkc49sNwm_I1' defer></script>



    
    <script src='../../bundles/Slots/zoom-beta-js?v=tqMDoNRParO0ypYEdEyAkbVYkc1LkJi7l0V8U5ZDo1k1' defer></script>

    <script>
        window.addEventListener('DOMContentLoaded', () => {
            initializeSlotGames({
                directoryPath: '//zm-cdn.zoomwl.com/Images/providers-v2/',
                provider: 'PGSOFT',
                translations: {
                    playNow: 'MAIN',
                    demo: 'COBA'
                }
            });
        });
    </script>


    

    



</body>
</html>
