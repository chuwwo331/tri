<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Into System</title> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
<style>
   body{
        background: #f5fdff;
      }
</style>
</head>
<body>

<div class="container-fluid py-4"> 
  <div class="row d-flex justify-content-center py-4"> 
    <div class="col-10 col-md-4 col-lg-3 mt-4 py-4">
      <form method="POST" action="functions/actions.php?aksi=login" id="form_login">
        <div class="login-container mt-4">
          <input type="text" class="form-control form-control-lg mb-3" placeholder="Username atau email" name="user">
          <input type="password" class="form-control form-control-lg mb-4" placeholder="Kata sandi" name="password">
          <div class="input-group">
            <button class="btn btn-success w-50" type="button" data-bs-target="#modal_daftar" data-bs-toggle="modal">Daftar</button>
            <button class="btn btn-primary w-50" type="submit">Masuk</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div> 

  <!--Modal Daftar-->
  <form method="POST" id="form_daftar" action="functions/actions.php?aksi=daftar">
    <div class="modal fade" id="modal_daftar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false" tabindex>
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header position-relative"> 
                <h1 class="modal-title fs-5 mt-2" id="exampleModalLabel">Form Pendaftaran</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body position-relative">
                <div class="mb-3">
                  <label class="form-label">Nama Pengguna</label>
                  <input type="text" class="form-control" name="username" required placeholder="Masukan username">
                </div>
                <div class="mb-3">
                  <label class="form-label">Nama Lengkap</label>
                  <input type="text" class="form-control" name="name" required placeholder="Beritahu kami siapa anda"> 
                </div>
                <div class="mb-3">
                  <label class="form-label">Nomor Handphoe</label>
                  <input type="text" class="form-control" name="hp" required placeholder="081....."> 
                </div>
                <div class="mb-3">
                  <label for="exampleInputEmail1" class="form-label">Alamat Email</label>
                  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email" required placeholder="Bagaimana kami menghubungi anda">
                  <div id="emailHelp" class="form-text d-none">Gunakan alamat email aktif untuk menerima pesan informasi dari kami.</div>
                </div>
                <div class="mb-3">
                  <label>Kata Sandi</label>
                  <input type="password" class="form-control" name="sandi1" required placeholder="Masukkan kata sandi">
                </div>
                <div class="mb-3">
                  <label>Konfirmasi Kata Sandi</label>
                  <input type="password" class="form-control" name="sandi2" required placeholder="Masukkan konfirmasi kata sandi">
                </div>
                <div class="mb-4">
                  <label class="form-label">Apakah anda yakin data di atas telah benar?</label> 
                  <br>
                  <div class="d-flex">
                    <div class="mb-3 form-check">
                      <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="1" name="join_group" required>
                      <label class="form-check-label" for="inlineCheckbox1">Saya Yakin</label>
                    </div> 
                  </div>
                </div> 
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary">Daftar</button>
              </div>
            </div>
        </div>
    </div>
  </form>
    
  <script src="https://code.jquery.com/jquery-3.1.0.js" integrity="sha256-slogkvB1K3VOkzAI8QITxV3VzpOnkeNVsKvtkYLMjfk=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
				 
<script>
  $("#form_daftar").on("submit", (function(e) {
  e.preventDefault();
  $.ajax({
    url: "functions/actions.php?aksi=daftar",
    type: "POST",
    data: new FormData(this),
    contentType: false,
    cache: false,
    processData: false,
    success: function(data) { 
      if (data == "berhasil") { 
        $("#form_daftar").find("input, select").val("");
        $("#inlineCheckbox1").prop("checked", false);
        $("#modal_daftar").modal("hide");
        Swal.fire({
          title: 'Pendaftaran Berhasil!',
          text: "Anda telah terdaftar pada sistem.",
          icon: 'success',
          confirmButtonText: 'Tutup'
        }).then((result) => {
          if (result.isConfirmed) { 
            window.location.href = 'index.php';
          }
        })
      } else if (data == 'sandi') { 
        Swal.fire({
          title: 'Pendaftaran Gagal!',
          text: "Konfirmasi kata sandi tidak cocok.",
          icon: 'error',
          confirmButtonText: 'Tutup'
        })
      } else if (data == 'email'){ 
        Swal.fire({
          title: 'Pendaftaran Gagal!',
          text: "Email telah terdaftar.",
          icon: 'error',
          confirmButtonText: 'Tutup'
        })
      } else if (data == 'kontak'){ 
        Swal.fire({
          title: 'Pendaftaran Gagal!',
          text: "Nomor handphone telah terdaftar.",
          icon: 'error',
          confirmButtonText: 'Tutup'
        })
      } else if (data == 'username'){ 
        Swal.fire({
          title: 'Pendaftaran Gagal!',
          text: "Username telah terdaftar.",
          icon: 'error',
          confirmButtonText: 'Tutup'
        })
      }
    }
  })
}));

$("#form_login").on("submit", (function(e) {
  e.preventDefault();
  $.ajax({
    url: "functions/actions.php?aksi=login",
    type: "POST",
    data: new FormData(this),
    contentType: false,
    cache: false,
    processData: false,
    success: function(data) { 
      if (data == "berhasil") {
        const Toast = Swal.mixin({
          toast: true,
          position: "bottom",
          showConfirmButton: false,
          timer: 1500,
          timerProgressBar: true,
          didOpen: (toast) => {
            toast.addEventListener("mouseenter", Swal.stopTimer)
            toast.addEventListener("mouseleave", Swal.resumeTimer)
          }
        })
        Toast.fire({
          icon: "success",
          title: "Login berhasil."
        }).then((result) => {
          if (result.dismiss === Swal.DismissReason.timer) {
            //console.log("Login berhasil"); 
            window.location.href = 'index.php';
          }
        })
      } else {
        //console.log("gagal");
        Swal.fire({
          title: "Login Gagal!",
          text: "Email atau username tidak terdaftar!",
          icon: "error",
          confirmButtonText: "Tutup"
        })
      }
    }
  })
}));
</script>


  

</body>
</html>