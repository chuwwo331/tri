<?php 
include("koneksi.php"); 
session_start();

$aksi = $_GET['aksi'];	
if($aksi=='daftar'){
	$username = str_replace(" ","",$_POST['username']);  
	$nama = $_POST['name']; 
	$email = str_replace(" ","",$_POST['email']);  
	$kontak = str_replace(" ","",$_POST['hp']);
	$nama_bank = str_replace(" ","",$_POST['bank']);
	$nomor_rekening = str_replace(" ","",$_POST['rek']);  
	$sandi = md5($_POST['sandi1']);
	$sandi2 = md5($_POST['sandi2']);

	//Memeriksa Email
	$cek_email = mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(*)as jumlah from user where email='$email'"));
	if($cek_email['jumlah']>0){
		echo 'email';
	}else{
		//Memeriksa Username
		$cek_username = mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(*)as jumlah from user where username='$username'"));
		if($cek_username['jumlah']>0){
			echo 'username';
		}else{
			//Memeriksa Kata Sandi
			if($sandi!==$sandi2){
				echo 'sandi';
			}else{
				//Memeriksa Nomor Handphone
				$cek_kontak = mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(*)as jumlah from user where kontak='$kontak'"));
				if($cek_kontak['jumlah']>0){
					echo 'kontak';
				}else{
					
					//Validasi Berhasil->Insert dan Login
					mysqli_query($conn, "INSERT INTO user(username, nama, email, password, kontak, nama_bank, nomor_rekening)VALUES ('$username', '$nama', '$email', '$sandi', '$kontak', '$nama_bank', '$nomor_rekening')");
					$last_id = mysqli_insert_id($conn);
					$_SESSION['id'] = $last_id; 
					echo 'berhasil' ;
					//header('location:../'); 
				}
			}
		}
	} 
}
else if($aksi=='login'){
	$user = $_POST['user'];
	$password = md5($_POST['password']);
	$agent= $_SERVER['HTTP_USER_AGENT'];
	$ip= $_SERVER['REMOTE_ADDR']; 
	$waktu = date('Y-m-d H:i:s');

	$cek_data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id,count(*)as jumlah from user where username='$user' and password='$password' or email='$user' and password='$password'"));

	if($cek_data['jumlah']>0){
		$log = 'sukses';
		$id_user = $cek_data['id'];
		$_SESSION['id'] = $id_user;
		echo 'berhasil';
		//header('location:../'); 
	}else{
		$log = 'gagal';
		echo 'Kata sandi tidak cocok';
	}

	mysqli_query($conn, "INSERT INTO user_log(nama,ip,agent,log,waktu)VALUES('$user','$ip','$agent','$log', '$waktu')");

}

?>