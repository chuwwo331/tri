<?php
$host = 'localhost';
$user = 'root'; //user db
$pass = ''; //password db
$db   = 'registrar'; //nama db
 
    $conn = mysqli_connect($host, $user, $pass, $db);
    if($conn->connect_error){
        die ("<h1>Database Connection Failed</h1>");
    }
    //echo "Database Connected Successfully";  
?>