<?php
session_start();
$sesi_id = $_SESSION['id'];
if(empty($sesi_id)){
    header('location:../home');
}else{
    include_once('../functions/koneksi.php');
    $query = mysqli_query($conn, "SELECT * FROM user where id='$sesi_id'");
    $d = mysqli_fetch_assoc($query);
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>TIC88 Situs slot deposit pulsa tri 5000 tanpa potongan</title>

<meta content="TIC88 merupakan situs slot deposit pulsa tri terpercaya tanpa potongan yang memberikan banyak promosi mantap di tahun 2023" name="description" /><meta content="TIC88, Tri 88, slot pulsa tri, slot pulsa, slot online, situs slot, situs slot deposit pulsa, slot deposit tri, situs slot deposit 5000, slot tanpa potongan tri, deposit slot online, depo slot, tri slot." name="keywords" /><meta content="TIC88 Situs slot deposit pulsa tri 5000 tanpa potongan" property="og:title" /><meta content="TIC88 merupakan situs slot deposit pulsa tri terpercaya tanpa potongan yang memberikan banyak promosi mantap di tahun 2023" property="og:description" /><meta content="https://www.androidfanatic.com" property="og:url" /><meta content="TIC88" property="og:site_name" /><meta content="DarkGold" name="theme-color" /><meta content="id-ID" name="language" /><meta content="Indonesia" name="geo.region" /><meta content="Jakarta" name="geo.placename" /><meta content="website" name="categories" /><meta content="lAabQ_jE5qVb4m31PKzUGtDeAeebFGypV4JEw1dywQs" name="google-site-verification" />
    

    <link rel="preload" href="../fonts/glyphicons-halflings-regular.woff" as="font" type="font/woff" crossorigin>
    <link rel="preload" href="../fonts/FontsFreeNetAvenirLTStdBook.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="../fonts/FontsFreeNetAvenirLTStdBlack.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="../fonts/AvenirLTStdRoman.woff2" as="font" type="font/woff2" crossorigin>


<link href="https://TIC88.net" rel="canonical" /><link href="../favicon.png" rel="shortcut icon" type="image/x-icon" />
    <link href="../Content/zoom-beta-css?v=VzHJ-qzdbye7P7NykpUgLrBV7a_6cHgNNOfbEKlM9uc1" rel="stylesheet"/>


    
    <link href="../Content/Home/zoom-beta-css?v=w5zG77vAKkol5Djn8MXCK6CXHjdPfQseMluPeEWKrRY1" rel="stylesheet"/>



<link href="../Content/Theme/zoom-beta-dark-turquoise-css?v=CYcoorWS7zJqM6kKvoS7WpSkFlc3te5aN3DCNawvKDw1" rel="stylesheet"/>


<div style="position: fixed; bottom: 100px; left: 17px; z-index: 10; opacity: 0.98;">
<a href="https://wa.me/6289505661821 " target="_blank" rel="noopener nofollow">
<img src="https://i.ibb.co/2qNy6vN/whatsapp.gif" alt="whatsapp" border="0"  width="50" height="50"></a></div>


 <div align="center1" id="foot_banner2" style="z-index: 9999; width: 100px; margin: 0 auto; overflow:hidden;display:scroll;position:fixed;bottom:200px;left:17px;">
<a id="rtp2" onclick="document.getElementById('foot_banner2').style.display = 'none';" style="cursor:pointer; float:right;">
<button style="z-index: 999920;position: absolute;float: right;top: 0px;right: 0px;width: 20px;cursor: pointer;height: 20px;background-repeat: no-repeat;background-size: cover;background-color: red;" id="rtp2" alt="close" title="Close Ads">X</button></a>
<p>
<a title="RTP SLOT TERBARU" href="../livertpgacor/" target="_blank"><img src="https://i.ibb.co/LCZStMw/rtp.webp" alt="surga-group" width="50" height="50"></a>
</p>
</div> </head>
<body style="--expand-icon-src: url(//zm-cdn.zoomwl.com/Images/icons/expand.gif?v=20230417-1);
      --collapse-icon-src: url(//zm-cdn.zoomwl.com/Images/icons/collapse.gif?v=20230417-1);
      --play-icon-src: url(//zm-cdn.zoomwl.com/Images/icons/play.png?v=20230417-1);
      --jquery-ui-444444-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_444444_256x240.png?v=20230417-1);
      --jquery-ui-555555-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_555555_256x240.png?v=20230417-1);
      --jquery-ui-ffffff-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_ffffff_256x240.png?v=20230417-1);
      --jquery-ui-777620-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_777620_256x240.png?v=20230417-1);
      --jquery-ui-cc0000-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_cc0000_256x240.png?v=20230417-1);
      --jquery-ui-777777-src: url(//zm-cdn.zoomwl.com/Images/jquery-ui/ui-icons_777777_256x240.png?v=20230417-1);">

    <div class="navbar navbar-fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="site-topbar">
                            <a href="../dashboard/" class="logo">
                                <img loading="lazy" src="../logo.png" />
                            </a>
                        <main>

                        <div class="user-info">
    <button title="Refresh" class="" onclick="alert('Balance Updated !'); window.location='../dashboard'" data-loading="false">
        <i class="glyphicon glyphicon-refresh"></i>
    </button>
    <div class="user-info-item wallet-container" id="wallet_container">
        <?php echo $d['username'];?>
        <div class="balance">
            <a href="#" data-toggle="dropdown">
                <strong>IDR</strong>
                <span class="total_balance">
                    0.00
                </span>
                <span class="locked-balance locked_balance_container" hidden>
                    <i data-icon="locked-balance" class="glyphicon glyphicon-lock"></i>
                    <span class="total_locked_balance">
                        -1.00
                    </span>
                </span>
            </a>
            <div class="dropdown-menu vendor-balances-container">
    <div class="vendor-balances-header">
        <div>SALDO KREDIT</div>
        <div>0.00</div>
    </div>
    <div class="vendor-balances-content">
            <div>
                <strong>Slots</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>Pragmatic Play</div>
                            <div data-vendor-game-code="7">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>MicroGaming</div>
                            <div data-vendor-game-code="17">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>PG Slots</div>
                            <div data-vendor-game-code="9">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Reel Kingdom by Pragmatic</div>
                            <div data-vendor-game-code="74">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>AdvantPlay</div>
                            <div data-vendor-game-code="54">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Crowd Play</div>
                            <div data-vendor-game-code="73">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>AMB Slot</div>
                            <div data-vendor-game-code="61">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Bigpot</div>
                            <div data-vendor-game-code="75">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>VPower</div>
                            <div data-vendor-game-code="77">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Mario Club</div>
                            <div data-vendor-game-code="80">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Dragoonsoft</div>
                            <div data-vendor-game-code="81">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Slot88</div>
                            <div data-vendor-game-code="40">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>ION Slot</div>
                            <div data-vendor-game-code="50">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Joker</div>
                            <div data-vendor-game-code="6">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Fachai</div>
                            <div data-vendor-game-code="72">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Jili</div>
                            <div data-vendor-game-code="70">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Live22</div>
                            <div data-vendor-game-code="45">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Playstar</div>
                            <div data-vendor-game-code="65">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Spade Gaming</div>
                            <div data-vendor-game-code="29">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Fun Gaming</div>
                            <div data-vendor-game-code="79">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Habanero</div>
                            <div data-vendor-game-code="16">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>JDB</div>
                            <div data-vendor-game-code="51">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>CQ9</div>
                            <div data-vendor-game-code="13">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Top Trend Gaming</div>
                            <div data-vendor-game-code="67">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>BetSoft</div>
                            <div data-vendor-game-code="68">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Playtech</div>
                            <div data-vendor-game-code="2">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Yggdrasil</div>
                            <div data-vendor-game-code="42">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Play&#39;n Go</div>
                            <div data-vendor-game-code="18">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>OneTouch</div>
                            <div data-vendor-game-code="33">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Real Time Gaming</div>
                            <div data-vendor-game-code="28">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Flow Gaming</div>
                            <div data-vendor-game-code="26">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Funky Games</div>
                            <div data-vendor-game-code="35">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>Live Casino</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>ION Casino</div>
                            <div data-vendor-game-code="1">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>PP Casino</div>
                            <div data-vendor-game-code="41">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>MG Live</div>
                            <div data-vendor-game-code="66">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Evo Gaming</div>
                            <div data-vendor-game-code="38">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Sexy Baccarat</div>
                            <div data-vendor-game-code="27">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Pretty Gaming</div>
                            <div data-vendor-game-code="39">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Asia Gaming</div>
                            <div data-vendor-game-code="14">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>AllBet</div>
                            <div data-vendor-game-code="44">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>PGS Live</div>
                            <div data-vendor-game-code="64">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>SA Gaming</div>
                            <div data-vendor-game-code="84">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Ebet</div>
                            <div data-vendor-game-code="85">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Dream Gaming</div>
                            <div data-vendor-game-code="43">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>568Win Casino</div>
                            <div data-vendor-game-code="10">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>SV388</div>
                            <div data-vendor-game-code="57">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>Sports</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>SBO Sportsbook</div>
                            <div data-vendor-game-code="5">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Saba Sportsbook</div>
                            <div data-vendor-game-code="23">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Opus</div>
                            <div data-vendor-game-code="71">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>WBet</div>
                            <div data-vendor-game-code="69">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Pinnacle</div>
                            <div data-vendor-game-code="59">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>CMD</div>
                            <div data-vendor-game-code="83">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>SBO Virtual Sports</div>
                            <div data-vendor-game-code="11">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>PP Virtual Sports</div>
                            <div data-vendor-game-code="55">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>Arcade</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>MicroGaming Fishing</div>
                            <div data-vendor-game-code="17">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Crowd Play Fishing</div>
                            <div data-vendor-game-code="73">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Spribe</div>
                            <div data-vendor-game-code="82">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Joker Fishing</div>
                            <div data-vendor-game-code="6">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Fachai Fishing</div>
                            <div data-vendor-game-code="72">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Jili Fishing</div>
                            <div data-vendor-game-code="70">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Mario Club Fishing</div>
                            <div data-vendor-game-code="80">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Dragoonsoft Fishing</div>
                            <div data-vendor-game-code="81">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>AMB Slot Fishing</div>
                            <div data-vendor-game-code="61">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>VPower Fishing</div>
                            <div data-vendor-game-code="77">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Live22 Fishing</div>
                            <div data-vendor-game-code="45">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>CQ9 Fishing</div>
                            <div data-vendor-game-code="13">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Fun Gaming Fishing</div>
                            <div data-vendor-game-code="79">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Spade Gaming Fishing</div>
                            <div data-vendor-game-code="29">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Arcadia</div>
                            <div data-vendor-game-code="63">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Playstar Fishing</div>
                            <div data-vendor-game-code="65">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>AdvantPlay Mini Game</div>
                            <div data-vendor-game-code="62">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>JDB Fishing</div>
                            <div data-vendor-game-code="51">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Funky Games Fishing</div>
                            <div data-vendor-game-code="35">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>MM Tangkas</div>
                            <div data-vendor-game-code="34">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>Poker</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>Balak Play</div>
                            <div data-vendor-game-code="24">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>9Gaming</div>
                            <div data-vendor-game-code="32">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>E-Sports</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>IM Esports</div>
                            <div data-vendor-game-code="78">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>Pinnacle E-Sports</div>
                            <div data-vendor-game-code="60">
                                0.00
                            </div>
                        </div>
                        <div>
                            <div>TF Gaming</div>
                            <div data-vendor-game-code="58">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
            <div>
                <strong>Togel</strong>
                <div class="vendor-balance-item">
                        <div>
                            <div>Nex4D</div>
                            <div data-vendor-game-code="48">
                                0.00
                            </div>
                        </div>
                </div>
            </div>
    </div>
</div>
        </div>
    </div>
    <div class="unread-announcements-button unread_announcements_button" data-announcement-count="1">
        <a href="#">
            <i class="glyphicon glyphicon-bell"></i>
        </a>
    </div>
    <a href="../account-summary/" data-link="profile">
        <span class="user-info-item">
            <i class="glyphicon glyphicon-user"></i>
            Akun Saya
        </span>
    </a>
    <a href="../deposit/" data-link="deposit">
        <span class="user-info-item">
            <i class="glyphicon glyphicon-credit-card"></i>
            Deposit
        </span>
    </a>
        <a href="../mobile-app/" data-link="download">
            <span class="user-info-item">
                <i class="glyphicon glyphicon-download-alt"></i>
                Download Game APK
            </span>
        </a>
    <a href="javascript:registerPopup({ content:&#39;Inbox anda kosong.&#39; });" data-link="inbox">
        <span class="user-info-item">
            <i class="glyphicon glyphicon-envelope"></i>
            Inbox
        </span>
    </a>
    <a href="javascript:registerPopup({ content:&#39;Pengumuman anda kosong.&#39; });" data-link="announcement">
        <span class="user-info-item unread_announcements_button" data-new-announcement="true" data-announcement-count="1">
            <i class="glyphicon glyphicon-bell"></i>
            Pengumuman
        </span>
    </a>
        <a href="javascript:registerPopup({ content:&#39;Mohon maaf Live Tv sedang tidak tersedia.&#39; });" data-link="live-tv">
            <span class="user-info-item">
                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/live-tv.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/live-tv.png?v=20230417-1" type="image/png" /><img alt="Live TV" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/live-tv.png?v=20230417-1" /></picture>
                Live Tv
            </span>
        </a>
    <a href="#" data-link="logout" onclick="window.closeWindows(); document.querySelector('#form_logout').submit()">
<form action="../logout.php" id="form_logout" method="post">            <span class="user-info-item">
                <i class="glyphicon glyphicon-log-out"></i>
                Keluar
            </span>
</form>    </a>
</div>
                            <label class="site-side-menu-trigger" for="site_side_menu_trigger_input">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </label>
                        </main>
                    </div>
                </div>
            </div>
        </div>
        <div class="site-header-navbar">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="site-menu">
                            <li data-active="true">
                                <a href="../dashboard/">
                                    <i class="glyphicon glyphicon-home"></i>
                                </a>
                            </li>
                            <li data-active="false">
                                <a href="../slots/">
                                    <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/hot-games.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/hot-games.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/hot-games.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/hot-games-active.png?v=20230417-1);" /></picture>
                                    Hot Games
                                    <i data-icon="dropdown"></i>
                                </a>
                                    <div class="game-list-container">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <ul class="games-container">



<li>
    <a href="/slots/pragmatic">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.png?v=20230417-1" /></picture>
        Pragmatic Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TRG/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.png?v=20230417-1" /></picture>
        ION Casino
    </a>
</li>



<li>
    <a href="/slots/microgaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.png?v=20230417-1" /></picture>
        MicroGaming
    </a>
</li>



<li>
    <a href="/slots/crowd-play">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.png?v=20230417-1" /></picture>
        Crowd Play
    </a>
</li>



<li>
    <a href="/slots/pgsoft">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.png?v=20230417-1" /></picture>
        PG Slots
    </a>
</li>



<li>
    <a href="/arcade/spribe">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.png?v=20230417-1" /></picture>
        Spribe
    </a>
</li>



<li>
    <a href="/slots/reel-kingdom">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.png?v=20230417-1" /></picture>
        Reel Kingdom by Pragmatic
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/G8POKER/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.png?v=20230417-1" /></picture>
        Balak Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/BALAK4D/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.png?v=20230417-1" /></picture>
        Nex4D
    </a>
</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </li>
                                <li data-active="false">
                                    <a href="../slots/">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/slots.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/slots.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/slots.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/slots-active.png?v=20230417-1);" /></picture>
                                        Slots
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="/slots/pragmatic">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pp.png?v=20230417-1" /></picture>
        Pragmatic Play
    </a>
</li>



<li>
    <a href="/slots/microgaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgaming.png?v=20230417-1" /></picture>
        MicroGaming
    </a>
</li>



<li>
    <a href="/slots/pgsoft">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgsoft.png?v=20230417-1" /></picture>
        PG Slots
    </a>
</li>



<li>
    <a href="/slots/reel-kingdom">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/reelkingdom.png?v=20230417-1" /></picture>
        Reel Kingdom by Pragmatic
    </a>
</li>



<li>
    <a href="/slots/advantplay">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplay.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplay.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplay.png?v=20230417-1" /></picture>
        AdvantPlay
    </a>
</li>



<li>
    <a href="/slots/crowd-play">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplay.png?v=20230417-1" /></picture>
        Crowd Play
    </a>
</li>



<li>
    <a href="/slots/amb-slot">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/amb.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/amb.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/amb.png?v=20230417-1" /></picture>
        AMB Slot
    </a>
</li>



<li>
    <a href="/slots/bigpot">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/bigpot.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/bigpot.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/bigpot.png?v=20230417-1" /></picture>
        Bigpot
    </a>
</li>



<li>
    <a href="/slots/vpower">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpower.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpower.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpower.png?v=20230417-1" /></picture>
        VPower
    </a>
</li>



<li>
    <a href="/slots/mario-club">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclub.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclub.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclub.png?v=20230417-1" /></picture>
        Mario Club
    </a>
</li>



<li>
    <a href="/slots/dragoonsoft">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoft.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoft.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoft.png?v=20230417-1" /></picture>
        Dragoonsoft
    </a>
</li>



<li>
    <a href="/slots/slot88">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/slot88.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/slot88.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/slot88.png?v=20230417-1" /></picture>
        Slot88
    </a>
</li>



<li>
    <a href="/slots/ion-slot">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgs.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgs.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgs.png?v=20230417-1" /></picture>
        ION Slot
    </a>
</li>



<li>
    <a href="/slots/joker">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/joker.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/joker.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/joker.png?v=20230417-1" /></picture>
        Joker
    </a>
</li>



<li>
    <a href="/slots/fachai">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachai.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachai.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachai.png?v=20230417-1" /></picture>
        Fachai
    </a>
</li>



<li>
    <a href="/slots/jili">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jili.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jili.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jili.png?v=20230417-1" /></picture>
        Jili
    </a>
</li>



<li>
    <a href="/slots/live22">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22.png?v=20230417-1" /></picture>
        Live22
    </a>
</li>



<li>
    <a href="/slots/playstar">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstar.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstar.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstar.png?v=20230417-1" /></picture>
        Playstar
    </a>
</li>



<li>
    <a href="/slots/spade-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegaming.png?v=20230417-1" /></picture>
        Spade Gaming
    </a>
</li>



<li>
    <a href="/slots/fun-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungaming.png?v=20230417-1" /></picture>
        Fun Gaming
    </a>
</li>



<li>
    <a href="/slots/habanero">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/habanero.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/habanero.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/habanero.png?v=20230417-1" /></picture>
        Habanero
    </a>
</li>



<li>
    <a href="/slots/jdb">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdb.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdb.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdb.png?v=20230417-1" /></picture>
        JDB
    </a>
</li>



<li>
    <a href="/slots/cq9">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9.png?v=20230417-1" /></picture>
        CQ9
    </a>
</li>



<li>
    <a href="/slots/ttg">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ttg.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ttg.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ttg.png?v=20230417-1" /></picture>
        Top Trend Gaming
    </a>
</li>



<li>
    <a href="/slots/betsoft">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/betsoft.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/betsoft.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/betsoft.png?v=20230417-1" /></picture>
        BetSoft
    </a>
</li>



<li>
    <a href="/slots/playtech">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playtech.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playtech.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playtech.png?v=20230417-1" /></picture>
        Playtech
    </a>
</li>



<li>
    <a href="/slots/yggdrasil">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/yggdrasil.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/yggdrasil.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/yggdrasil.png?v=20230417-1" /></picture>
        Yggdrasil
    </a>
</li>



<li>
    <a href="/slots/playngo">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playngo.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playngo.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playngo.png?v=20230417-1" /></picture>
        Play&#39;n Go
    </a>
</li>



<li>
    <a href="/slots/onetouch">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onetouch.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onetouch.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onetouch.png?v=20230417-1" /></picture>
        OneTouch
    </a>
</li>



<li>
    <a href="/slots/real-time-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sborealtimegaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sborealtimegaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sborealtimegaming.png?v=20230417-1" /></picture>
        Real Time Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOFLOWGAMING/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sboflowgaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sboflowgaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sboflowgaming.png?v=20230417-1" /></picture>
        Flow Gaming
    </a>
</li>



<li>
    <a href="/slots/funky-games">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygame.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygame.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygame.png?v=20230417-1" /></picture>
        Funky Games
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/casino">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/casino.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/casino.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/casino.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/casino-active.png?v=20230417-1);" /></picture>
                                        Live Casino
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TRG/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/trg.png?v=20230417-1" /></picture>
        ION Casino
    </a>
</li>



<li>
    <a href="/casino/pragmatic">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pplivecasino.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pplivecasino.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pplivecasino.png?v=20230417-1" /></picture>
        PP Casino
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/MGLIVECASINO/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/mglivecasino.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/mglivecasino.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/mglivecasino.png?v=20230417-1" /></picture>
        MG Live
    </a>
</li>



<li>
    <a href="/casino/evo-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/evogaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/evogaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/evogaming.png?v=20230417-1" /></picture>
        Evo Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOSEXYBACCARAT/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbosexybaccarat.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbosexybaccarat.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbosexybaccarat.png?v=20230417-1" /></picture>
        Sexy Baccarat
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PRETTYGAMING/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/prettygaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/prettygaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/prettygaming.png?v=20230417-1" /></picture>
        Pretty Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/AG/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ag.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ag.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ag.png?v=20230417-1" /></picture>
        Asia Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/ALLBET/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/allbet.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/allbet.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/allbet.png?v=20230417-1" /></picture>
        AllBet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PGSLIVE/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgslive.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgslive.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pgslive.png?v=20230417-1" /></picture>
        PGS Live
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SAGAMING/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sagaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sagaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sagaming.png?v=20230417-1" /></picture>
        SA Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/EBET/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ebet.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ebet.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ebet.png?v=20230417-1" /></picture>
        Ebet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/DREAMGAMING/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dreamgaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dreamgaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dreamgaming.png?v=20230417-1" /></picture>
        Dream Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOCASINO/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocasino.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocasino.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocasino.png?v=20230417-1" /></picture>
        568Win Casino
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SV388/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sv388.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sv388.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sv388.png?v=20230417-1" /></picture>
        SV388
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/sport">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/sport.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/sport.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/sport.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/sport-active.png?v=20230417-1);" /></picture>
                                        Sports
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBO/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbo.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbo.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbo.png?v=20230417-1" /></picture>
        SBO Sportsbook
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IBCSPORTS/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ibcsports.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ibcsports.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ibcsports.png?v=20230417-1" /></picture>
        Saba Sportsbook
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/OPUS/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/opus.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/opus.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/opus.png?v=20230417-1" /></picture>
        Opus
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/WBET/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/wbet.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/wbet.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/wbet.png?v=20230417-1" /></picture>
        WBet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PINNACLE/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacle.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacle.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacle.png?v=20230417-1" /></picture>
        Pinnacle
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/CMD/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/cmd.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/cmd.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/cmd.png?v=20230417-1" /></picture>
        CMD
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOVIRTUALGAMES/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbovirtualgames.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbovirtualgames.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbovirtualgames.png?v=20230417-1" /></picture>
        SBO Virtual Sports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PPVIRTUALGAMES/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ppvirtualgames.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ppvirtualgames.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ppvirtualgames.png?v=20230417-1" /></picture>
        PP Virtual Sports
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/arcade">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/arcade.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/arcade.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/arcade.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/arcade-active.png?v=20230417-1);" /></picture>
                                        Arcade
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="/arcade/microgaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgamingfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgamingfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/microgamingfishing.png?v=20230417-1" /></picture>
        MicroGaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/crowd-play">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplayfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplayfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/crowdplayfishing.png?v=20230417-1" /></picture>
        Crowd Play Fishing
    </a>
</li>



<li>
    <a href="/arcade/spribe">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spribe.png?v=20230417-1" /></picture>
        Spribe
    </a>
</li>



<li>
    <a href="/arcade/joker">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jokerfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jokerfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jokerfishing.png?v=20230417-1" /></picture>
        Joker Fishing
    </a>
</li>



<li>
    <a href="/arcade/fachai">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachaifishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachaifishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fachaifishing.png?v=20230417-1" /></picture>
        Fachai Fishing
    </a>
</li>



<li>
    <a href="/arcade/jili">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jilifishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jilifishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jilifishing.png?v=20230417-1" /></picture>
        Jili Fishing
    </a>
</li>



<li>
    <a href="/arcade/mario-club">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclubfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclubfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/marioclubfishing.png?v=20230417-1" /></picture>
        Mario Club Fishing
    </a>
</li>



<li>
    <a href="/arcade/dragoonsoft">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoftfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoftfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/dragoonsoftfishing.png?v=20230417-1" /></picture>
        Dragoonsoft Fishing
    </a>
</li>



<li>
    <a href="/arcade/amb-slot">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ambfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ambfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ambfishing.png?v=20230417-1" /></picture>
        AMB Slot Fishing
    </a>
</li>



<li>
    <a href="/arcade/vpower">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpowerfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpowerfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/vpowerfishing.png?v=20230417-1" /></picture>
        VPower Fishing
    </a>
</li>



<li>
    <a href="/arcade/live22">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22fishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22fishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/live22fishing.png?v=20230417-1" /></picture>
        Live22 Fishing
    </a>
</li>



<li>
    <a href="/arcade/cq9">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9fishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9fishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbocq9fishing.png?v=20230417-1" /></picture>
        CQ9 Fishing
    </a>
</li>



<li>
    <a href="/arcade/fun-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungamingfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungamingfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/fungamingfishing.png?v=20230417-1" /></picture>
        Fun Gaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/spade-gaming">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegamingfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegamingfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/spadegamingfishing.png?v=20230417-1" /></picture>
        Spade Gaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/arcadia">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/arcadia.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/arcadia.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/arcadia.png?v=20230417-1" /></picture>
        Arcadia
    </a>
</li>



<li>
    <a href="/arcade/playstar">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstarfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstarfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/playstarfishing.png?v=20230417-1" /></picture>
        Playstar Fishing
    </a>
</li>



<li>
    <a href="/arcade/advantplay-mini-game">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplayminigame.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplayminigame.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/advantplayminigame.png?v=20230417-1" /></picture>
        AdvantPlay Mini Game
    </a>
</li>



<li>
    <a href="/arcade/jdb">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdbfishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdbfishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/jdbfishing.png?v=20230417-1" /></picture>
        JDB Fishing
    </a>
</li>



<li>
    <a href="/arcade/funky-games">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygamefishing.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygamefishing.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/sbofunkygamefishing.png?v=20230417-1" /></picture>
        Funky Games Fishing
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IXTTANGKAS/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ixttangkas.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ixttangkas.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/ixttangkas.png?v=20230417-1" /></picture>
        MM Tangkas
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/poker">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/poker.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/poker.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/poker.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/poker-active.png?v=20230417-1);" /></picture>
                                        Poker
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/G8POKER/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/g8poker.png?v=20230417-1" /></picture>
        Balak Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/ONEPOKER/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onepoker.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onepoker.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/onepoker.png?v=20230417-1" /></picture>
        9Gaming
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/e-sports">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/e-sports.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/e-sports.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/e-sports.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/e-sports-active.png?v=20230417-1);" /></picture>
                                        E-Sports
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IMONE/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/imone.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/imone.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/imone.png?v=20230417-1" /></picture>
        IM Esports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PINNACLEESPORTS/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacleesports.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacleesports.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/pinnacleesports.png?v=20230417-1" /></picture>
        Pinnacle E-Sports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TFGAMING/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/tfgaming.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/tfgaming.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/tfgaming.png?v=20230417-1" /></picture>
        TF Gaming
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                                <li data-active="false">
                                    <a href="/others">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/others.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/others.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/others.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/others-active.png?v=20230417-1);" /></picture>
                                        Togel
                                        <i data-icon="dropdown"></i>
                                    </a>
                                        <div class="game-list-container">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <ul class="games-container">



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/BALAK4D/Mobile&#39;, &#39;Main&#39;)">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/providers/shortcuts/balak4d.png?v=20230417-1" /></picture>
        Nex4D
    </a>
</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </li>
                            <li data-active="false">
                                <a href="../promotions/">
                                    <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/promotion.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/promotion.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/promotion.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/site-menu/promotion-active.png?v=20230417-1);" /></picture>
                                    Promosi
                                </a>
                            </li>
                            <li>
                                <div class="language-selector-container" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/flags.png?v=20230417-1);">
                                    <div id="language_selector_trigger" data-toggle="dropdown" class="language-selector-trigger" data-language="id">
                                        <i data-language="id"></i>
                                        ID
                                        <i data-icon="dropdown"></i>
                                    </div>
                                    <ul class="dropdown-menu language-selector">
                                            <li class="language_selector" data-language="en">
                                                <i data-language="en"></i>
                                                EN
                                            </li>
                                            <li class="language_selector" data-language="id">
                                                <i data-language="id"></i>
                                                ID
                                            </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    


<div class="banner">
    <div id="banner_carousel" class="carousel slide" data-ride="carousel" data-interval="5000">
        <ol class="carousel-indicators">
                <li class="active" data-target="#banner_carousel" data-slide-to="0"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="1"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="2"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="3"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="4"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="5"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="6"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="7"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="8"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="9"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="10"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="11"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="12"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="13"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="14"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="15"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="16"></li>
                <li class="" data-target="#banner_carousel" data-slide-to="17"></li>
        </ol>

        <div class="carousel-inner">
                <div class="item active">
                    <a href="#" target="_blank">
                        <picture>
                                <source media="(max-width:767px)" srcset="../PROMOBANNER/tebakperkalian.jpg" />
                            <source srcset="../PROMOBANNER/tebakperkalian.jpg" />
                            <img class="img-responsive" title="EVENT TEBAK PERKALIAN" src="../PROMOBANNER/tebakperkalian.jpg" alt="EVENT TEBAK PERKALIAN" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="#" target="_blank">
                        <picture>
                                <source media="(max-width:767px)" srcset="https://api2-t8r.tr8zgames.com/images/id_cbm_6c249af7-cf7a-45a6-86e4-da0a1c2ebb0a_1680864509193.jpg" />
                                <source media="(max-width:767px)" srcset="https://api2-t8r.tr8zgames.com/images/id_cbm_6c249af7-cf7a-45a6-86e4-da0a1c2ebb0a_1680864509193.jpg" />
                            <source srcset="https://api2-t8r.tr8zgames.com/images/id_cbm_6c249af7-cf7a-45a6-86e4-da0a1c2ebb0a_1680864509193.jpg" />
                            <img class="img-responsive" title="WELCOME BONUS SLOT 100% - 200%" src="https://api2-t8r.tr8zgames.com/images/id_cbm_6c249af7-cf7a-45a6-86e4-da0a1c2ebb0a_1680864509193.jpg" alt="WELCOME BONUS SLOT 100% - 200%" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="#" target="_blank">
                        <picture>
                                <source media="(max-width:767px)" srcset="../PROMOBANNER/mixparlay.png" />
                                <source media="(max-width:767px)" srcset="../PROMOBANNER/mixparlay.png" />
                            <source srcset="../PROMOBANNER/mixparlay.png" />
                            <img class="img-responsive" title="EVENT MIX PARLAY" src="../PROMOBANNER/mixparlay.png" alt="EVENT MIX PARLAY" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="#" target="_blank">
                        <picture>
                                <source media="(max-width:767px)" srcset="../PROMOBANNER/1juta.jpg" />
                                <source media="(max-width:767px)" srcset="../PROMOBANNER/1juta.jpg" />
                            <source srcset="PROMOBANNER/1juta.jpg" />
                            <img class="img-responsive" title="BONUS 1 JUTA SETIAP HARINYA" src="../PROMOBANNER/1juta.jpg" alt="PROMO SENSATIONAL 1 JUTA SETIAP HARINYA" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="/#" target="_blank">
                        <picture>
                                <source media="(max-width:767px)" srcset="https://api2-t8r.tr8zgames.com/images/id_cbm_cf276c29-569a-453f-8d32-e8bf266f5c96_1680843760487.jpg" />
                                <source media="(max-width:767px)" srcset="https://api2-t8r.tr8zgames.com/images/id_cbm_cf276c29-569a-453f-8d32-e8bf266f5c96_1680843760487.webp" />
                            <source srcset="https://api2-t8r.tr8zgames.com/images/id_cbd_cf276c29-569a-453f-8d32-e8bf266f5c96_1680843760487.jpg" />
                            <img class="img-responsive" title="MINIMAL DEPOSIT HANYA 5K" src="https://api2-t8r.tr8zgames.com/images/id_cbd_cf276c29-569a-453f-8d32-e8bf266f5c96_1680843760487.jpg" alt="MINIMAL DEPOSIT HANYA 5K" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="/#" target="_blank">
                        <picture>
                                <source media="(max-width:767px)" srcset="https://api2-t8r.tr8zgames.com/images/id_cbm_6ed30f99-4079-463f-8167-fedaf10589ff_1680850984420.jpg" />
                                <source media="(max-width:767px)" srcset="https://api2-t8r.tr8zgames.com/images/id_cbm_6ed30f99-4079-463f-8167-fedaf10589ff_1680850984420.webp" />
                            <source srcset="https://api2-t8r.tr8zgames.com/images/id_cbd_6ed30f99-4079-463f-8167-fedaf10589ff_1680850984420.jpg" />
                            <img class="img-responsive" title="DEPOSIT PULSA TANPA POTONGAN" src="https://api2-t8r.tr8zgames.com/images/id_cbd_6ed30f99-4079-463f-8167-fedaf10589ff_1680850984420.jpg" alt="DEPOSIT PULSA TANPA POTONGAN" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="/#" target="_blank">
                        <picture>
                                <source media="(max-width:767px)" srcset="https://api2-t8r.tr8zgames.com/images/id_cbm_3427b555-c314-45e6-9787-c4e10259c22c_1680753177560.jpg" />
                                <source media="(max-width:767px)" srcset="https://api2-t8r.tr8zgames.com/images/id_cbm_3427b555-c314-45e6-9787-c4e10259c22c_1680753177560.webp" />
                            <source srcset="https://api2-t8r.tr8zgames.com/images/id_cbd_3427b555-c314-45e6-9787-c4e10259c22c_1680753177560.jpg" />
                            <img class="img-responsive" title="BONUS HARIAN SPORT &amp; SLOT 10%" src="https://api2-t8r.tr8zgames.com/images/id_cbd_3427b555-c314-45e6-9787-c4e10259c22c_1680753177560.jpg" alt="BONUS HARIAN SPORT &amp; SLOT 10%" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="/#" target="_blank">
                        <picture>
                                <source media="(max-width:767px)" srcset="https://api2-t8r.tr8zgames.com/images/id_cbm_6c249af7-cf7a-45a6-86e4-da0a1c2ebb0a_1680864509193.jpg" />
                                <source media="(max-width:767px)" srcset="https://api2-t8r.tr8zgames.com/images/id_cbm_6c249af7-cf7a-45a6-86e4-da0a1c2ebb0a_1680864509193.webp" />
                            <source srcset="https://api2-t8r.tr8zgames.com/images/id_cbd_6c249af7-cf7a-45a6-86e4-da0a1c2ebb0a_1680864509193.jpg" />
                            <img class="img-responsive" title="REBATE HARIAN UP TO 0.7%" src="https://api2-t8r.tr8zgames.com/images/id_cbd_6c249af7-cf7a-45a6-86e4-da0a1c2ebb0a_1680864509193.jpg" alt="REBATE HARIAN UP TO 0.7%" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="slots/pragmatic" target="_self">
                        <picture>
                                <source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/banners/home/pp-mega-gacor-mobile.jpg" />
                            <source srcset="//zm-cdn.zoomwl.com/Images/banners/home/pp-mega-gacor-desktop.jpg" />
                            <img class="img-responsive" title="Pragmatic Play Mega Gacor" src="//zm-cdn.zoomwl.com/Images/banners/home/pp-mega-gacor-desktop.jpg" alt="Pragmatic Play Mega Gacor" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="slots/microgaming" target="_self">
                        <picture>
                                <source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/banners/home/mg-eksklusif-bonus-epik-harian-mobile.gif" />
                            <source srcset="//zm-cdn.zoomwl.com/Images/banners/home/mg-eksklusif-bonus-epik-harian-desktop.gif" />
                            <img class="img-responsive" title="Microgaming Bonus Epik Harian" src="//zm-cdn.zoomwl.com/Images/banners/home/mg-eksklusif-bonus-epik-harian-desktop.gif" alt="Microgaming Bonus Epik Harian" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="slots/pragmatic" target="_self">
                        <picture>
                                <source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/banners/home/pp-gacor-festival-mobile.png" />
                            <source srcset="//zm-cdn.zoomwl.com/Images/banners/home/pp-gacor-festival-desktop.png" />
                            <img class="img-responsive" title="Pragmatic Play Gacor Festival!" src="//zm-cdn.zoomwl.com/Images/banners/home/pp-gacor-festival-desktop.png" alt="Pragmatic Play Gacor Festival!" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="/dispatch/game/PP/Default/vs10gizagods" target="_self">
                        <picture>
                                <source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/banners/home/pp-exclusive-gods-of-giza-mobile.png" />
                            <source srcset="//zm-cdn.zoomwl.com/Images/banners/home/pp-exclusive-gods-of-giza-desktop.png" />
                            <img class="img-responsive" title="Pragmatic Play Exclusive Gods of Giza" src="//zm-cdn.zoomwl.com/Images/banners/home/pp-exclusive-gods-of-giza-desktop.png" alt="Pragmatic Play Exclusive Gods of Giza" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="slots/pragmatic" target="_self">
                        <picture>
                                <source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/banners/home/pp-mystery-of-the-orient-mobile.png" />
                            <source srcset="//zm-cdn.zoomwl.com/Images/banners/home/pp-mystery-of-the-orient-desktop.png" />
                            <img class="img-responsive" title="Pragmatic Play Mystery of The Orient" src="//zm-cdn.zoomwl.com/Images/banners/home/pp-mystery-of-the-orient-desktop.png" alt="Pragmatic Play Mystery of The Orient" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="/dispatch/game/MICROGAMING/Default/SMG_luckyTwinsNexus" target="_blank">
                        <picture>
                                <source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/banners/home/mg-exclusive-lucky-twins-mobile.gif" />
                            <source srcset="//zm-cdn.zoomwl.com/Images/banners/home/mg-exclusive-lucky-twins-desktop.gif" />
                            <img class="img-responsive" title="MG Exclusive Lucky Twins" src="//zm-cdn.zoomwl.com/Images/banners/home/mg-exclusive-lucky-twins-desktop.gif" alt="MG Exclusive Lucky Twins" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="slots/crowd-play" target="_self">
                        <picture>
                                <source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/banners/home/crowdplay-rebutan-harian-mobile.jpg" />
                            <source srcset="//zm-cdn.zoomwl.com/Images/banners/home/crowdplay-rebutan-harian-desktop.jpg" />
                            <img class="img-responsive" title="CROWDPLAY Rebutan Harian" src="//zm-cdn.zoomwl.com/Images/banners/home/crowdplay-rebutan-harian-desktop.jpg" alt="CROWDPLAY Rebutan Harian" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="slots/ion-slot" target="_self">
                        <picture>
                                <source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/banners/home/ionslot-cashdrop-april-mobile.png" />
                            <source srcset="//zm-cdn.zoomwl.com/Images/banners/home/ionslot-cashdrop-april-desktop.png" />
                            <img class="img-responsive" title="IONSLOT CASHDROP APRIL" src="//zm-cdn.zoomwl.com/Images/banners/home/ionslot-cashdrop-april-desktop.png" alt="IONSLOT CASHDROP APRIL" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="slots/advantplay" target="_self">
                        <picture>
                                <source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/banners/home/ap-songkran-festival-mobile.jpg" />
                            <source srcset="//zm-cdn.zoomwl.com/Images/banners/home/ap-songkran-festival-desktop.jpg" />
                            <img class="img-responsive" title="Advantplay Songkran Festival" src="//zm-cdn.zoomwl.com/Images/banners/home/ap-songkran-festival-desktop.jpg" alt="Advantplay Songkran Festival" />
                        </picture>
                    </a>
                </div>
                <div class="item ">
                    <a href="slots/advantplay" target="_self">
                        <picture>
                                <source media="(max-width:767px)" srcset="//zm-cdn.zoomwl.com/Images/banners/home/ap-fantastic-beast-mobile.jpg" />
                            <source srcset="//zm-cdn.zoomwl.com/Images/banners/home/ap-fantastic-beast-desktop.jpg" />
                            <img class="img-responsive" title="Advantplay Fantastic Beast" src="//zm-cdn.zoomwl.com/Images/banners/home/ap-fantastic-beast-desktop.jpg" alt="Advantplay Fantastic Beast" />
                        </picture>
                    </a>
                </div>
        </div>
    </div>
</div>


<div class="announcement-outer-container">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="announcement-container">
    <div data-section="date">
        20/04/2023 (Kam) 08.42 (GMT+07)
        <i data-icon="news" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/news.png?v=20230417-1);"></i>
    </div>
    <div data-section="announcements">
        <ul class="announcement-list" id="announcement_list">
                <li>Selamat datang di TIC88, hubungi CS kami yang online 24 jam kapan saja jika mengalami kesulitan dalam navigasi website kami, atau info seputar TIC88</li>
                <li>Pemeliharaan Terjadwal: Nex4D pada 2023-04-20 dari 9.00 AM sampai 12.30 PM (GMT + 7). Selama waktu ini, Nex4D permainan tidak akan tersedia. Kami memohon maaf atas ketidaknyamanan yang mungkin ditimbulkan.</li>
                <li>Pemeliharaan Terjadwal: Crowd Play pada 2023-04-20 dari 7.00 AM sampai 9.30 AM (GMT + 7). Selama waktu ini, Crowd Play permainan tidak akan tersedia. Kami memohon maaf atas ketidaknyamanan yang mungkin ditimbulkan.</li>
                <li>Pemeliharaan Terjadwal: Dragoonsoft pada 2023-04-20 dari 7.00 AM sampai 10.30 AM (GMT + 7). Selama waktu ini, Dragoonsoft permainan tidak akan tersedia. Kami memohon maaf atas ketidaknyamanan yang mungkin ditimbulkan.</li>
        </ul>
    </div>
</div>

            </div>
        </div>
    </div>
</div>
<div class="progressive-jackpot-outer-container">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="progressive-jackpot-inner-container">
                    <h3>Progressive<span>Jackpot</span></h3>
                    <div class="slot-jackpot-container">
    <div class="progressive-jackpot">
        <span id="progressive_jackpot"></span>
        <div class="jackpot-container">
            <span class="counter-container" id="progressive_jackpot_counter">
                <span data-digit="-"></span>
                <span data-digit="-"></span>
                <span>,</span>
                <span data-digit="-"></span>
                <span data-digit="-"></span>
                <span data-digit="-"></span>
                <span>,</span>
                <span data-digit="-"></span>
                <span data-digit="-"></span>
                <span data-digit="-"></span>
            </span>
        </div>
    </div>
</div>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    
    
    <div class="row">
        <div class="col-md-12">
            <div class="home-component-group">
                <div class="home-component-item">
                    

<div class="popular-slots-header">
    <h2>Video Slots Popular</h2>
    <div>
        <button type="button" id="previous_popular_slots_game">
            <img class="chevron-left" loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-left.svg?v=20230417-1" />
        </button>
        <button type="button" id="next_popular_slots_game">
            <img class="chevron-right" loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
        </button>
    </div>
</div>
<div class="popular-slots-games" id="popular_slots_games">
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs1600drago.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs1600drago.jpg?v=20230417-1" type="image/jpeg" /><img alt="PP" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs1600drago.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Jewels of Fortune™</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20fruitparty.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20fruitparty.jpg?v=20230417-1" type="image/jpeg" /><img alt="PP" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20fruitparty.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Fruit Party™</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs50hercules.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs50hercules.jpg?v=20230417-1" type="image/jpeg" /><img alt="PP" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs50hercules.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Hercules Son of Zeus</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vswayswildwest.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vswayswildwest.jpg?v=20230417-1" type="image/jpeg" /><img alt="PP" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vswayswildwest.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Wild West Gold Megaways™</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs8magicjourn.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs8magicjourn.jpg?v=20230417-1" type="image/jpeg" /><img alt="PP" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs8magicjourn.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Magic Journey™</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_rugbyStar.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_rugbyStar.jpg?v=20230417-1" type="image/jpeg" /><img alt="MICROGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_rugbyStar.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Rugby Star</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_luckyLeprechaun.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_luckyLeprechaun.jpg?v=20230417-1" type="image/jpeg" /><img alt="MICROGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_luckyLeprechaun.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Lucky Leprechaun</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_exoticCats.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_exoticCats.jpg?v=20230417-1" type="image/jpeg" /><img alt="MICROGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_exoticCats.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Exotic Cats</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_ingotsOfCaiShen.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_ingotsOfCaiShen.jpg?v=20230417-1" type="image/jpeg" /><img alt="MICROGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_ingotsOfCaiShen.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Ingots of Cai Shen</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_santasWildRide.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_santasWildRide.jpg?v=20230417-1" type="image/jpeg" /><img alt="MICROGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_santasWildRide.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Santa&#39;s Wild Ride</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/dragon-legend.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/dragon-legend.jpg?v=20230417-1" type="image/jpeg" /><img alt="PGSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/dragon-legend.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Dragon Legend</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/emperor_favour.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/emperor_favour.jpg?v=20230417-1" type="image/jpeg" /><img alt="PGSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/emperor_favour.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Emperors Favour</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/gem-saviour-sword.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/gem-saviour-sword.jpg?v=20230417-1" type="image/jpeg" /><img alt="PGSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/gem-saviour-sword.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Gem Saviour Sword</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/gem-saviour.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/gem-saviour.jpg?v=20230417-1" type="image/jpeg" /><img alt="PGSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/gem-saviour.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Gem Saviour</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/hotpot.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/hotpot.jpg?v=20230417-1" type="image/jpeg" /><img alt="PGSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/hotpot.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Hotpot</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs10spiritadv.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs10spiritadv.jpg?v=20230417-1" type="image/jpeg" /><img alt="REELKINGDOM" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs10spiritadv.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Spirit of Adventure</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs5drhs.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs5drhs.jpg?v=20230417-1" type="image/jpeg" /><img alt="REELKINGDOM" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs5drhs.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="j../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Dragon Hot Hold and Spin</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs243queenie.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs243queenie.jpg?v=20230417-1" type="image/jpeg" /><img alt="REELKINGDOM" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs243queenie.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Queenie</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs10luckcharm.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs10luckcharm.jpg?v=20230417-1" type="image/jpeg" /><img alt="REELKINGDOM" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs10luckcharm.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Lucky, Grace And Charm</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs20terrorv.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs20terrorv.jpg?v=20230417-1" type="image/jpeg" /><img alt="REELKINGDOM" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/REELKINGDOM/vs20terrorv.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Cash Elevator</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10005.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10005.jpg?v=20230417-1" type="image/jpeg" /><img alt="ADVANTPLAY" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10005.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Bobo Monster</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_19002.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_19002.jpg?v=20230417-1" type="image/jpeg" /><img alt="ADVANTPLAY" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_19002.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="../deposit/" onclick="alert('Silahkan isi kredit anda terlebih dahulu sebelum bermain !');" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">3 Warlords</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10015.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10015.jpg?v=20230417-1" type="image/jpeg" /><img alt="ADVANTPLAY" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10015.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/ADVANTPLAY/Desktop/AdvantPlay_10015&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Fortune&#39;s Warrior</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10002.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10002.jpg?v=20230417-1" type="image/jpeg" /><img alt="ADVANTPLAY" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10002.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/ADVANTPLAY/Desktop/AdvantPlay_10002&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Counter Terrorists</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10023.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10023.jpg?v=20230417-1" type="image/jpeg" /><img alt="ADVANTPLAY" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10023.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/ADVANTPLAY/Desktop/AdvantPlay_10023&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Hu Fu Blessing</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/Nightclub.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/Nightclub.jpg?v=20230417-1" type="image/jpeg" /><img alt="CROWDPLAY" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/Nightclub.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/CROWDPLAY/Desktop/Nightclub&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Nightclub</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/PawHouse.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/PawHouse.jpg?v=20230417-1" type="image/jpeg" /><img alt="CROWDPLAY" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/PawHouse.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/CROWDPLAY/Desktop/PawHouse&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Paw House</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/FiveLion.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/FiveLion.jpg?v=20230417-1" type="image/jpeg" /><img alt="CROWDPLAY" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/FiveLion.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/CROWDPLAY/Desktop/FiveLion&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Five Lion</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/Ra.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/Ra.jpg?v=20230417-1" type="image/jpeg" /><img alt="CROWDPLAY" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/Ra.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/CROWDPLAY/Desktop/Ra&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Ra</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/FuLuShou.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/FuLuShou.jpg?v=20230417-1" type="image/jpeg" /><img alt="CROWDPLAY" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/FuLuShou.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/CROWDPLAY/Desktop/FuLuShou&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Fu Lu Shou</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/VIRUS.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/VIRUS.jpg?v=20230417-1" type="image/jpeg" /><img alt="AMB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/VIRUS.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/AMB/Desktop/VIRUS&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Lab 19 Mania</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/BLESSINGTIGER.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/BLESSINGTIGER.jpg?v=20230417-1" type="image/jpeg" /><img alt="AMB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/BLESSINGTIGER.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/AMB/Desktop/BLESSINGTIGER&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Blessing of the Tiger</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/DORAEMON.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/DORAEMON.jpg?v=20230417-1" type="image/jpeg" /><img alt="AMB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/DORAEMON.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/AMB/Desktop/DORAEMON&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Doradoor</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/DROPRACING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/DROPRACING.jpg?v=20230417-1" type="image/jpeg" /><img alt="AMB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/DROPRACING.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/AMB/Desktop/DROPRACING&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Drop Racing</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/HORSERACING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/HORSERACING.jpg?v=20230417-1" type="image/jpeg" /><img alt="AMB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/AMB/HORSERACING.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/AMB/Desktop/HORSERACING&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Horse Racing</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_LV.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_LV.jpg?v=20230417-1" type="image/jpeg" /><img alt="BIGPOT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_LV.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/BIGPOT/Desktop/SLOT_LV&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Last Valkyrie</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_GK.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_GK.jpg?v=20230417-1" type="image/jpeg" /><img alt="BIGPOT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_GK.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/BIGPOT/Desktop/SLOT_GK&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Gold of the King</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_AS.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_AS.jpg?v=20230417-1" type="image/jpeg" /><img alt="BIGPOT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_AS.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/BIGPOT/Desktop/SLOT_AS&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Ancient Stones</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_LW.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_LW.jpg?v=20230417-1" type="image/jpeg" /><img alt="BIGPOT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_LW.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/BIGPOT/Desktop/SLOT_LW&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Lucky Waterfalls</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_PJ.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_PJ.jpg?v=20230417-1" type="image/jpeg" /><img alt="BIGPOT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/BIGPOT/SLOT_PJ.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/BIGPOT/Desktop/SLOT_PJ&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Panda’s Jackpot</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/BEFGHKMNORSV.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/BEFGHKMNORSV.jpg?v=20230417-1" type="image/jpeg" /><img alt="VPOWER" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/BEFGHKMNORSV.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/VPOWER/Desktop/BEFGHKMNORSV&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Seasons</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/ACDFGIKNPSWY.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/ACDFGIKNPSWY.jpg?v=20230417-1" type="image/jpeg" /><img alt="VPOWER" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/ACDFGIKNPSWY.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/VPOWER/Desktop/ACDFGIKNPSWY&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Panda</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/ABCFIJKMOQRW.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/ABCFIJKMOQRW.jpg?v=20230417-1" type="image/jpeg" /><img alt="VPOWER" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/ABCFIJKMOQRW.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/VPOWER/Desktop/ABCFIJKMOQRW&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Orient</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/BCFGIJLOQUWX.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/BCFGIJLOQUWX.jpg?v=20230417-1" type="image/jpeg" /><img alt="VPOWER" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/BCFGIJLOQUWX.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/VPOWER/Desktop/BCFGIJLOQUWX&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Girls</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/AFIJKMPQSTWY.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/AFIJKMPQSTWY.jpg?v=20230417-1" type="image/jpeg" /><img alt="VPOWER" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/VPOWER/AFIJKMPQSTWY.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/VPOWER/Desktop/AFIJKMPQSTWY&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Fame</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS094.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS094.jpg?v=20230417-1" type="image/jpeg" /><img alt="MARIOCLUB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS094.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/MARIOCLUB/Desktop/GS094&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">ZHAO CAI JIN BAO</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS099.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS099.jpg?v=20230417-1" type="image/jpeg" /><img alt="MARIOCLUB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS099.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/MARIOCLUB/Desktop/GS099&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">CHERRY LOVE</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS077.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS077.jpg?v=20230417-1" type="image/jpeg" /><img alt="MARIOCLUB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS077.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/MARIOCLUB/Desktop/GS077&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">GOLDEN TOUR</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/AG006.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/AG006.jpg?v=20230417-1" type="image/jpeg" /><img alt="MARIOCLUB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/AG006.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/MARIOCLUB/Desktop/AG006&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">MONKEYS THUNDERBOLT</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS103.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS103.jpg?v=20230417-1" type="image/jpeg" /><img alt="MARIOCLUB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/MARIOCLUB/GS103.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/MARIOCLUB/Desktop/GS103&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">BAI SHI</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3029.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3029.jpg?v=20230417-1" type="image/jpeg" /><img alt="DRAGOONSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3029.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/DRAGOONSOFT/Desktop/DRAGOONSOFT_3029&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Rich Dragon</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3026.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3026.jpg?v=20230417-1" type="image/jpeg" /><img alt="DRAGOONSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3026.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/DRAGOONSOFT/Desktop/DRAGOONSOFT_3026&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Midas Touch</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3002.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3002.jpg?v=20230417-1" type="image/jpeg" /><img alt="DRAGOONSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3002.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/DRAGOONSOFT/Desktop/DRAGOONSOFT_3002&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Over Dragon&#39;s Gate</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3010.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3010.jpg?v=20230417-1" type="image/jpeg" /><img alt="DRAGOONSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3010.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/DRAGOONSOFT/Desktop/DRAGOONSOFT_3010&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Monkey King</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3053.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3053.jpg?v=20230417-1" type="image/jpeg" /><img alt="DRAGOONSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/DRAGOONSOFT/DRAGOONSOFT_3053.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/DRAGOONSOFT/Desktop/DRAGOONSOFT_3053&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Big Diamond</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_7.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_7.jpg?v=20230417-1" type="image/jpeg" /><img alt="SLOT88" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_7.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SLOT88/Desktop/SLOT88_7&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Silent Samurai</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_58.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_58.jpg?v=20230417-1" type="image/jpeg" /><img alt="SLOT88" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_58.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SLOT88/Desktop/SLOT88_58&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Avengers</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_63.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_63.jpg?v=20230417-1" type="image/jpeg" /><img alt="SLOT88" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_63.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SLOT88/Desktop/SLOT88_63&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Crystal Crater</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_33.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_33.jpg?v=20230417-1" type="image/jpeg" /><img alt="SLOT88" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_33.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SLOT88/Desktop/SLOT88_33&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Totem Island</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_30.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_30.jpg?v=20230417-1" type="image/jpeg" /><img alt="SLOT88" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SLOT88/SLOT88_30.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SLOT88/Desktop/SLOT88_30&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Hong Long Meng</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-estaterichman.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-estaterichman.jpg?v=20230417-1" type="image/jpeg" /><img alt="PGS" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-estaterichman.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PGS/Desktop/agg_ht-estaterichman_290013&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Estate Rich Man</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/ht-luckywheel.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/ht-luckywheel.jpg?v=20230417-1" type="image/jpeg" /><img alt="PGS" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/ht-luckywheel.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PGS/Desktop/agg_ht-luckywheel_290046&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Lucky Wheel</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-heracles.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-heracles.jpg?v=20230417-1" type="image/jpeg" /><img alt="PGS" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-heracles.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PGS/Desktop/agg_ht-heracles_290036&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Heracles</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-horseracing_290045.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-horseracing_290045.jpg?v=20230417-1" type="image/jpeg" /><img alt="PGS" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-horseracing_290045.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PGS/Desktop/agg_ht-horseracing_290045&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Horse Racing</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-dragontreasure.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-dragontreasure.jpg?v=20230417-1" type="image/jpeg" /><img alt="PGS" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-dragontreasure.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PGS/Desktop/agg_ht-dragontreasure_290048&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Dragon Treasure</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/qd1fcneqbhgy4.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/qd1fcneqbhgy4.jpg?v=20230417-1" type="image/jpeg" /><img alt="JOKER" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/qd1fcneqbhgy4.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JOKER/Desktop/qd1fcneqbhgy4&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Immortals</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/55hj8ghaugxj6.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/55hj8ghaugxj6.jpg?v=20230417-1" type="image/jpeg" /><img alt="JOKER" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/55hj8ghaugxj6.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JOKER/Desktop/55hj8ghaugxj6&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Happy Buddha</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/pirtanombyroh.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/pirtanombyroh.jpg?v=20230417-1" type="image/jpeg" /><img alt="JOKER" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/pirtanombyroh.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JOKER/Desktop/pirtanombyroh&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Huga</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/rh8iwwntk3mie.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/rh8iwwntk3mie.jpg?v=20230417-1" type="image/jpeg" /><img alt="JOKER" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/rh8iwwntk3mie.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JOKER/Desktop/rh8iwwntk3mie&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Dolphin Reef</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/69xaiyrbo4dae.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/69xaiyrbo4dae.jpg?v=20230417-1" type="image/jpeg" /><img alt="JOKER" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JOKER/69xaiyrbo4dae.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JOKER/Desktop/69xaiyrbo4dae&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">A Night Out</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22048.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22048.jpg?v=20230417-1" type="image/jpeg" /><img alt="FACHAI" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22048.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/FACHAI/Desktop/FACHAI_22048&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">CRAZY BUFFALO</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22026.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22026.jpg?v=20230417-1" type="image/jpeg" /><img alt="FACHAI" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22026.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/FACHAI/Desktop/FACHAI_22026&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">HOT POT PARTY</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22042.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22042.jpg?v=20230417-1" type="image/jpeg" /><img alt="FACHAI" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22042.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/FACHAI/Desktop/FACHAI_22042&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">TREASURE RAIDERS</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22032.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22032.jpg?v=20230417-1" type="image/jpeg" /><img alt="FACHAI" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22032.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/FACHAI/Desktop/FACHAI_22032&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">MAGIC BEANS</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22028.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22028.jpg?v=20230417-1" type="image/jpeg" /><img alt="FACHAI" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/FACHAI/FACHAI_22028.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/FACHAI/Desktop/FACHAI_22028&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">TREASURE CRUISE</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_108.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_108.jpg?v=20230417-1" type="image/jpeg" /><img alt="JILI" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_108.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JILI/Desktop/JILI_108&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Magic Lamp</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_35.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_35.jpg?v=20230417-1" type="image/jpeg" /><img alt="JILI" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_35.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JILI/Desktop/JILI_35&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Crazy777</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_45.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_45.jpg?v=20230417-1" type="image/jpeg" /><img alt="JILI" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_45.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JILI/Desktop/JILI_45&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Crazy Golden Bank</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_145.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_145.jpg?v=20230417-1" type="image/jpeg" /><img alt="JILI" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_145.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JILI/Desktop/JILI_145&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Neko Fortune</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_38.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_38.jpg?v=20230417-1" type="image/jpeg" /><img alt="JILI" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JILI/JILI_38.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JILI/Desktop/JILI_38&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Fengshen</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_9700.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_9700.jpg?v=20230417-1" type="image/jpeg" /><img alt="LIVE22" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_9700.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/LIVE22/Desktop/LIVE22_9700&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Nezha and Aobing</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_4600.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_4600.jpg?v=20230417-1" type="image/jpeg" /><img alt="LIVE22" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_4600.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/LIVE22/Desktop/LIVE22_4600&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Dashing Inferno</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_12400.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_12400.jpg?v=20230417-1" type="image/jpeg" /><img alt="LIVE22" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_12400.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/LIVE22/Desktop/LIVE22_12400&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Golden Lion</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_7800.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_7800.jpg?v=20230417-1" type="image/jpeg" /><img alt="LIVE22" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_7800.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/LIVE22/Desktop/LIVE22_7800&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Panther Moon</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_10100.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_10100.jpg?v=20230417-1" type="image/jpeg" /><img alt="LIVE22" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/LIVE22/LIVE22_10100.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/LIVE22/Desktop/LIVE22_10100&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Jewel Twinkles</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00015.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00015.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYSTAR" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00015.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYSTAR/Desktop/PSS-ON-00015&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Who&#39;s The Boss</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00037.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00037.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYSTAR" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00037.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYSTAR/Desktop/PSS-ON-00037&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Money Come In</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSV-ON-00001.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSV-ON-00001.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYSTAR" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSV-ON-00001.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYSTAR/Desktop/PSV-ON-00001&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Candy Smash</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00135.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00135.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYSTAR" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00135.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYSTAR/Desktop/PSS-ON-00135&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">FEATURE BUY - Golden Pig</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00022.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00022.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYSTAR" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYSTAR/PSS-ON-00022.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYSTAR/Desktop/PSS-ON-00022&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Fruit Party</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-LY02.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-LY02.jpg?v=20230417-1" type="image/jpeg" /><img alt="SPADEGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-LY02.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SPADEGAMING/Desktop/S-LY02&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">FaFaFa2</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-FC03.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-FC03.jpg?v=20230417-1" type="image/jpeg" /><img alt="SPADEGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-FC03.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SPADEGAMING/Desktop/S-FC03&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Big Prosperity SA</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-RK02.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-RK02.jpg?v=20230417-1" type="image/jpeg" /><img alt="SPADEGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-RK02.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SPADEGAMING/Desktop/S-RK02&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Royal Katt</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-PH02.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-PH02.jpg?v=20230417-1" type="image/jpeg" /><img alt="SPADEGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-PH02.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SPADEGAMING/Desktop/S-PH02&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">King Pharaoh</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-CP02.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-CP02.jpg?v=20230417-1" type="image/jpeg" /><img alt="SPADEGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SPADEGAMING/S-CP02.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SPADEGAMING/Desktop/S-CP02&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Candy Candy</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/party.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/party.jpg?v=20230417-1" type="image/jpeg" /><img alt="FUNGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/party.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/FUNGAMING/Desktop/party&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Fruit_Party</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/PVZ.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/PVZ.jpg?v=20230417-1" type="image/jpeg" /><img alt="FUNGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/PVZ.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/FUNGAMING/Desktop/PVZ&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">PVZ</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/chz.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/chz.jpg?v=20230417-1" type="image/jpeg" /><img alt="FUNGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/chz.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/FUNGAMING/Desktop/chz&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Chinese Zodiac</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/dfdc.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/dfdc.jpg?v=20230417-1" type="image/jpeg" /><img alt="FUNGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/dfdc.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/FUNGAMING/Desktop/dfdc&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Bless&amp;Wealth</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/zhw.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/zhw.jpg?v=20230417-1" type="image/jpeg" /><img alt="FUNGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/FUNGAMING/zhw.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/FUNGAMING/Desktop/zhw&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Lord Of The Ring</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/SGLuckyFortuneCat.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/SGLuckyFortuneCat.jpg?v=20230417-1" type="image/jpeg" /><img alt="HABANERO" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/SGLuckyFortuneCat.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/HABANERO/Desktop/SGLuckyFortuneCat&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Lucky Fortune Cat</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/HB0143.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/HB0143.jpg?v=20230417-1" type="image/jpeg" /><img alt="HABANERO" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/HB0143.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/HABANERO/Desktop/SGRollingRoger&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Rolling Roger</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/HB0066.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/HB0066.jpg?v=20230417-1" type="image/jpeg" /><img alt="HABANERO" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/HB0066.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/HABANERO/Desktop/SGTreasureDiver&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Treasure Diver</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/HB0017.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/HB0017.jpg?v=20230417-1" type="image/jpeg" /><img alt="HABANERO" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/HB0017.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/HABANERO/Desktop/SGGalacticCash&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Galactic Cash</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/SGBeforeTimeRunsOut.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/SGBeforeTimeRunsOut.jpg?v=20230417-1" type="image/jpeg" /><img alt="HABANERO" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/HABANERO/SGBeforeTimeRunsOut.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/HABANERO/Desktop/SGBeforeTimeRunsOut&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Before Time Runs Out</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_8019.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_8019.jpg?v=20230417-1" type="image/jpeg" /><img alt="JDB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_8019.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JDB/Desktop/JDB_0_8019&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Four Treasures</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_9_9001.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_9_9001.jpg?v=20230417-1" type="image/jpeg" /><img alt="JDB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_9_9001.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JDB/Desktop/JDB_9_9001&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Classic Mario</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_14016.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_14016.jpg?v=20230417-1" type="image/jpeg" /><img alt="JDB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_14016.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JDB/Desktop/JDB_0_14016&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Kingsman</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_8005.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_8005.jpg?v=20230417-1" type="image/jpeg" /><img alt="JDB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_8005.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JDB/Desktop/JDB_0_8005&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">The Llama Adventure</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_14036.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_14036.jpg?v=20230417-1" type="image/jpeg" /><img alt="JDB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/JDB/JDB_0_14036.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/JDB/Desktop/JDB_0_14036&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">SuperNiubi</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_320.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_320.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOCQ9" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_320.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOCQ9/Desktop/CQ9_320&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Dragon Gate</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_339.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_339.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOCQ9" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_339.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOCQ9/Desktop/CQ9_339&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Hot DJ</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_187.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_187.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOCQ9" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_187.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOCQ9/Desktop/CQ9_187&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Lord Ganesha</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_118.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_118.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOCQ9" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_118.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOCQ9/Desktop/CQ9_118&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">WuKong&amp;Peaches</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_76.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_76.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOCQ9" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOCQ9/CQ9_76.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOCQ9/Desktop/CQ9_76&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Jump High</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_Golden888_0_1146.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_Golden888_0_1146.jpg?v=20230417-1" type="image/jpeg" /><img alt="TTG" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_Golden888_0_1146.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/TTG/Desktop/TTG_Golden888_0_1146&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Golden 888</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_BookOfTheEast_0_1161.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_BookOfTheEast_0_1161.jpg?v=20230417-1" type="image/jpeg" /><img alt="TTG" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_BookOfTheEast_0_1161.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/TTG/Desktop/TTG_BookOfTheEast_0_1161&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Book of the East</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_GoldenReindeer_0_1174.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_GoldenReindeer_0_1174.jpg?v=20230417-1" type="image/jpeg" /><img alt="TTG" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_GoldenReindeer_0_1174.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/TTG/Desktop/TTG_GoldenReindeer_0_1174&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Golden Reindeer</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_FortuneFrog_0_1153.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_FortuneFrog_0_1153.jpg?v=20230417-1" type="image/jpeg" /><img alt="TTG" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_FortuneFrog_0_1153.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/TTG/Desktop/TTG_FortuneFrog_0_1153&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Fortune Frog</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_GoldenAmazon_0_1077.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_GoldenAmazon_0_1077.jpg?v=20230417-1" type="image/jpeg" /><img alt="TTG" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/TTG/TTG_GoldenAmazon_0_1077.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/TTG/Desktop/TTG_GoldenAmazon_0_1077&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Golden Amazon</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_840.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_840.jpg?v=20230417-1" type="image/jpeg" /><img alt="BETSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_840.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/BETSOFT/Desktop/BETSOFT_840&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Stacked</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_471.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_471.jpg?v=20230417-1" type="image/jpeg" /><img alt="BETSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_471.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/BETSOFT/Desktop/BETSOFT_471&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Tycoons</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_704.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_704.jpg?v=20230417-1" type="image/jpeg" /><img alt="BETSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_704.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/BETSOFT/Desktop/BETSOFT_704&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">The SlotFather Part II</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_833.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_833.jpg?v=20230417-1" type="image/jpeg" /><img alt="BETSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_833.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/BETSOFT/Desktop/BETSOFT_833&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Primal Hunt</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_619.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_619.jpg?v=20230417-1" type="image/jpeg" /><img alt="BETSOFT" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/BETSOFT/BETSOFT_619.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/BETSOFT/Desktop/BETSOFT_619&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">A Christmas Carol</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/gpas_gskc_pop.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/gpas_gskc_pop.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYTECH" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/gpas_gskc_pop.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYTECH/Desktop/gpas_gskc_pop&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Gem Splash™: Kings Court™</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/feng-kuang-ma-jiang.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/feng-kuang-ma-jiang.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYTECH" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/feng-kuang-ma-jiang.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYTECH/Desktop/pop_swfkmj_skw&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Feng Kuang Ma Jiang</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/super-lions.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/super-lions.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYTECH" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/super-lions.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYTECH/Desktop/slion&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Super Lion</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/gpas_bomaway_pop.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/gpas_bomaway_pop.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYTECH" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/gpas_bomaway_pop.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYTECH/Desktop/gpas_bomaway_pop&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Bombs</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/miss-fortune.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/miss-fortune.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYTECH" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYTECH/miss-fortune.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYTECH/Desktop/mfrt&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Miss Fortune</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_226.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_226.jpg?v=20230417-1" type="image/jpeg" /><img alt="YGGDRASIL" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_226.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/YGGDRASIL/Desktop/YGGDRASIL_226&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Dragon Blox Gigablox</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_59.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_59.jpg?v=20230417-1" type="image/jpeg" /><img alt="YGGDRASIL" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_59.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/YGGDRASIL/Desktop/YGGDRASIL_59&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Yokozuna Clash</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_110.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_110.jpg?v=20230417-1" type="image/jpeg" /><img alt="YGGDRASIL" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_110.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/YGGDRASIL/Desktop/YGGDRASIL_110&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Thor Infinity Reels</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_98.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_98.jpg?v=20230417-1" type="image/jpeg" /><img alt="YGGDRASIL" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_98.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/YGGDRASIL/Desktop/YGGDRASIL_98&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Atlantis Megaways</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_131.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_131.jpg?v=20230417-1" type="image/jpeg" /><img alt="YGGDRASIL" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/YGGDRASIL/YGGDRASIL_131.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/YGGDRASIL/Desktop/YGGDRASIL_131&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Crystal Falls</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/tomeofmadness.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/tomeofmadness.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYNGO" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/tomeofmadness.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYNGO/Desktop/tomeofmadness&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Tome of Madness</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/taleofkyubiko.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/taleofkyubiko.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYNGO" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/taleofkyubiko.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYNGO/Desktop/taleofkyubiko&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Tale of Kyubiko</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/hugotwo.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/hugotwo.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYNGO" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/hugotwo.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYNGO/Desktop/hugotwo&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Hugo 2</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/bigwincat.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/bigwincat.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYNGO" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/bigwincat.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYNGO/Desktop/bigwincat&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Big Win Cat</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/keno.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/keno.jpg?v=20230417-1" type="image/jpeg" /><img alt="PLAYNGO" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PLAYNGO/keno.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/PLAYNGO/Desktop/keno&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Keno</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_travelingtreasuresbrazil.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_travelingtreasuresbrazil.jpg?v=20230417-1" type="image/jpeg" /><img alt="ONETOUCH" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_travelingtreasuresbrazil.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/ONETOUCH/Desktop/ont_travelingtreasuresbrazil&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Traveling Treasures Brazil</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_travelingtreasuresafrica.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_travelingtreasuresafrica.jpg?v=20230417-1" type="image/jpeg" /><img alt="ONETOUCH" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_travelingtreasuresafrica.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/ONETOUCH/Desktop/ont_travelingtreasuresafrica&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Traveling Treasures Africa</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_mikofestival.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_mikofestival.jpg?v=20230417-1" type="image/jpeg" /><img alt="ONETOUCH" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_mikofestival.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/ONETOUCH/Desktop/ont_mikofestival&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Miko Festival</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_snackblast.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_snackblast.jpg?v=20230417-1" type="image/jpeg" /><img alt="ONETOUCH" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_snackblast.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/ONETOUCH/Desktop/ont_snackblast&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Snack Blast</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_ryseofrome.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_ryseofrome.jpg?v=20230417-1" type="image/jpeg" /><img alt="ONETOUCH" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/ONETOUCH/ont_ryseofrome.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/ONETOUCH/Desktop/ont_ryseofrome&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Ryse of Rome</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_56.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_56.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOREALTIMEGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_56.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOREALTIMEGAMING/Desktop/RTG_56&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Lucky 6</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_5.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_5.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOREALTIMEGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_5.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOREALTIMEGAMING/Desktop/RTG_5&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Wu Zetian</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_116.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_116.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOREALTIMEGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_116.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOREALTIMEGAMING/Desktop/RTG_116&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Persian Treasures</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_70.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_70.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOREALTIMEGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_70.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOREALTIMEGAMING/Desktop/RTG_70&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Builder Beaver</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_1.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_1.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOREALTIMEGAMING" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOREALTIMEGAMING/RTG_1.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOREALTIMEGAMING/Desktop/RTG_1&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Plentiful Treasure</div>
                        </div>
                </div>
            </div>
            <div class="item">
                <div class="game-list">
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_214.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_214.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOFUNKYGAME" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_214.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOFUNKYGAME/Desktop/FUNKYGAMES_214&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Ju Bao Duo Fu</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_117.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_117.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOFUNKYGAME" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_117.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOFUNKYGAME/Desktop/FUNKYGAMES_117&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Pet Farm</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_153.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_153.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOFUNKYGAME" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_153.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOFUNKYGAME/Desktop/FUNKYGAMES_153&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Spring Festival</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_18.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_18.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOFUNKYGAME" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_18.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOFUNKYGAME/Desktop/FUNKYGAMES_18&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Fortune Goddess</div>
                        </div>
                        <div class="game-container">
                            <div class="game-wrapper">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_170.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_170.jpg?v=20230417-1" type="image/jpeg" /><img alt="SBOFUNKYGAME" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/SBOFUNKYGAME/FUNKYGAMES_170.jpg?v=20230417-1" /></picture>
                                <div class="link-container">
                                    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOFUNKYGAME/Desktop/FUNKYGAMES_170&#39;, &#39;Slots&#39;)" class="play-now">
                                        MAIN
                                    </a>
                                </div>
                            </div>
                            <div class="game-name">Ice Land</div>
                        </div>
                </div>
            </div>
</div>

                </div>
                <div class="home-component-sub-group">
                    <div class="home-component-item">
                        <h2>Pemenang Mesin Slot</h2>
                        <div class="slots-winner-list-container">
    <div id="winners_ticker">
        <ul class="slots-winner-list">
                <li>
                    <div class="slots-winner">
                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.jpg?v=20230417-1" type="image/jpeg" /><img alt="Gates of Olympus™" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.jpg?v=20230417-1" /></picture>
                        <div class="winner-info">
                            <h5>Gates of Olympus™</h5>
                            <div>kas****0</div>
                            <div>
                                IDR <span class="winner-amount">1109.80</span>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="slots-winner">
                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.jpg?v=20230417-1" type="image/jpeg" /><img alt="Gates of Olympus™" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.jpg?v=20230417-1" /></picture>
                        <div class="winner-info">
                            <h5>Gates of Olympus™</h5>
                            <div>tirta****5</div>
                            <div>
                                IDR <span class="winner-amount">987.18</span>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="slots-winner">
                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20starlight.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20starlight.jpg?v=20230417-1" type="image/jpeg" /><img alt="Starlight Princess™" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20starlight.jpg?v=20230417-1" /></picture>
                        <div class="winner-info">
                            <h5>Starlight Princess™</h5>
                            <div>ron****g</div>
                            <div>
                                IDR <span class="winner-amount">678.40</span>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="slots-winner">
                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20starlight.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20starlight.jpg?v=20230417-1" type="image/jpeg" /><img alt="Starlight Princess™" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20starlight.jpg?v=20230417-1" /></picture>
                        <div class="winner-info">
                            <h5>Starlight Princess™</h5>
                            <div>alp****u</div>
                            <div>
                                IDR <span class="winner-amount">653.34</span>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="slots-winner">
                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20fruitparty.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20fruitparty.jpg?v=20230417-1" type="image/jpeg" /><img alt="Fruit Party™" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20fruitparty.jpg?v=20230417-1" /></picture>
                        <div class="winner-info">
                            <h5>Fruit Party™</h5>
                            <div>y****8</div>
                            <div>
                                IDR <span class="winner-amount">518.65</span>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="slots-winner">
                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.jpg?v=20230417-1" type="image/jpeg" /><img alt="Gates of Olympus™" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.jpg?v=20230417-1" /></picture>
                        <div class="winner-info">
                            <h5>Gates of Olympus™</h5>
                            <div>chac****8</div>
                            <div>
                                IDR <span class="winner-amount">481.20</span>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="slots-winner">
                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSoft/default.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSoft/default.jpg?v=20230417-1" type="image/jpeg" /><img alt="PG74" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSoft/default.jpg?v=20230417-1" /></picture>
                        <div class="winner-info">
                            <h5>PG74</h5>
                            <div>t****8</div>
                            <div>
                                IDR <span class="winner-amount">447.52</span>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="slots-winner">
                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20starlight.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20starlight.jpg?v=20230417-1" type="image/jpeg" /><img alt="Starlight Princess™" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20starlight.jpg?v=20230417-1" /></picture>
                        <div class="winner-info">
                            <h5>Starlight Princess™</h5>
                            <div>d****9</div>
                            <div>
                                IDR <span class="winner-amount">430.94</span>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="slots-winner">
                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vswayshammthor.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vswayshammthor.jpg?v=20230417-1" type="image/jpeg" /><img alt="Power of Thor Megaways™" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vswayshammthor.jpg?v=20230417-1" /></picture>
                        <div class="winner-info">
                            <h5>Power of Thor Megaways™</h5>
                            <div>s***r</div>
                            <div>
                                IDR <span class="winner-amount">425.76</span>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="slots-winner">
                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSoft/default.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSoft/default.jpg?v=20230417-1" type="image/jpeg" /><img alt="PG135" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSoft/default.jpg?v=20230417-1" /></picture>
                        <div class="winner-info">
                            <h5>PG135</h5>
                            <div>br****e</div>
                            <div>
                                IDR <span class="winner-amount">400.68</span>
                            </div>
                        </div>
                    </div>
                </li>
        </ul>
    </div>
</div>
                    </div>
                    
            <div class="home-component-item">
                


<div class="new-slots-games-header">
    <h2>Slots Game Baru</h2>
    <div>
        <button type="button" id="previous_new_slots_game">
            <img class="chevron-left" loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-left.svg?v=20230417-1" />
        </button>
        <button type="button" id="next_new_slots_game">
            <img class="chevron-right" loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
        </button>
    </div>
</div>
<div class="new-slots-games" id="new_slots_games">
        <a href="javascript:openNewTab(&#39;/dispatch/game/PP/Desktop/vs20olympgate&#39;, &#39;Slots&#39;)" data-game="Gates of Olympus™">
            <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.jpg?v=20230417-1" type="image/jpeg" /><img alt="Gates of Olympus™" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PP/vs20olympgate.jpg?v=20230417-1" /></picture>
        </a>
        <a href="javascript:openNewTab(&#39;/dispatch/game/PGSOFT/Desktop/PGSOFT_74&#39;, &#39;Slots&#39;)" data-game="Mahjong Ways 2">
            <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/mahjong-ways2.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/mahjong-ways2.jpg?v=20230417-1" type="image/jpeg" /><img alt="Mahjong Ways 2" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGSOFT/mahjong-ways2.jpg?v=20230417-1" /></picture>
        </a>
        <a href="javascript:openNewTab(&#39;/dispatch/game/MICROGAMING/Desktop/SMG_luckyTwinsNexus&#39;, &#39;Slots&#39;)" data-game="Lucky Twins Nexus">
            <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_luckyTwinsNexus.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_luckyTwinsNexus.jpg?v=20230417-1" type="image/jpeg" /><img alt="Lucky Twins Nexus" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/MICROGAMING/SMG_luckyTwinsNexus.jpg?v=20230417-1" /></picture>
        </a>
        <a href="javascript:openNewTab(&#39;/dispatch/game/ADVANTPLAY/Desktop/AdvantPlay_10027&#39;, &#39;Slots&#39;)" data-game="Disco 777">
            <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10027.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10027.jpg?v=20230417-1" type="image/jpeg" /><img alt="Disco 777" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/ADVANTPLAY/AdvantPlay_10027.jpg?v=20230417-1" /></picture>
        </a>
        <a href="javascript:openNewTab(&#39;/dispatch/game/PGS/Desktop/agg_ht-powerofthor_290087&#39;, &#39;Slots&#39;)" data-game="Power Of Thor">
            <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-powerofthor_290087.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-powerofthor_290087.jpg?v=20230417-1" type="image/jpeg" /><img alt="Power Of Thor" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/PGS/agg_ht-powerofthor_290087.jpg?v=20230417-1" /></picture>
        </a>
        <a href="javascript:openNewTab(&#39;/dispatch/game/CROWDPLAY/Desktop/MoneyTree&#39;, &#39;Slots&#39;)" data-game="Money Tree Slot">
            <picture><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/MoneyTree.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/MoneyTree.jpg?v=20230417-1" type="image/jpeg" /><img alt="Money Tree Slot" loading="lazy" src="//zm-cdn.zoomwl.com/Images/providers-v2/CROWDPLAY/MoneyTree.jpg?v=20230417-1" /></picture>
        </a>
</div>

            </div>
        </div>
    </div>
</div>



<div class="carousel slide slots-providers" id="slots_providers" data-ride="carousel" style="background-image: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/background.jpg?v=20230417-1);">
    <div class="carousel-inner">
            <div class="item active">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PP.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PP.png?v=20230417-1" type="image/png" /><img alt="Pragmatic Play" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PP.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Pragmatic Play</h2>
                                <h4>GOLDEN OX™</h4>
                                <p>Perayaan dimulai di Golden Ox™ di mana kerbau keberuntungan memainkan peran utama. kumpulkan simbol scatter untuk mengaktifkan fitur putaran gratis dan gabungkan Simbol Uang dapat memberi Anda Grand Jackpot bernilai hingga 1,000x taruhan.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/MICROGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/MICROGAMING.png?v=20230417-1" type="image/png" /><img alt="MicroGaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/MICROGAMING.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>MicroGaming</h2>
                                <h4>Jungle Jim and The Lost Sphinx™</h4>
                                <p>Bersiaplah untuk petualangan di dalam mesir kuno dengan 50 payline dan grand jackpot 5000x tahuran. Temukan simbol sphinx untuk memicu fitur putaran 15 spin gratis.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PGSOFT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PGSOFT.png?v=20230417-1" type="image/png" /><img alt="PG Slots" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PGSOFT.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>PG Slots</h2>
                                <h4>Queen of Bounty™</h4>
                                <p>Jelajahi lautan dan terima tantangan untuk menjadi pemilik baru harta karun!  kumpulkan 3 atau lebih simbol Scatter dapat memicu fitur putaran 40 spin Gratis.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/REELKINGDOM.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/REELKINGDOM.png?v=20230417-1" type="image/png" /><img alt="Reel Kingdom by Pragmatic" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/REELKINGDOM.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Reel Kingdom by Pragmatic</h2>
                                <h4></h4>
                                <p>REELKINGDOM_SlotProvidersDesc</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/ADVANTPLAY.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/ADVANTPLAY.png?v=20230417-1" type="image/png" /><img alt="AdvantPlay" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/ADVANTPLAY.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>AdvantPlay</h2>
                                <h4>NINJA LEGEND™</h4>
                                <p>Legenda kuno dari negara Timur, bayangan yang tersembunyi dalam kegelapan, siapa pun yang bisa mendapatkan bantuan dari ninja akan memiliki kemampuan untuk menguasai dunia. Suatu hari, desa ninja yang sangat tersembunyi dalam pegunungan mendapatkan serangan misterius. Para ninja mengamuk dan tidak dapat diam saja, saatnya ninja terkuat untuk bangkit!</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/CROWDPLAY.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/CROWDPLAY.png?v=20230417-1" type="image/png" /><img alt="Crowd Play" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/CROWDPLAY.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Crowd Play</h2>
                                <h4></h4>
                                <p>CROWDPLAY_SlotProvidersDesc</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/AMB.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/AMB.png?v=20230417-1" type="image/png" /><img alt="AMB Slot" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/AMB.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>AMB Slot</h2>
                                <h4></h4>
                                <p>AMB Slots telah menciptakan sejumlah besar hampir 70 permainan berkualitas tinggi yang di sesuaikan untuk berbagai pasar. Ahli dalam menciptakan permainan dalam berbagai bentuk dan ukuran, Anda pasti akan terpesone oleh permainan yang di tawarkan oleh AMB slot.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/BIGPOT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/BIGPOT.png?v=20230417-1" type="image/png" /><img alt="Bigpot" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/BIGPOT.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Bigpot</h2>
                                <h4></h4>
                                <p>BIGPOT_SlotProvidersDesc</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/VPOWER.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/VPOWER.png?v=20230417-1" type="image/png" /><img alt="VPower" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/VPOWER.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>VPower</h2>
                                <h4></h4>
                                <p>VPOWER_SlotProvidersDesc</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/MARIOCLUB.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/MARIOCLUB.png?v=20230417-1" type="image/png" /><img alt="Mario Club" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/MARIOCLUB.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Mario Club</h2>
                                <h4></h4>
                                <p>MARIOCLUB_SlotProvidersDesc</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/DRAGOONSOFT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/DRAGOONSOFT.png?v=20230417-1" type="image/png" /><img alt="Dragoonsoft" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/DRAGOONSOFT.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Dragoonsoft</h2>
                                <h4></h4>
                                <p>DRAGOONSOFT_SlotProvidersDesc</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SLOT88.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SLOT88.png?v=20230417-1" type="image/png" /><img alt="Slot88" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SLOT88.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Slot88</h2>
                                <h4>88Fortunes™</h4>
                                <p>Ini hari keberuntungan anda! 88 Fortunes menghadirkan semua hit mesin slot langsung ke ponsel anda di lengkapin dengan progressive jackpot. Simbol Gong keberuntungan akan mengaktifkan fitur putaran gratis.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PGS.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PGS.png?v=20230417-1" type="image/png" /><img alt="ION Slot" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PGS.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>ION Slot</h2>
                                <h4>TAI CHI FORTUNA™</h4>
                                <p>Permainan slot terbaru dan terpopuler! Jadikan anda The Next Millioner!</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/JOKER.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/JOKER.png?v=20230417-1" type="image/png" /><img alt="Joker" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/JOKER.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Joker</h2>
                                <h4>COLUMBUS DELUXE™</h4>
                                <p>Slot video  columbus deluxe mengundang anda untuk melakukan perjalanan mengarungi lautan yang luas. Kumpulkan 5 simbol wild untuk mengaktifkan grand jackpot 5000x. Cobalah keberuntungan anda sekarang!</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/FACHAI.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/FACHAI.png?v=20230417-1" type="image/png" /><img alt="Fachai" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/FACHAI.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Fachai</h2>
                                <h4></h4>
                                <p>FACHAI_SlotProvidersDesc</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/JILI.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/JILI.png?v=20230417-1" type="image/png" /><img alt="Jili" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/JILI.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Jili</h2>
                                <h4></h4>
                                <p>JILI_SlotProvidersDesc</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/LIVE22.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/LIVE22.png?v=20230417-1" type="image/png" /><img alt="Live22" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/LIVE22.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Live22</h2>
                                <h4>BUFFALO BLAZE™</h4>
                                <p>Kawanan kerbau berlarian di sini, bersiaplah! Slot bertema barat lainnya ada di sini, apakah Anda siap untuk menang besar dalam game ini? Saat kawanan kerbau muncul dari reel 2 dan seterusnya hingga reel 5 secara berurutan, Anda dapat memenangkan hingga 8 putaran gratis dengan pengali 2x.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PLAYSTAR.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PLAYSTAR.png?v=20230417-1" type="image/png" /><img alt="Playstar" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PLAYSTAR.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Playstar</h2>
                                <h4></h4>
                                <p>Harta Free Game 2 kali dihitung tanpa terganggu meningkatkan
  hadiah, Jackpot super tinggi 16200 kali lipat, cara main mudah dan betah
  dimainkan, game paling populer di pasar orang Tionghoa PS.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SPADEGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SPADEGAMING.png?v=20230417-1" type="image/png" /><img alt="Spade Gaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SPADEGAMING.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Spade Gaming</h2>
                                <h4>HEROES™</h4>
                                <p>Rasakan setiap putaran terasa seperti Anda sedang mengambil bagian dalam pertarungan yang epik! dan gabungkan simbol kebijaksanaan Master Jiang Untuk mengaktifkan putaran Spin Gratis.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/FUNGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/FUNGAMING.png?v=20230417-1" type="image/png" /><img alt="Fun Gaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/FUNGAMING.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Fun Gaming</h2>
                                <h4></h4>
                                <p>FUNGAMING_SlotProvidersDesc</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/HABANERO.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/HABANERO.png?v=20230417-1" type="image/png" /><img alt="Habanero" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/HABANERO.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Habanero</h2>
                                <h4>FA CHAI SHEN DELUXE™</h4>
                                <p>
Hanabero kini menghadirkan video slot bertemakan cina dengan progressive jackpot, kumpulkanlah uang emas untuk mengaktifkan fitur putaran gratis dan cobalah keberuntungan anda dapatkan jackpotnya.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/JDB.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/JDB.png?v=20230417-1" type="image/png" /><img alt="JDB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/JDB.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>JDB</h2>
                                <h4>NINJA X™</h4>
                                <p>NINJA and five elements memberikan banyak hadiah! Five elements memastikan sejumlah besar bonus! Permainan gratis mengaktifkan simbol layar penuh untuk memenangkan hadiah besar! Shuriken membuat bonus menjadi 2 kali lipat! NINJAS berkumpul untuk membawa keberuntungan, menjadi dua kali lipat keuntungan anda!</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOCQ9.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOCQ9.png?v=20230417-1" type="image/png" /><img alt="CQ9" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOCQ9.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>CQ9</h2>
                                <h4>JUMP HIGHZ™</h4>
                                <p>Nikmati slot bernuansa EDM, carilah bola emas berkilauan lebih dari tiga untuk mengaktifkan fitur putaran gratis. Dengan maksimum kemenangan 2500x taruhan dengan fitur pengganda.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/TTG.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/TTG.png?v=20230417-1" type="image/png" /><img alt="Top Trend Gaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/TTG.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Top Trend Gaming</h2>
                                <h4></h4>
                                <p>Get ready to save the day by joining the forces with some of the most famous superheroes in history as you play for real cash on the reels. The free Super Kids slot with software by Top Trend Gaming features Spiderman, Thor, Deadpool, Hulk and Ironman to name just a few! But you won’t need any superpowers of your own to join in, so don’t waste any time in joining in the fun.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/BETSOFT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/BETSOFT.png?v=20230417-1" type="image/png" /><img alt="BetSoft" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/BETSOFT.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>BetSoft</h2>
                                <h4></h4>
                                <p>Take a journey into the high mountains in GOLD TIGER ASCENT, the latest video slot from Betsoft Gaming! This 3-reel, 3 row video slot, featuring an iconic golden tiger character, pays on 3 of a kind on any payline.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PLAYTECH.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PLAYTECH.png?v=20230417-1" type="image/png" /><img alt="Playtech" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PLAYTECH.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Playtech</h2>
                                <h4>JACKPOT GIANT™</h4>
                                <p>Jackpot giant adalah slot online dari Playtech dengan nuansa jaman batu dan tema prasejarah dengan fitur progressive jackpot dengan 50 pay lines dan 5 baris. Kumpulkanlah 3 tangan raksasa memegang uang untuk mengaktifkan fitur putaran gratis.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/YGGDRASIL.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/YGGDRASIL.png?v=20230417-1" type="image/png" /><img alt="Yggdrasil" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/YGGDRASIL.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Yggdrasil</h2>
                                <h4>VALLEY OF THE GOD™</h4>
                                <p>
Ungkap rahasia di dewa matahari Ra dengan tema mesir kuno dengan grafis yang memukau di lengkapi dengan 3125 payline dan 5 baris. Cobalah keberuntungan anda di sini dengan total maksimum kemenangan 580.000.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PLAYNGO.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PLAYNGO.png?v=20230417-1" type="image/png" /><img alt="Play&#39;n Go" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/PLAYNGO.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Play&#39;n Go</h2>
                                <h4>RISE OF OLYMPUS™</h4>
                                <p>
Kini Play n Go menghadirkan slot dengan animasi dan nuansa bertemakan nuansa mytologi kuno dengan peran utama Zeus. Jika Anda bermain dengan taruhan maksimum, ini bisa membuat Anda memenangkan 5000x dari jumlah taruhan anda.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/ONETOUCH.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/ONETOUCH.png?v=20230417-1" type="image/png" /><img alt="OneTouch" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/ONETOUCH.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>OneTouch</h2>
                                <h4>FORTUNE MINNER™</h4>
                                <p>Galilah harta karun bersama di slot Fortune Minner temukan respin setiap kemenangan dengan total 3 baris., kumpulkanlah gem sebanyak-banyaknya</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOREALTIMEGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOREALTIMEGAMING.png?v=20230417-1" type="image/png" /><img alt="Real Time Gaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOREALTIMEGAMING.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Real Time Gaming</h2>
                                <h4>Wu Ze Tian™</h4>
                                <p>Pimpinlah kerajaan anda menuju kekayaan rasakan sensasi suasana di kerajaan cina dengan tampilan 3D menarik 25 payline dan 5 reel. Kumpulkanlah simbol gong emas lebih dari 3 untuk memicu fitur putaran gratis.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOFLOWGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOFLOWGAMING.png?v=20230417-1" type="image/png" /><img alt="Flow Gaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOFLOWGAMING.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Flow Gaming</h2>
                                <h4>FINN GOLDEN TAVERN™</h4>
                                <p>Kini hadir FINN GOLDEN TAVERN anda akan di bawa ke Emerald Isle, dengan latar belakang nuansa bar bertema irlandia, temukanlah keberuntunganmu menemukan kotak harta karun bersama leprechaun bernama FINN untuk mengaktifasi fitur putaran gratis.</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item ">
                <div class="container">
                    <div class="row">
                        <div class="provider-item">
                            <div class="animated fadeInLeftBig">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOFUNKYGAME.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOFUNKYGAME.png?v=20230417-1" type="image/png" /><img alt="Funky Games" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/SBOFUNKYGAME.png?v=20230417-1" /></picture>
                            </div>
                            <section class="animated fadeInRightBig">
                                <h2>Funky Games</h2>
                                <h4></h4>
                                <p>SBOFUNKYGAME_SlotProvidersDesc</p>
                                <a href="../slots/">
                                    Coba Sekarang
                                </a>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <a class="left" href="#slots_providers" data-slide="prev" rel="nofollow">
        <img class="chevron-left" loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-left.svg?v=20230417-1" />
        <span class="sr-only">Previous</span>
    </a>
    <a class="right " href="#slots_providers" data-slide="next" rel="nofollow">
        <img class="chevron-right" loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
        <span class="sr-only">Next</span>
    </a>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="partners-container">
                <h3>OUR PARTNER</h3>
                <div class="partner-list">
                        <a href="/slots/pragmatic">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PP.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PP.png?v=20230417-1" type="image/png" /><img alt="Pragmatic Play" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PP.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/microgaming">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/MICROGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/MICROGAMING.png?v=20230417-1" type="image/png" /><img alt="MicroGaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/MICROGAMING.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/pgsoft">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PGSOFT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PGSOFT.png?v=20230417-1" type="image/png" /><img alt="PG Slots" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PGSOFT.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/reel-kingdom">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/REELKINGDOM.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/REELKINGDOM.png?v=20230417-1" type="image/png" /><img alt="Reel Kingdom by Pragmatic" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/REELKINGDOM.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/advantplay">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/ADVANTPLAY.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/ADVANTPLAY.png?v=20230417-1" type="image/png" /><img alt="AdvantPlay" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/ADVANTPLAY.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/crowd-play">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/CROWDPLAY.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/CROWDPLAY.png?v=20230417-1" type="image/png" /><img alt="Crowd Play" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/CROWDPLAY.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/amb-slot">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/AMB.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/AMB.png?v=20230417-1" type="image/png" /><img alt="AMB Slot" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/AMB.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/bigpot">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/BIGPOT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/BIGPOT.png?v=20230417-1" type="image/png" /><img alt="Bigpot" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/BIGPOT.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/vpower">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/VPOWER.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/VPOWER.png?v=20230417-1" type="image/png" /><img alt="VPower" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/VPOWER.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/mario-club">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/MARIOCLUB.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/MARIOCLUB.png?v=20230417-1" type="image/png" /><img alt="Mario Club" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/MARIOCLUB.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/dragoonsoft">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/DRAGOONSOFT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/DRAGOONSOFT.png?v=20230417-1" type="image/png" /><img alt="Dragoonsoft" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/DRAGOONSOFT.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/slot88">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SLOT88.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SLOT88.png?v=20230417-1" type="image/png" /><img alt="Slot88" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SLOT88.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/ion-slot">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PGS.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PGS.png?v=20230417-1" type="image/png" /><img alt="ION Slot" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PGS.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/joker">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/JOKER.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/JOKER.png?v=20230417-1" type="image/png" /><img alt="Joker" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/JOKER.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/fachai">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/FACHAI.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/FACHAI.png?v=20230417-1" type="image/png" /><img alt="Fachai" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/FACHAI.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/jili">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/JILI.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/JILI.png?v=20230417-1" type="image/png" /><img alt="Jili" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/JILI.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/live22">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/LIVE22.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/LIVE22.png?v=20230417-1" type="image/png" /><img alt="Live22" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/LIVE22.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/playstar">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PLAYSTAR.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PLAYSTAR.png?v=20230417-1" type="image/png" /><img alt="Playstar" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PLAYSTAR.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/spade-gaming">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SPADEGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SPADEGAMING.png?v=20230417-1" type="image/png" /><img alt="Spade Gaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SPADEGAMING.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/fun-gaming">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/FUNGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/FUNGAMING.png?v=20230417-1" type="image/png" /><img alt="Fun Gaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/FUNGAMING.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/habanero">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/HABANERO.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/HABANERO.png?v=20230417-1" type="image/png" /><img alt="Habanero" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/HABANERO.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/jdb">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/JDB.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/JDB.png?v=20230417-1" type="image/png" /><img alt="JDB" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/JDB.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/cq9">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOCQ9.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOCQ9.png?v=20230417-1" type="image/png" /><img alt="CQ9" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOCQ9.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/ttg">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/TTG.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/TTG.png?v=20230417-1" type="image/png" /><img alt="Top Trend Gaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/TTG.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/betsoft">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/BETSOFT.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/BETSOFT.png?v=20230417-1" type="image/png" /><img alt="BetSoft" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/BETSOFT.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/playtech">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PLAYTECH.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PLAYTECH.png?v=20230417-1" type="image/png" /><img alt="Playtech" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PLAYTECH.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/yggdrasil">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/YGGDRASIL.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/YGGDRASIL.png?v=20230417-1" type="image/png" /><img alt="Yggdrasil" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/YGGDRASIL.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/playngo">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PLAYNGO.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PLAYNGO.png?v=20230417-1" type="image/png" /><img alt="Play&#39;n Go" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/PLAYNGO.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/onetouch">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/ONETOUCH.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/ONETOUCH.png?v=20230417-1" type="image/png" /><img alt="OneTouch" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/ONETOUCH.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/real-time-gaming">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOREALTIMEGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOREALTIMEGAMING.png?v=20230417-1" type="image/png" /><img alt="Real Time Gaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOREALTIMEGAMING.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/flow-gaming">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOFLOWGAMING.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOFLOWGAMING.png?v=20230417-1" type="image/png" /><img alt="Flow Gaming" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOFLOWGAMING.png?v=20230417-1" /></picture>
                        </a>
                        <a href="/slots/funky-games">
                            <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOFUNKYGAME.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOFUNKYGAME.png?v=20230417-1" type="image/png" /><img alt="Funky Games" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/providers/logo/SBOFUNKYGAME.png?v=20230417-1" /></picture>
                        </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="download-apk-container" style="background-image: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/download-apk-background.jpg?v=20230417-1);">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="download-apk" id="download_apk">
                    <div>
                        <h2>
                            Unduh Gratis
                            <strong>TIC88 App</strong>
                        </h2>
                        <h3>Nikmati berbagai permainan dalam satu genggaman</h3>
                        <div class="download-apk-info">
                            <div class="download-apk-section">
                                <div class="download-apk-qr-code">
                                    <a href="https://game-apk.s3.ap-northeast-1.amazonaws.com/t8r.apk">
                                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/apk-qrcodes/T8R.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/apk-qrcodes/T8R.jpg?v=20230417-1" type="image/jpeg" /><img alt="Download Game APK" loading="lazy" src="//zm-cdn.zoomwl.com/Images/apk-qrcodes/T8R.jpg?v=20230417-1" /></picture>
                                    </a>
                                </div>
                                <div class="download-apk-btn">
                                    <a href="https://game-apk.s3.ap-northeast-1.amazonaws.com/t8r.apk" class="download-apk-btn-android">
                                        <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/android-logo.svg?v=20230417-1" /> Android APK
                                    </a>
                                </div>
                                <div class="download-apk-detail">
                                    <div class="download-apk-detail-platform">TIC88 App</div>
                                    <a class="btn" href="#" data-toggle="modal" data-target="#apk_install_guide_modal">Panduan instalasi</a>
                                </div>
                                <span class="download-apk-scan-qr">Pindai kode QR untuk Unduh Android APK</span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/download-apk-phone.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/download-apk-phone.png?v=20230417-1" type="image/png" /><img alt="Download APK" class="img-responsive" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/home/download-apk-phone.png?v=20230417-1" /></picture>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="apk_install_guide_modal" class="modal download-popup-modal" role="dialog" data-title="Panduan Instalasi" aria-hidden="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="apk_install_guide_modal_title">
                    Panduan Instalasi
                </h4>
            </div>
            <div class="modal-body" id="apk_install_guide_modal_body">
                <h5><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/android-logo.svg?v=20230417-1" /> Instalasi Android</h5>
                <ol>
                    <li>
                        Pindai kode QR untuk Android
                    </li>
                    <li>
                        Pilih buka situs web
                    </li>
                    <li>
                        Pilih "UNDUH" untuk mengunduh TIC88 App
                    </li>
                    <li>
                        Pilih "PENGATURAN"
                    </li>
                    <li>
                        Pilih "Mengizinkan" dari sumber kami
                    </li>
                    <li>
                        Pilih "Terima"
                    </li>
                    <li>
                        Pilih "INSTAL"
                    </li>
                </ol>
            </div>
        </div>
    </div>
</div>
</div>


    <div class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="site-footer-info">
                        <ul class="footer-links">
                                <li data-active="false">
                                    <a href="/info//">
                                        Daftar Situs Slot Pulsa Terbaik Agen TIC88 Jackpot
                                    </a>
                                </li>
                        </ul>
                        </div>
                    <hr />
                    <div class="site-footer-info">
                        <div>
                            <h4>Metode Pembayaran</h4>
                            <ul class="footer-bank-list">
                                        <li><img src="https://api2-t8r.tr8zgames.com/images/BNI_3d30334c-d871-46fb-80b3-0fcb12f99b87_1677349763390.png" /></li>
                                        <li><img src="https://api2-t8r.tr8zgames.com/images/BRI_a458ab91-91a3-49ac-98b3-1bfc5d1966bd_1677505864343.png" /></li>
                                        <li><img src="https://api2-t8r.tr8zgames.com/images/GOPAY_6fbfbc88-bd3a-42ab-b4e8-d35645f9cccd_1679683577987.png" /></li>
                                        <li><img src="https://api2-t8r.tr8zgames.com/images/MANDIRI_ec4427ff-2e6e-4657-a2fe-b3702bc15e7c_1680725104910.png" /></li>
                                        <li><img src="https://api2-t8r.tr8zgames.com/images/PERMATA_4d05ecbe-98e5-47db-a562-21bcf4c24565_1669271085050.png" /></li>
                            </ul>
                        </div>
                        <div>
                            <h4>Hubungi Kami</h4>
                            <ul class="social-media-list">
                                    <li>
                                        <a href="https://t.me/TIC88official" target="_blank" rel="nofollow">
                                            <img src="https://api2-t8r.tr8zgames.com/images/Telegram_fd6804d7-e59d-4012-ac10-07b36c2164e2_1677516566663.png" />
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://api.whatsapp.com/send?phone=6289505661821" target="_blank" rel="nofollow">
                                            <img src="https://api2-t8r.tr8zgames.com/images/Whatsapp_e5de0900-0421-4617-8765-3298a843f85b_1669447888240.png" />
                                        </a>
                                    </li>
                            </ul>
                        </div>
                    </div>
                    <hr />
                </div>
            </div>

                <div class="row">
                    <div class="col-lg-12">
                        <ul class="contact-list">
                                <li>
                                    <a href="https://api.whatsapp.com/send?phone=6289505661821" target="_blank" rel="noopener nofollow">
                                        <i>
                                            <img alt="Contact" loading="lazy" src="//zm-cdn.zoomwl.com/Images/communications/whatsapp.svg?v=20230417-1" />
                                        </i>
                                        6289505661821
                                    </a>
                                </li>
                        </ul>
                    </div>
                </div>

            <div class="row">
                <div class="col-lg-12 site-description">
                    <h1>SITUS SLOT DEPOSIT 5000 PULSA TRI TANPA POTONGAN GACOR | TIC88</h1>
<p><a href="https://www.androidfanatic.com">TIC88</a> yaitu web judi slot pulsa tanpa potongan juga tempat bermain slot yang kini menjadi salah satu kegiatan yang banyak dilakukan oleh masyarakat di Indonesia. Para permainan tersebut masing-masing pemain dapat bermain dengan ratusan game. Saat ini para pemain tidak perlu bingung mencari tempat untuk bermain judi slot deposit 5000. Berbagai situs di Internet sudah menyediakan permainan tersebut. Itulah mengapa masyarakat di Indonesia sangat mudah untuk mengakses permainan judi slot. Namun dengan berbagai pilihan situs yang ada di internet membuat para pemain harus bisa memilih dengan teliti. Apabila nantinya kalian salah pilih maka hasil yang diperoleh saat bermain menjadi kurang menguntungkan. Setiap pemain pastinya sudah tahu bahwa permainan tersebut mampu memberikan keuntungan sampai ratusan juta rupiah. Oleh sebab itu, pilihlah situs slot deposit pulsa tri 5000 resmi TIC88.</p>
<p>Ada hal menarik yang perlu kalian ketahui mengenai situs TIC88 resmi. Di dalamnya para pemain dapat menikmati game-game dengan visual yang menarik. Bahkan, ratusan game tersebut juga tersedia oleh berbagai provider. Hal tersebut pastinya akan membuat para pemain merasa nyaman. Selain menyajikan visual terbaik melalui tema dan simbol di dalamnya, masing-masing pemain juga mampu merasakan keseruan dengan fitur-fitur yang tersedia. Oleh karena itu, tidak heran apabila situs TIC88 resmi sampai saat ini menjadi andalan untuk bertaruh judi slot. Itulah mengapa kini para pemula sebaiknya daftar secara tepat situs TIC88 resmi.</p>
<p>Join Member Situs Slot Deposit Pulsa 5000 Agen TIC88 Resmi</p>
<p>Gabung menjadi member agen judi slot deposit 5000 terbaik merupakan pilihan tepat untuk setiap pemain. Kalian pastinya ingin bermain dengan agen yang memberikan untung besar. Tentu saja agen TIC88 resmi dapat mewujudkan hal tersebut. Di dalamnya pemain mampu menangkan taruhan dengan jackpot jutaan rupiah. Bahkan, total keuntungan yang diperoleh mencapai ratusan juta rupiah. Hal tersebut pastinya menarik perhatian bagi masyarakat di Indonesia. Bertaruh di dalamnya juga tidak memerlukan modal besar. Setelah daftar member nantinya kalian bisa deposit dengan nominal yang terjangkau bagi siapa saja. Agen TIC88 resmi dan terpercaya tidak hanya berikan kalian kemenangan dengan jackpot jutaan rupiah saja. Tetapi, sampai sekarang para pemain juga bisa raih bonus-bonus menarik. Tidak heran bila kini para pemain di Indonesia berlomba-lomba untuk dapatkan keuntungan maksimal bersama agen judi slot deposit pulsa 5000 terpercaya.</p>
<p>Apabila kalian ingin bermain bersama agen <a href="https://www.androidfanatic.com">slot deposit pulsa tri 5000</a> resmi, maka pastikan untuk daftar member. Siapapun tidak perlu khawatir bagaimana cara untuk bisa bergabung dan bermain di dalamnya. Proses yang begitu mudah tentu dapat dilakukan oleh siapa saja. Daftar member pada agen judi TIC88 sangat fleksibel. Pemain dapat mendaftar kapan saja dan dari mana saja. Kalian hanya perlu siapkan smartphone yang terkoneksi dengan internet. Agen slot deposit 5000 resmi memproses pendaftaran setiap member dengan cepat karena online 24 jam nonstop. Oleh karena itu, kalian bisa juga daftar sekarang untuk bermain dengan setiap game di dalamnya. Jika belum tahu mengenai cara daftar tersebut, maka simak caranya berikut ini dengan baik.</p>
<p>- Cara pertama tentunya pemain harus memilih agen dengan tepat karena banyakan pilihan saat ini. Hal ini masih jadi perhatian penting bagi siapa saja. Apabila nantinya kalian asal pilih maka belum tentu agen yang dipilih memberikan hasil maksimal. Hanya agen slot deposit 5000 resmi TIC88 yang berikan keuntungan hingga ratusan juta rupiah. Oleh sebab itu, berhati-hati dalam menentukan pilihan nantinya.</p>
<p>- Cara kedua para pemain dapat memilih menu daftar pada agen TIC88 resmi. Dari menu tersebut masing-masing pastinya wajib mengisi data dengan valid. Data-data yang kalian isi tentu tidak banyak. Namun, pastikan mengisi secara lengkap. Jangan sampai kalian salah dalam mengisi data-data di dalamnya. Pastikan juga bahwa data yang digunakan masih aktif sampai saat ini.</p>
<p>- Cara ketiga adalah klik kolom "Daftar" pada bagian paling bawah. Setelah melakukan hal tersebut maka kalian tentu sudah berhasil mendaftar sebagai member di dalamnya. Dengan ID yang diperoleh kalian dapat bertaruh pada tiap-tiap game di dalamnya.</p>
<p>- Cara keempat yaitu pastikan untuk login terlebih dahulu setelah menyelesaikan pendaftaran akun. Hal ini dilakukan untuk memastikan jika akun tersebut sudah bisa digunakan. Tentunya kalian terdaftar sebagai member resmi agen slot deposit 5000 terpercaya TIC88.</p>
<h2>Kumpulan Provider Terlaris Situs Slot Deposit Pulsa Tri 5000 Resmi</h2>
<p>Di dalam <a href="https://www.androidfanatic.com">situs slot</a> deposit tri tanpa potongan 5000 resmi tentu saja kalian bisa nikmati bermacam-macam game dari berbagai provider terbaik. Dari masing-masing provider yang tersedia pada situs TIC88 resmi kalian bisa bawa pulang untung jutaan rupiah. Sebagian pemain tentu memilih untuk bertaruh dengan provider terpopuler. Sebab, peluang untuk menang bahkan mendapatkan jackpot sudah pasti tinggi. Jika kalian ingin tahu berbagai pilihan terbaik provider tersebut, maka akan kami berikan daftarnya. Berikut merupakan provider-provider terlaris pada situs judi slot pulsa. Simak baik-baik untuk mengetahui secara lengkap informasi mengenai provider tersebut.</p>
<p>1. TIC88 Habanero</p>
<p>Habanero merupakan penyedia game judi slot yang kini ramai dinikmati oleh para pemain di situs TIC88 terpercaya. Tentu saja habanero memiliki berbagai keunggulan di dalamnya. Hal itu menjadikan setiap pemain tidak akan mudah merasa bosan. Perlu kalian ketahui bahwa habanero dapat dinikmati dengan berbagai pilihan bahasa. Oleh karena itu, masyarakat di Indonesia dapat dengan mudah untuk memahami berbagai kata di dalamnya. Selain itu, provider slot satu ini juga memiliki grafis yang tidak perlu diragukan lagi. Tiap-tiap pemain bahkan bisa nikmati berbagai game degan tema yang sangat menarik. Tidak hanya itu saja, namun simbol-simbol yang tersedia pada setiap game juga menambah keseruan saat bertaruh. Itulah mengapa habanero begitu banyak dinikmati para pemain hingga saat ini. Tetapi, habanero banyak dilirik oleh para member situs TIC88 bukan hanya karena itu saja. Melainkan di dalamnya kalian juga bisa menangkan jackpot besar. Salah satu yang menarik adalah jackpot progresif. Jadi, tidak perlu khawatir bertaruh dengan game-game dari habanero melalui situs slot deposit pulsa 5000 resmi.</p>
<p>2. TIC88 Pragmatic Play</p>
<p>Pragmatic play pastinya sudah tidak asing bagi banyak pemain di Indonesia. Situs judi TIC88 tentu menjadi salah satu terbaik untuk meraih untung besar bermain bersama pragmatic play. Ada beberapa hal yang perlu kalian ketahui mengenai provider tersebut. Pragmatic play sendiri memiliki deretan game dengan jumlah lebih dari ratusan judul. Hal tersebut memberikan kesempatan bagi tiap-tiap member untuk menikmati berbagai keseruan setiap harinya. Game-game yang dimiliki oleh pragmatic play bahkan mempunyai visual berkualitas tinggi. Oleh karena itu, kalian tidak akan jenuh apabila nantinya habiskan waktu bermain bersama pragmatic play hingga berjam-jam. Selain itu, pragmatic play juga menawarkan demo pada beberapa game di dalamnya. Setiap member TIC88 resmi tentu saja dapat mencoba permainan tersebut secara gratis. Tentunya hal tersebut membuat nyaman para pemain. Bagi para pemula kalian bisa berlatih untuk menangkan taruhan dengan mudah. Namun, seperti yang disampaikan sebelumnya bahwa tiap-tiap pemain dapat raih untung besar. Di sini kalian mampu menangkan berbagai jackpot. Dalam beberapa pilihan game terbaik kalian bahkan bisa dapatkan jackpot dengan berbagai macam. Oleh karena itu, tidak diragukan lagi bila setiap member mampu raih keuntungan hingga ratusan juta rupiah.</p>
<p>3. TIC88 PG Soft</p>
<p>Situs judi slot deposit pulsa 5000 tentu memiliki berbagai pilihan provider terlaris lainnya. Salah satu diantaranya yaitu PG soft. Provider tersebut memberikan pemain keseruan dalam menikmati setiap game. Kalian bisa temukan berbagai tema menarik pada tiap-tiap game dari PG soft. Perlu kalian pahami jika provider tersebut memberikan grafis yang begitu memukau. Tentu saja siapapun akan merasa nyaman ketika melihat tampilan game saat bermain. Tidak heran apabila kini PG soft juga banyak dipilih oleh sebagian besar member situs TIC88 resmi dan terpercaya. Selain itu, berbagai game dari PG soft juga memiliki tema Asia yang begitu khas. Maka dari itu, jangan lewatkan berbagai keseruan dari game-game yang dimiliki oleh PG soft.</p>
<p>4. TIC88 Microgaming</p>
<p>Saat ini provider microgaming juga bisa jadi pilihan tepat kalian saat bermain bersama situs TIC88 resmi. Mengapa microgaming begitu populer hingga saat ini? Meskipun tersedia banyak pilihan provider pada situs TIC88 tentunya microgaming juga memiliki keunggulan tersendiri. Hal ini yang menjadikan setiap pemain bisa bermain dengan merasakan berbagai keseruan. Microgaming tentu saja memiliki bermacam-macam game dengan RTP tinggi. Peluang untuk menang dari tiap-tiap game tersebut pastinya tinggi. Bahkan, bayaran yang diberikan untuk kalian juga tidak kecil. Itulah mengapa kalian bisa raih untung besar di dalamnya. Selain itu, jackpot yang tersedia juga memberikan untung besar. Pastikan tidak melewatkan berbagai game terbaik dari microgaming saat bertaruh bersama situs TIC88 terpercaya.</p>
<h3>Tips Bertaruh Judi Slot Deposit Pulsa 5000 Terpercaya Menang Jackpot</h3>
<p>Ada beberapa hal yang pastinya perlu diperhatikan saat bermain <a href="https://www.androidfanatic.com">judi slot</a> pulsa. Pemain sebaiknya tidak hanya asal bermain saja meskipun sudah daftar member agen TIC88 terpercaya. Untuk mendapatkan kemenangan dengan untung besar maka kalian perlu bermain menggunakan strategi yang tepat. Jika nantinya hanya bertaruh secara asal, maka hasil menang taruhan tersebut tidak akan memberikan untung maksimal. Itulah sebabnya kami akan berikan beberapa tips untuk bermain bersama agen TIC88 terpercaya. Perhatikan dan pahami berbagai tips tersebut untuk menangkan taruhan dengan mudah serta mendapatkan jackpot.</p>
<p>1. Tips pertama adalah pemain harus tahu berbagai hal mengenai permainan judi slot. Tentu saja permainan ini bukan hanya sekedar pasang taruhan dan memutar gulungan secara berulang-ulang. Tetapi, ada berbagai hal lainnya yang perlu dipahami untuk bisa menangkan taruhan dengan mudah. Pastinya kalian juga bisa mendapatkan jackpot terbesar. Beberapa hal tersebut seperti simbol, paylines, RTP, fitur, dan lain-lain. Setiap game tentunya memiliki ciri khas tersendiri. Oleh karena itu, jangan hanya memilih secara asal tanpa memperhatikan hal-hal tersebut.</p>
<p>2. Tips kedua adalah memilih game slot dengan win rate tinggi. Agen TIC88 tentu memiliki ratusan game dengan win rate yang beragam. Jika kalian memilih game-game dengan win rate tinggi tentunya peluang untuk menang semakin besar. Hal itu pastinya juga mempengaruhi hasil yang diperoleh saat bertaruh bersama agen TIC88. Mendapatkan jackpot bahkan wax win tentu menjadi semakin mudah.</p>
<p>3. Tips ketiga ialah bermain dengan game slot yang sudah dikuasai. Dari sekian banyak pilihan game agen TIC88 pastinya beberapa diantaranya bisa menjadi andalan tepat. Jangan hanya sembarangan memilih game untuk bertaruh. Jika nantinya kalian bermain dengan game-game yang belum dikuasai tentunya kesempatan menang justru semakin kecil.</p>
<p>4. Tips keempat ialah bertaruh menggunakan pola slot jitu. Sebagian besar member agen TIC88 tentu tidak hanya mengandalkan keberuntungan saja. Namun, bermain menggunakan pola jitu juga bisa menjadi cara tepat untuk menang dengan mudah. Hasil dari tiap-tiap taruhan pada agen TIC88 pastinya memberikan untung maksimal. Hanya saja untuk bermain dengan pola jitu para pemain juga harus mencari sumber terpercaya. Bila nantinya kalian asal-asalan dalam memilih sumber pola slot maka kemenangan tidak akan diperoleh secara mudah. Bahkan, jackpot pada agen TIC88 akan terlewatkan. Itulah mengapa tiap-tiap member agen judi TIC88 harus pintar dalam memilih sumber pola slot tersebut.</p>
<h4>Game Terbaik dan Menguntungkan Situs Judi Tri 88 Resmi No 1 di Indonesia</h4>
<p>Kesempatan untuk menangkan uang hingga ratusan juta rupiah tentu juga diperoleh dengan memilih game terbaik. Pada situs judi <a href="https://www.androidfanatic.com">slot deposit pulsa</a> 5000 kalian dapat temukan berbagai pilihan game paling menguntungkan. Tentunya kalian tidak boleh lewatkan kesempatan untuk bermain di dalamnya. Lantas, game-game apa saja yang menjadi pilihan terbaik pada situs TIC88 terpercaya? Di bawah ini adalah berbagai daftar mengenai game-game tersebut. Oleh karena itu, simak baik-baik.</p>
<ul>
    <li>Koi Gate</li>
</ul>
<p>Koi gate merupakan game RTP tinggi yang dimiliki oleh provider slot pulsa habanero. Game tersebut pastinya begitu populer pada situs TIC88 resmi. Di dalamnya kalian dapat menikmati berbagai simbol menarik serta visual terbaik. Hal tersebut tentu saja memberikan pengalaman bermain terbaik bagi setiap pemain. Bahkan, di dalam situs judi TIC88 kalian bisa raih untung besar saat bermain bersama koi gate. Dengan jackpot progresif yang tersedia di dalamnya maka kalian bisa raih untung lebih dari jutaan rupiah. Tidak mengherankan apabila kini koi gate selalu menjadi andalan bagi sebagian besar member situs TIC88 resmi.</p>
<ul>
    <li>Gates of Olympus</li>
</ul>
<p>Gates of olympus tentunya bisa jadi andalan untuk dapatkan uang jutaan rupiah dengan mudah. Game satu ini bukan hanya memberikan jackpot besar bagi setiap member situs TIC88 resmi. Namun, di dalam game tersebut pemain juga bisa nikmati fitur free spin setiap hari. Fitur tersebut memberikan kesempatan bagi siapa saja untuk bermain secara gratis tanpa saldo sedikitpun. Tidak heran bila member situs slot deposit 5000 Resmi begitu tertarik untuk bermain bersama gates of olympus.</p>
<ul>
    <li>Thunderstruck II</li>
</ul>
<p>Game terbaik lainnya dari situs alot deposit 5000 terpercaya yaitu thunderstruck II. Game tersebut kini juga banyak dicari dan dimainkan oleh sebagian besar member situs slot deposit 5000 terpercaya. Masing-masing pemain pastinya bukan hanya mendapatkan bayaran tinggi. Namun, jackpot dari game tersebut juga tinggi. Hal itu memberikan kesempatan bagi siapa saja untuk bawa pulang untung hingga ratusan juta rupiah. Jadi, tidak perlu ragu apabila nantinya kalian juga tertarik untuk bermain thunderstruck II pada situs judi slot deposit 5000 terpercaya.</p>
<p>Itulah bermacam-macam game terbaik situs slot <a href="https://www.androidfanatic.com">deposit 5000</a> yang bisa jadi pilihan telat saat bertaruh. Pilih salah satu diantaranya dan memenangkan taruhan dengan mendapatkan uang lebih dari jutaan rupiah setiap harinya. Oleh sebab itu, jangan salah daftar member situs judi slot pulsa. Daftar segera bersama situs TIC88 dan raih hasil maksimal di dalamnya.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="site-copyright-container">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="site-footer-info">
                        <div class="copyright">
                            ©2023 TIC88. All rights reserved | 18+
                        </div>
                        <div class="license-list">
                            <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/licenses/gambling-commission.svg?v=20230417-1" />
                            <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/licenses/18-plus.svg?v=20230417-1" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="site-footer-navbar navbar-fixed-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul>
                        <li data-active="true">
                            <a href="../dashboard/">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/home.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/home.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/home.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/home-active.png?v=20230417-1);" /></picture>
                                Beranda
                            </a>
                        </li>
                        <li data-active="false">
                            <a href="../mobile-app/">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/mobile-app.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/mobile-app.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/mobile-app.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/mobile-app-active.png?v=20230417-1);" /></picture>
                                Unduh
                            </a>
                        </li>
                        <li data-active="false">
                            <a href="../deposit/">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/deposit.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/deposit.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/deposit.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/deposit-active.png?v=20230417-1);" /></picture>
                                Deposit
                            </a>
                        </li>
                        <li data-active="false">
                            <a href="../promotions/">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/promotion.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/promotion.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/promotion.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/promotion-active.png?v=20230417-1);" /></picture>
                                Promosi
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)" class="js_live_chat_link" data-url="https://direct.lc.chat/15353634/">
                                <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat-active.png?v=20230417-1);" /></picture>
                                Live Chat
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <input type="checkbox" id="site_side_menu_trigger_input" class="site-side-menu-trigger-input" />

    <div class="site-side-menu">
        <label for="site_side_menu_trigger_input"></label>
        <ul>
                            <li>
                    <div class="side-menu-user-info">
    <div class="avatar">
        <i class="glyphicon glyphicon-user"></i>
    </div>
    <div>
        <div class="username"><?php echo $d['username'];?></div>
        <div class="balance-field">
            <div class="balance">
                <strong>IDR</strong>
                <span class="total_balance">0.00</span>
            </div>
            <div class="locked-balance locked_balance_container" hidden>
                <i class="glyphicon glyphicon-lock"></i>
                <span class="total_locked_balance">
                    -1.00
                </span>
            </div>
        </div>
    </div>
    <div class="buttons-container">
        <a href="#" class="logout-button" id="form_logout" onclick="window.closeWindows(); document.querySelector('#form_logout').submit();">
<form action="../logout.php" id="form_logout" method="post">Keluar</form>        </a>
    </div>
</div>

                </li>
            <li>
                <a href="../dashboard/" data-active="true">
                    <i data-icon="home">
                        <img alt="Home" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/home.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/home-active.svg?v=20230417-1);" />
                    </i>
                    Beranda
                </a>
            </li>
            <li>
                <details>
                    <summary>
                        <section>
                            <span>
                                <i data-icon="games">
                                    <img alt="Games" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/games.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/games-active.svg?v=20230417-1);" />
                                </i>
                                Games
                            </span>
                            <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                        </section>
                    </summary>
                    <article>
                        <ul>
                            <li>
                                <details>
                                    <summary>
                                        <section>
                                            Hot Games
                                            <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                        </section>
                                    </summary>
                                    <article>
                                        <ul>



<li>
    <a href="/slots/pragmatic">
        Pragmatic Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TRG/Mobile&#39;, &#39;Main&#39;)">
        ION Casino
    </a>
</li>



<li>
    <a href="/slots/microgaming">
        MicroGaming
    </a>
</li>



<li>
    <a href="/slots/crowd-play">
        Crowd Play
    </a>
</li>



<li>
    <a href="/slots/pgsoft">
        PG Slots
    </a>
</li>



<li>
    <a href="/arcade/spribe">
        Spribe
    </a>
</li>



<li>
    <a href="/slots/reel-kingdom">
        Reel Kingdom by Pragmatic
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/G8POKER/Mobile&#39;, &#39;Main&#39;)">
        Balak Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/BALAK4D/Mobile&#39;, &#39;Main&#39;)">
        Nex4D
    </a>
</li>
                                        </ul>
                                    </article>
                                </details>
                            </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Slots
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="/slots/pragmatic">
        Pragmatic Play
    </a>
</li>



<li>
    <a href="/slots/microgaming">
        MicroGaming
    </a>
</li>



<li>
    <a href="/slots/pgsoft">
        PG Slots
    </a>
</li>



<li>
    <a href="/slots/reel-kingdom">
        Reel Kingdom by Pragmatic
    </a>
</li>



<li>
    <a href="/slots/advantplay">
        AdvantPlay
    </a>
</li>



<li>
    <a href="/slots/crowd-play">
        Crowd Play
    </a>
</li>



<li>
    <a href="/slots/amb-slot">
        AMB Slot
    </a>
</li>



<li>
    <a href="/slots/bigpot">
        Bigpot
    </a>
</li>



<li>
    <a href="/slots/vpower">
        VPower
    </a>
</li>



<li>
    <a href="/slots/mario-club">
        Mario Club
    </a>
</li>



<li>
    <a href="/slots/dragoonsoft">
        Dragoonsoft
    </a>
</li>



<li>
    <a href="/slots/slot88">
        Slot88
    </a>
</li>



<li>
    <a href="/slots/ion-slot">
        ION Slot
    </a>
</li>



<li>
    <a href="/slots/joker">
        Joker
    </a>
</li>



<li>
    <a href="/slots/fachai">
        Fachai
    </a>
</li>



<li>
    <a href="/slots/jili">
        Jili
    </a>
</li>



<li>
    <a href="/slots/live22">
        Live22
    </a>
</li>



<li>
    <a href="/slots/playstar">
        Playstar
    </a>
</li>



<li>
    <a href="/slots/spade-gaming">
        Spade Gaming
    </a>
</li>



<li>
    <a href="/slots/fun-gaming">
        Fun Gaming
    </a>
</li>



<li>
    <a href="/slots/habanero">
        Habanero
    </a>
</li>



<li>
    <a href="/slots/jdb">
        JDB
    </a>
</li>



<li>
    <a href="/slots/cq9">
        CQ9
    </a>
</li>



<li>
    <a href="/slots/ttg">
        Top Trend Gaming
    </a>
</li>



<li>
    <a href="/slots/betsoft">
        BetSoft
    </a>
</li>



<li>
    <a href="/slots/playtech">
        Playtech
    </a>
</li>



<li>
    <a href="/slots/yggdrasil">
        Yggdrasil
    </a>
</li>



<li>
    <a href="/slots/playngo">
        Play&#39;n Go
    </a>
</li>



<li>
    <a href="/slots/onetouch">
        OneTouch
    </a>
</li>



<li>
    <a href="/slots/real-time-gaming">
        Real Time Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOFLOWGAMING/Mobile&#39;, &#39;Main&#39;)">
        Flow Gaming
    </a>
</li>



<li>
    <a href="/slots/funky-games">
        Funky Games
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Live Casino
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TRG/Mobile&#39;, &#39;Main&#39;)">
        ION Casino
    </a>
</li>



<li>
    <a href="/casino/pragmatic">
        PP Casino
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/MGLIVECASINO/Mobile&#39;, &#39;Main&#39;)">
        MG Live
    </a>
</li>



<li>
    <a href="/casino/evo-gaming">
        Evo Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOSEXYBACCARAT/Mobile&#39;, &#39;Main&#39;)">
        Sexy Baccarat
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PRETTYGAMING/Mobile&#39;, &#39;Main&#39;)">
        Pretty Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/AG/Mobile&#39;, &#39;Main&#39;)">
        Asia Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/ALLBET/Mobile&#39;, &#39;Main&#39;)">
        AllBet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PGSLIVE/Mobile&#39;, &#39;Main&#39;)">
        PGS Live
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SAGAMING/Mobile&#39;, &#39;Main&#39;)">
        SA Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/EBET/Mobile&#39;, &#39;Main&#39;)">
        Ebet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/DREAMGAMING/Mobile&#39;, &#39;Main&#39;)">
        Dream Gaming
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOCASINO/Mobile&#39;, &#39;Main&#39;)">
        568Win Casino
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SV388/Mobile&#39;, &#39;Main&#39;)">
        SV388
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Sports
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBO/Mobile&#39;, &#39;Main&#39;)">
        SBO Sportsbook
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IBCSPORTS/Mobile&#39;, &#39;Main&#39;)">
        Saba Sportsbook
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/OPUS/Mobile&#39;, &#39;Main&#39;)">
        Opus
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/WBET/Mobile&#39;, &#39;Main&#39;)">
        WBet
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PINNACLE/Mobile&#39;, &#39;Main&#39;)">
        Pinnacle
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/CMD/Mobile&#39;, &#39;Main&#39;)">
        CMD
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/SBOVIRTUALGAMES/Mobile&#39;, &#39;Main&#39;)">
        SBO Virtual Sports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PPVIRTUALGAMES/Mobile&#39;, &#39;Main&#39;)">
        PP Virtual Sports
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Arcade
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="/arcade/microgaming">
        MicroGaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/crowd-play">
        Crowd Play Fishing
    </a>
</li>



<li>
    <a href="/arcade/spribe">
        Spribe
    </a>
</li>



<li>
    <a href="/arcade/joker">
        Joker Fishing
    </a>
</li>



<li>
    <a href="/arcade/fachai">
        Fachai Fishing
    </a>
</li>



<li>
    <a href="/arcade/jili">
        Jili Fishing
    </a>
</li>



<li>
    <a href="/arcade/mario-club">
        Mario Club Fishing
    </a>
</li>



<li>
    <a href="/arcade/dragoonsoft">
        Dragoonsoft Fishing
    </a>
</li>



<li>
    <a href="/arcade/amb-slot">
        AMB Slot Fishing
    </a>
</li>



<li>
    <a href="/arcade/vpower">
        VPower Fishing
    </a>
</li>



<li>
    <a href="/arcade/live22">
        Live22 Fishing
    </a>
</li>



<li>
    <a href="/arcade/cq9">
        CQ9 Fishing
    </a>
</li>



<li>
    <a href="/arcade/fun-gaming">
        Fun Gaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/spade-gaming">
        Spade Gaming Fishing
    </a>
</li>



<li>
    <a href="/arcade/arcadia">
        Arcadia
    </a>
</li>



<li>
    <a href="/arcade/playstar">
        Playstar Fishing
    </a>
</li>



<li>
    <a href="/arcade/advantplay-mini-game">
        AdvantPlay Mini Game
    </a>
</li>



<li>
    <a href="/arcade/jdb">
        JDB Fishing
    </a>
</li>



<li>
    <a href="/arcade/funky-games">
        Funky Games Fishing
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IXTTANGKAS/Mobile&#39;, &#39;Main&#39;)">
        MM Tangkas
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Poker
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/G8POKER/Mobile&#39;, &#39;Main&#39;)">
        Balak Play
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/ONEPOKER/Mobile&#39;, &#39;Main&#39;)">
        9Gaming
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                E-Sports
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/IMONE/Mobile&#39;, &#39;Main&#39;)">
        IM Esports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/PINNACLEESPORTS/Mobile&#39;, &#39;Main&#39;)">
        Pinnacle E-Sports
    </a>
</li>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/TFGAMING/Mobile&#39;, &#39;Main&#39;)">
        TF Gaming
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                                <li>
                                    <details>
                                        <summary>
                                            <section>
                                                Togel
                                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                            </section>
                                        </summary>
                                        <article>
                                                <ul>



<li>
    <a href="javascript:openNewTab(&#39;/dispatch/game/BALAK4D/Mobile&#39;, &#39;Main&#39;)">
        Nex4D
    </a>
</li>
                                                </ul>
                                        </article>
                                    </details>
                                </li>
                        </ul>
                    </article>
                </details>
            </li>
                <li>
                    <details>
                        <summary>
                            <section>
                                <span>
                                    <i data-icon="wallet">
                                        <img alt="Wallet" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/wallet.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/wallet-active.svg?v=20230417-1);" />
                                    </i>
                                    KASIR
                                </span>
                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                            </section>
                        </summary>
                        <article>
                            <ul>
                                <li>
                                    <a href="../deposit/">
                                        Deposit
                                    </a>
                                </li>
                                <li>
                                    <a href="../withdrawal/">
                                        Tarik
                                    </a>
                                </li>
                                                                    <li>
                                        <a href="/bonus">
                                            Bonus
                                        </a>
                                    </li>
                                                                    <li>
                                        <a href="/commission">
                                            Komisi
                                        </a>
                                    </li>
                                                                    <li>
                                        <a href="/cashback">
                                            Cashback
                                        </a>
                                    </li>
                                                                    <li>
                                        <a href="/combine-promo">
                                            Promo Gabungan
                                        </a>
                                    </li>
                            </ul>
                        </article>
                    </details>
                </li>
                <li>
                    <details>
                        <summary>
                            <section>
                                <span>
                                    <i data-icon="message">
                                        <img alt="Message" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/message.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/message-active.svg?v=20230417-1);" />
                                    </i>
                                    Pesan
                                </span>
                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                            </section>
                        </summary>
                        <article>
                            <ul>
                                <li>
                                    <a href="#">
                                        Inbox
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        Pengumuman
                                    </a>
                                </li>
                                <li>
                                    <a href="/new-message">
                                        Tiket Bantuan
                                    </a>
                                </li>
                            </ul>
                        </article>
                    </details>
                </li>
                <li>
                    <details>
                        <summary>
                            <section>
                                <span>
                                    <i data-icon="profile">
                                        <img alt="Profile" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/profile.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/profile-active.svg?v=20230417-1);" />
                                    </i>
                                    Profil Saya
                                </span>
                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                            </section>
                        </summary>
                        <article>
                            <ul>
                                <li>
                                    <a href="../account-summary/">
                                        Akun Saya
                                    </a>
                                </li>
                                <li>
                                    <a href="/password">
                                        Ubah Kata Sandi
                                    </a>
                                </li>
                                <li>
                                    <a href="/bank-account">
                                        Banking
                                    </a>
                                </li>
                                    <li>
                                        <a href="../mobile-app/">
                                            MOBILE APP
                                        </a>
                                    </li>
                            </ul>
                        </article>
                    </details>
                </li>
                    <li>
                        <details>
                            <summary>
                                <section>
                                    <span>
                                        <i data-icon="referral">
                                            <img alt="Referral" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/referral.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/referral-active.svg?v=20230417-1);" />
                                        </i>
                                        Referensi
                                    </span>
                                    <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                                </section>
                            </summary>
                            <article>
                                <ul>
                                    <li>
                                        <a href="/referral">
                                            Referensi
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/referral/signups-summary">
                                            Ringkasan Pendaftaran
                                        </a>
                                    </li>
                                    <li>
                                        <a href="/referral/claimed-history">
                                            Riwayat Klaim
                                        </a>
                                    </li>
                                </ul>
                            </article>
                        </details>
                    </li>
                <li>
                    <details>
                        <summary>
                            <section>
                                <span>
                                    <i data-icon="reporting">
                                        <img alt="Reporting" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/reporting.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/reporting-active.svg?v=20230417-1);" />
                                    </i>
                                    Laporan
                                </span>
                                <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                            </section>
                        </summary>
                        <article>
                            <ul>
                                <li>
                                    <a href="/statement/consolidate">
                                        KONSOLIDASI

                                    </a>
                                </li>
                                <li>
                                    <a href="/history/deposit">
                                        Riwayat
                                    </a>
                                </li>
                            </ul>
                        </article>
                    </details>
                </li>
                        <li>
                <details>
                    <summary>
                        <section>
                            <span>
                                <i data-icon="language">
                                    <img alt="Language" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/language.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/language-active.svg?v=20230417-1);" />
                                </i>
                                BHS INDONESIAN
                            </span>
                            <img loading="lazy" src="//zm-cdn.zoomwl.com/Images/icons/chevron-right.svg?v=20230417-1" />
                        </section>
                    </summary>
                    <article>
                        <ul>
                                <li>
                                    <a href="javascript:changeLanguage('en')">
                                        ENGLISH
                                    </a>
                                </li>
                                <li>
                                    <a href="javascript:changeLanguage('id')">
                                        BHS INDONESIAN
                                    </a>
                                </li>
                        </ul>
                    </article>
                </details>
            </li>
                <li>
                    <a href="../mobile-app/" data-active="false">
                        <i data-icon="download">
                            <img alt="Download" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/download.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/download-active.svg?v=20230417-1);" />
                        </i>
                        Download Game APK
                    </a>
                </li>
                            <li>
                    <a href="javascript:void(window.open(&#39;/streaming/live-tv/Mobile&#39;, &#39;live-tv&#39;))" rel="nofollow">
                        <i data-icon="live-tv">
                            <img alt="Live TV" loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/live-tv.svg?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/side-menu/live-tv-active.svg?v=20230417-1);" />
                        </i>
                        Live Tv
                    </a>
                </li>
        </ul>
    </div>

    <a href="#" class="back-to-top" id="back_to_top" hidden>
        <i class="glyphicon glyphicon-arrow-up" aria-hidden="true"></i>
    </a>

    <a href="javascript:void(0)" class="live-chat-link js_live_chat_link" data-url="https://direct.lc.chat/15353634/">
        <picture><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.webp?v=20230417-1" type="image/webp" /><source srcset="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.png?v=20230417-1" type="image/png" /><img loading="lazy" src="//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat.png?v=20230417-1" style="--image-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/footer-menu/live-chat-active.png?v=20230417-1);" /></picture>
    </a>


    


<div id="popup_modal" class="modal popup-modal" role="dialog" data-title="">
    <div class="modal-dialog">
        <div class="modal-content" style="--popup-alert-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/popup/alert.png?v=20230417-1);;--popup-notification-src: url(//zm-cdn.zoomwl.com/Images/zoom-beta/dark-turquoise/layout/popup/notification.png?v=20230417-1);;--event-giveaway-popper-src: url(//zm-cdn.zoomwl.com/Images/giveaway/popper.png?v=20230417-1);">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="popup_modal_title">
                    
                </h4>
            </div>
            <div class="modal-body" id="popup_modal_body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="popup_modal_dismiss_button">
                    OK
                </button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal" id="popup_modal_cancel_button" style="display: none">
                    Batal
                </button>
                <button type="button" class="btn btn-primary" id="popup_modal_confirm_button" style="display: none">
                    OK
                </button>
            </div>
        </div>
    </div>
</div>


    <script src='../bundles/zoom-beta-js?v=OwfKtUYGKaoa3WKTGf3rhl9iu3JUsKwvzkc49sNwm_I1' defer></script>



    
    <script src='../bundles/Home/zoom-beta-js?v=3qmCvzZicpuBVrH7_VGiLr2kfjylfbWlIFKunmqqr9I1' defer></script>

    <script>
        
      
      $("#form_logout").on("submit", (function(e) {
        e.preventDefault();
        $.ajax({
          url: "../home",
          type: "POST",
          data: new FormData(this),
          contentType: false,
          cache: false,
          processData: false,
          success: function(data) { 
            if (data == "berhasil") {
              const Toast = Swal.mixin({
                toast: true,
                position: "bottom",
                showConfirmButton: false,
                timer: 1500,
                timerProgressBar: true,
                didOpen: (toast) => {
                  toast.addEventListener("mouseenter", Swal.stopTimer)
                  toast.addEventListener("mouseleave", Swal.resumeTimer)
                }
              })
              Toast.fire({
                icon: "success",
                title: "Login berhasil."
              }).then((result) => {
                if (result.dismiss === Swal.DismissReason.timer) {
                  //console.log("Login berhasil"); 
                  window.location.href = '../home';
                }
              })
            } else {
              //console.log("gagal");
              Swal.fire({
                title: "Login Gagal!",
                text: "Nama pengguna atau Kata Sandi salah!",
                icon: "error",
                confirmButtonText: "Tutup"
              })
            }
          }
        })
      }));
      </script>



    

    



</body>
</html>
