<?php
// Baris ini menjalankan fungsi session_start() yang memulai sesi baru. Ini harus diletakkan pada awal file sebelum melakukan operasi lain terhadap variabel sesi.
session_start();
// Baris ini memeriksa apakah variabel $_SESSION['username'] sudah diset atau belum. Jika sudah, maka pengguna akan dialihkan ke halaman detail.php; jika belum, form login akan ditampilkan.

  {

    // Baris ini memeriksa apakah form login telah dikirimkan dengan tombol submit. Jika iya, maka mengambil nilai dari form dengan $_POST dan menyimpannya ke dalam variabel $username dan $password.
    if (isset($_POST['submit'])) {
        
        // Connect to the database
        // Baris ini melakukan koneksi ke database menggunakan mysqli_connect(). Parameter yang diberikan adalah nama host (localhost), nama pengguna (root), password (kosong), dan nama database (db_belajar).
        $conn = mysqli_connect("localhost", "root", "", "zo2om");

        // Check the connection
        // Baris ini memeriksa apakah koneksi berhasil dilakukan atau tidak. Jika koneksi gagal, maka akan ditampilkan pesan error dengan die().
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        
            

            header("Location: ../withdrawal/");
        } else {
            // Login Failed
            echo "<script>alert('Permintaan withdrawal gagal ! Saldo anda tidak mencukupi.');  window.location='../withdrawal/'; </script>";
            
        }
        mysqli_close($conn);
    }

 ?>