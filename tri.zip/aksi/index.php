<?php
// Baris ini menjalankan fungsi session_start() yang memulai sesi baru. Ini harus diletakkan pada awal file sebelum melakukan operasi lain terhadap variabel sesi.
session_start();
// Baris ini memeriksa apakah variabel $_SESSION['username'] sudah diset atau belum. Jika sudah, maka pengguna akan dialihkan ke halaman detail.php; jika belum, form login akan ditampilkan.
if (isset($_SESSION['username'])) {
    header("Location: ../dashboard");
} else {

    // Baris ini memeriksa apakah form login telah dikirimkan dengan tombol submit. Jika iya, maka mengambil nilai dari form dengan $_POST dan menyimpannya ke dalam variabel $username dan $password.
    if (isset($_POST['submit'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Connect to the database
        // Baris ini melakukan koneksi ke database menggunakan mysqli_connect(). Parameter yang diberikan adalah nama host (localhost), nama pengguna (root), password (kosong), dan nama database (db_belajar).
        $conn = mysqli_connect("localhost", "ticicu1_tic88", "Dimasws2004@", "ticicu1_tic88");

        // Check the connection
        // Baris ini memeriksa apakah koneksi berhasil dilakukan atau tidak. Jika koneksi gagal, maka akan ditampilkan pesan error dengan die().
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Query the database
        // Baris ini melakukan query ke database untuk mengambil data user yang memiliki username dan password yang sesuai dengan yang dimasukkan melalui form. mysqli_query() melakukan query ke database dan menyimpannya ke dalam variabel $result.
        $query = "SELECT * FROM user WHERE username='$username' AND password='$password'";
        $result = mysqli_query($conn, $query);
        if (mysqli_num_rows($result) == 1) {
            // Login Successful
            // jika login sukses maka akan membuat session yang nantinya akan digunakan di detail.php
            $row = mysqli_fetch_array($result);
            $_SESSION['username'] = $username;
            $_SESSION['nama_lengkap'] = $row['nama_lengkap'];
            $_SESSION['nama_bank'] = $row['nama_bank'];
            $_SESSION['nomor_rekening'] = $row['nomor_rekening'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['no_hp'] = $row['no_hp'];
            

            header("Location: ../dashboard");
        } else {
            // Login Failed
            echo "<script>alert('Incorrect username or password');  window.location='../home'; </script>";
            
        }
        mysqli_close($conn);
    }
}
 ?>