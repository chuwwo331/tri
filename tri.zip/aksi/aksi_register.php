<?php
// Perintah ini bertujuan untuk memeriksa apakah form telah di submit. Jika form sudah di submit, maka perintah dalam kurung kurawal akan dijalankan.
if (isset($_POST['submit'])) {
    // Koneksi ke database
    // Ini adalah perintah untuk menghubungkan ke database. Parameter pertama adalah host, parameter kedua adalah username, parameter ketiga adalah password, dan parameter keempat adalah nama database.
    $conn = mysqli_connect("localhost", "ticicu1_tic88", "Dimasws2004@", "ticicu1_tic88");

    // Cek koneksi apakah berhasil atau tidak
    // Perintah ini bertujuan untuk memeriksa apakah koneksi ke database berhasil dilakukan. Jika tidak, maka akan muncul pesan error.
    if (!$conn) {
        die("Gagal terhubung ke database: " . mysqli_connect_error());
    }

    // Form data
    // ini adalah perintah untuk menyimpan data username yang diterima dari form
    $username = $_POST['username'];
    $nama_lengkap = $_POST['namaLengkap'];
    $nama_bank = $_POST['namaBank'];
    $nomor_rekening = $_POST['nomorRekening'];
    $reff = $_POST['reff'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];
    // Query untuk menyimpan data ke database
    $query = "INSERT INTO user (username, nama_lengkap, nama_bank, nomor_rekening, reff, password, email, no_hp) VALUES ('$username', '$nama_lengkap', '$nama_bank', '$nomor_rekening', '$reff', '$password', '$email', '$no_hp')";

    // Eksekusi query
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Registration successful, you can login'); window.location='../register/';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan data'); window.location='../register/';</script>";
    }

    // Tutup koneksi ke database
    mysqli_close($conn);
}



?>