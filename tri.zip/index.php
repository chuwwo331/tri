<?php
session_start();
$sesi_id = $_SESSION['id'];
if(empty($sesi_id)){
    header('location:login.php');
}else{
    include_once('functions/koneksi.php');
    $query = mysqli_query($conn, "SELECT * FROM user where id='$sesi_id'");
    $d = mysqli_fetch_assoc($query);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">

<style>
   body{
        background: #f5fdff;
      }
</style>
</head>
<body>

<div class="container">
    <div class="row d-flex justify-content-center align-items-center py-4 mt-4">
        <div class="col-12 col-md-6">
            <div class="table-responsive">
                <table class="table table-striped">
                    <tr>
                        <td>user_id</td>
                        <td><?php echo $d['id'];?></td>
                    </tr>
                    <tr>
                        <td>Username</td>
                        <td><?php echo $d['username'];?></td>
                    </tr>
                    <tr>
                        <td>Nama</td>
                        <td><?php echo ucwords($d['nama']);?></td>
                    </tr>
                    <tr>
                        <td>No Handphone</td>
                        <td><?php echo $d['kontak'];?></td>
                    </tr>
                    <tr>
                        <td colspan="2"><a href="functions/logout.php" class="btn btn-warning w-100">Keluar</a></td> 
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
    
</body>
</html>